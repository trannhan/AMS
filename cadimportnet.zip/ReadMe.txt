CADImport.NET ReadMe

Folders contents:

-----------------------------------------------------------------------------------------
.\bin � executable files of demo applications, the Viewer or Import Library 
(depending on the order, the Viewer library is offered by default) � CADImport.dll;
-----------------------------------------------------------------------------------------
.\doc � the demo applications� documentation and the library�s documentation;
-----------------------------------------------------------------------------------------
.\sourses � the source code of demo applications;
-----------------------------------------------------------------------------------------
.\sourses\AddEntityDemo � the source code of demo application that demonstrates 
a process of adding new entities to the existing opened DXF or DWG file; this application 
uses the Import library and offered in the reduced form � EXE file and the code of the 
application without the library code (the Import library is needed for compiling 
the application);
-----------------------------------------------------------------------------------------
.\sourses\Import � the source code of the application that demonstrates the access to 
the properties of the loaded entities; this application also requires the Import library 
and by default offered in the reduced form � EXE file and the code of the application 
without the library code (the Import library is needed for compiling the application);
-----------------------------------------------------------------------------------------
.\sourses\Viewer � the source code of the demo application that demonstrates all 
possible ways of work with the library to display, print CAD files or export them 
into other formats;
-----------------------------------------------------------------------------------------
.\sourses\ViewerControl � the source code of the application that demonstrates how to 
work with the CADImportControl component.
-----------------------------------------------------------------------------------------

Sales questions: info@cadsofttools.com 
Request for Import demo: info@cadsofttools.com  