using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing.Imaging;
using CADImport;
using RasterImage;

public partial class _Default : System.Web.UI.Page 
{
    private string outFileName = @"testasp3.jpg";
    private CADImage FCADImage;
    
    protected override void OnPreLoad(EventArgs e)
    {
        tbFileName.Text = Request["inpath"];
        tbLeft.Text = Request["leftPos"];
        tbTop.Text = Request["topPos"];
        tbWidth.Text = Request["width"];
        tbHeight.Text = Request["height"];
        Image1.ImageUrl = Request["outpath"];
        if(Request["imageVisible"] == "1")
          Image1.Visible = true;
      else Image1.Visible = false;
        base.OnPreLoad(e);
    }

    protected void btnLoadFile_Click(object sender, EventArgs e)
    {
        string realPath = this.MapPath("") + "\\";
        string tmp = Request["tbFileName"];
        string left = Request["tbLeft"];
        string top = Request["tbTop"];
        string width = Request["tbWidth"];
        string height = Request["tbHeight"];
        int l = 0, t = 0, w = 500, h = 500;
        try
        {
            l = Convert.ToInt32(left.Trim());
            t = Convert.ToInt32(top.Trim());
            w = Convert.ToInt32(width.Trim());
            h = Convert.ToInt32(height.Trim());
        } 
        catch{ }
        if (OpenFile(realPath + tmp, realPath + outFileName, l, t, w, h) != 0) return;
        string tmpurl = @"http://" + this.Request.Url.Authority + this.Request.Url.AbsolutePath;
        string tmpquery = this.Request.Url.Query;
        if (tmpquery != "") tmpurl = tmpurl.Replace(tmpquery, "");
        Response.Redirect(tmpurl + @"?outpath=.\" + outFileName + "&inpath=" + tmp + "&imageVisible=1&leftPos=" + l +
                         "&topPos=" + t + "&width=" + w + "&height=" + h);
    }

    public Errors OpenFile(string inFileName, string outFileName, double left, double top, double width, double height)
    {
        try
        {
            if (inFileName.ToUpper().IndexOf(".DWG") != -1)
            {
                FCADImage = new DWG.DWGImage();
                ((DWG.DWGImage)FCADImage).LoadFromFile(inFileName);
            }
            else
            {
                if (inFileName.ToUpper().IndexOf(".DXF") != -1)
                {
                    FCADImage = new CADImage();
                    FCADImage.LoadFromFile(inFileName);
                }
                else
                {
                    FCADImage = new CADRasterImage();
                    FCADImage.LoadFromFile(inFileName);
                }
            }
            //save raster image
            DRect boundaryRectangle = new DRect(left, top, width, height);
            ImageFormat imgFrm = ImageFormat.Bmp;
            if (outFileName != null)
            {
                string tmp = outFileName;
                if (tmp.ToUpper().IndexOf(".JPG") != -1)
                    imgFrm = ImageFormat.Jpeg;
                if (tmp.ToUpper().IndexOf(".BMP") != -1)
                    imgFrm = ImageFormat.Bmp;
                if (tmp.ToUpper().IndexOf(".TIFF") != -1)
                    imgFrm = ImageFormat.Tiff;
                if (tmp.ToUpper().IndexOf(".GIF") != -1)
                    imgFrm = ImageFormat.Gif;
            }
            FCADImage.SaveToFile(outFileName, ImageFormat.Bmp, boundaryRectangle);               
        }
        catch
        {
            return Errors.UNIDENTIFIED_ERROR;
        }
        return Errors.NO_ERRORS;
    }

    public enum Errors
    {
        NO_ERRORS,
        FILE_NOT_FOUND,
        UNIDENTIFIED_ERROR
    }
}
