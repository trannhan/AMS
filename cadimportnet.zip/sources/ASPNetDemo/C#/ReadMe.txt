CADImport.Net ASP Demo ReadMe

This project has been created in Microsoft Visual Studio 2005.
However, the main application code (Default.aspx.cs) is completely 
compatible with Microsoft Visual Studio 2003.

To start the demo application:
-install it;
-open Microsoft Visual Studio 2005;
-select menu item File\Open\Web Site...;
-select the main directory where the demo application had been installed.

Sales questions: info@cadsofttools.com 
Request for Import demo: info@cadsofttools.com  