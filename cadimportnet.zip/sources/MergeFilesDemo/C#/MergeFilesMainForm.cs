//To compile the project you need the extended version of the CADImport .NET library
//that allows to access CAD entities directly.  You can get this version of the 
//library free of charge by emailing your request to: info@cadsofttools.com
using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using CADImport;
using RasterImage;
using CADImportFaceModule;
using MergeFilesDemoApplication;
using HPGL2;

namespace CADImportForm
{
	#region Help
	/// <summary>
	/// Represents the main application form in which CAD images can be viewed and merged.
	/// </summary>
	#endregion Help
	public class MainForm: System.Windows.Forms.Form
	{
		private const int OnMouseScroll = 522;
		#region Help
		/// <summary>
		/// A <B>string</B> containing a name of the default directory where to search for the files of language support.
		/// </summary>
		#endregion Help
		public static readonly string cnstLngPath = @"..\..\..\Languages";
		private bool deactiv;
		private PointF old_Pos;
		private LayerForm lForm;
		internal static MainForm actForm;
		private AboutForm aboutFrm;
		private SHXForm shxFrm;
		#region protect
		#if protect
			private RegForm regFrm;
		#endif
		#if (protect && floatprotect)
			private FloatLicForm floatLicFrm;
		#endif
		#endregion protect
		private MergeForm mgForm;
		private PointF pos;
		private Rectangle curClRect;
		private float wh;
		private float scale;
		private DPoint ScaleRect;
		private ArrayList layouts;
		private int cX, cY;
		private bool det1;
		private float prev_scale = 1;
		private System.Windows.Forms.ItemCheckEventHandler dl1;
		private System.Windows.Forms.StatusBar stBar;
		internal System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem mExit;
		private System.Windows.Forms.MenuItem mOpenFile;
		private System.Windows.Forms.MenuItem mSaveFile;
		private System.Windows.Forms.MenuItem mFile;
		private System.Windows.Forms.MenuItem mView;
		private System.Windows.Forms.MenuItem mScale;
		private System.Windows.Forms.MenuItem aboutMenuItem;
		private System.Windows.Forms.StatusBarPanel sbOpen;
		private System.Windows.Forms.StatusBarPanel sbScale;
		private System.Windows.Forms.ColorDialog setColorDlg;
		private System.Windows.Forms.ToolBarButton tlbOpen;
		private System.Windows.Forms.ToolBarButton tlbZoomIn;
		private System.Windows.Forms.ToolBarButton tlbZoomOut;
		private System.Windows.Forms.ToolBarButton tlbSave;
		private System.Windows.Forms.ToolBarButton tlbWhite;
		private System.Windows.Forms.ToolBarButton tlbBlack;
		private System.Windows.Forms.ToolBarButton tlbColor;
		private System.Windows.Forms.ToolBar tlbTool;
		private System.Windows.Forms.SaveFileDialog saveImgDlg;
		private System.Windows.Forms.ToolBarButton tlbOSX;
		private System.Windows.Forms.ToolBarButton tlb3d;
		private System.Windows.Forms.ToolBarButton tlbBlackMode;
		private System.Windows.Forms.ToolBarButton tlbColorMode;
		private System.Windows.Forms.ContextMenu orbitViewMenu;
		private System.Windows.Forms.MenuItem InitialViewMenuItem;
		private System.Windows.Forms.MenuItem TopViewMenuItem;
		private System.Windows.Forms.MenuItem BottomViewMenuItem;
		private System.Windows.Forms.MenuItem LeftViewMenuItem;
		private System.Windows.Forms.MenuItem RightViewMenuItem;
		private System.Windows.Forms.MenuItem FrontViewMenuItem;
		private System.Windows.Forms.MenuItem BackViewMenuItem;
		private System.Windows.Forms.MenuItem SWViewMenuItem;
		private System.Windows.Forms.MenuItem SEViewMenuItem;
		private System.Windows.Forms.MenuItem NEViewMenuItem;
		private System.Windows.Forms.MenuItem NWViewMenuItem;
		private System.Windows.Forms.StatusBarPanel sbCoord;
		private System.Windows.Forms.ToolBarButton tlbDefSize;
		private System.Windows.Forms.ToolBarButton tlbTextShow;
		private System.Windows.Forms.ToolBarButton tlbDimShow;
		private System.Windows.Forms.ToolBarButton tlbSaveImageClip;
		private System.Windows.Forms.ToolBarButton tlbPrint;
		private System.Windows.Forms.MenuItem menuItemReg;
		private System.Windows.Forms.Panel trvPanel;
		private System.Windows.Forms.PictureBox cadPictBox;
		private System.Windows.Forms.TreeView trvEntity;
		private System.Windows.Forms.MenuItem menuItem24;
		private System.Windows.Forms.MenuItem entitiesMenuItem;
		private System.Windows.Forms.MenuItem zoomInMenuItem;
		private System.Windows.Forms.MenuItem zoomOutMenuItem;
		private System.Windows.Forms.MenuItem fitMenuItem;
		private System.Windows.Forms.MenuItem menuItem29;
		private System.Windows.Forms.MenuItem copyMenuItem;
		private System.Windows.Forms.MenuItem colorMenuItem;
		private System.Windows.Forms.MenuItem blackMenuItem;
		private System.Windows.Forms.MenuItem whiteBackMenuItem;
		private System.Windows.Forms.MenuItem blackBackMenuItem;
		private System.Windows.Forms.MenuItem changeBackMenuItem;
		private System.Windows.Forms.MenuItem menuItem38;
		private System.Windows.Forms.MenuItem showLineWeightMenuItem;
		private System.Windows.Forms.MenuItem arcsSplitMenuItem;
		private System.Windows.Forms.MenuItem dimShowMenuItem;
		private System.Windows.Forms.MenuItem textsShowMenuItem;
		private System.Windows.Forms.MenuItem menuItem43;
		private System.Windows.Forms.MenuItem ViewMenuItem;
		private System.Windows.Forms.MenuItem orbitMenuItem;
		private System.Windows.Forms.MenuItem closeMenuItem;
		private System.Windows.Forms.MenuItem printMenuItem;
		private System.Windows.Forms.MenuItem InitMenuItem;
		private Orbit3D Orb3D;
		private System.Windows.Forms.ImageList toolBtnImageList;
		private System.Windows.Forms.MenuItem topMenuItem;
		private System.Windows.Forms.MenuItem zoom10MenuItem;
		private System.Windows.Forms.MenuItem zoom25MenuItem;
		private System.Windows.Forms.MenuItem zoom50MenuItem;
		private System.Windows.Forms.MenuItem zoom100MenuItem;
		private System.Windows.Forms.MenuItem zoom200MenuItem;
		private System.Windows.Forms.MenuItem zoom400MenuItem;
		private System.Windows.Forms.MenuItem zoom800MenuItem;
		private System.Windows.Forms.MenuItem bottomMenuItem;
		private System.Windows.Forms.MenuItem leftMenuItem;
		private System.Windows.Forms.MenuItem rightMenuItem;
		private System.Windows.Forms.MenuItem frontMenuItem;
		private System.Windows.Forms.MenuItem backMenuItem;
		private System.Windows.Forms.MenuItem swMenuItem;
		private System.Windows.Forms.MenuItem seMenuItem;
		private System.Windows.Forms.MenuItem neMenuItem;
		private System.Windows.Forms.MenuItem nwMenuItem;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.MenuItem editMenuItem;
		private System.Windows.Forms.MenuItem cADFilesMenuItem;
		private System.Windows.Forms.MenuItem helpMenuItem;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.MenuItem menuItem1;
		internal CADImage FCADImage;
		internal static string lngFile = "Default";
		internal MultipleLanguage mlng;
		private SaveSettings svSet;
		internal static SortedList settingsLst;
		private readonly string fileSettingsName = Application.StartupPath + @"\Settings.txt";
		private System.Windows.Forms.MenuItem menuItem3;
		private bool colorDraw;
		private byte curLngInd;
		private System.Windows.Forms.PrintPreviewDialog printPrevDlg;
		private System.Windows.Forms.MenuItem printprevItem;
		private OptionsForm optForm;
		private System.Windows.Forms.MenuItem print2Item;
		private System.Windows.Forms.OpenFileDialog openFileDlg;
		private System.Windows.Forms.ToolBarButton tlbMergeFiles;
		private System.Windows.Forms.MenuItem mnSaveAsDXF;
		private System.Windows.Forms.SaveFileDialog saveDXFDlg;
		private PrintingForm prtForm;
		private System.Windows.Forms.ToolBarButton tlbRect;
		private System.Windows.Forms.MenuItem miFloatLic;
		private ClipRect clipRectangle;
		private static readonly ArrayList HPGLExt;

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.saveImgDlg = new System.Windows.Forms.SaveFileDialog();
			this.stBar = new System.Windows.Forms.StatusBar();
			this.sbOpen = new System.Windows.Forms.StatusBarPanel();
			this.sbScale = new System.Windows.Forms.StatusBarPanel();
			this.sbCoord = new System.Windows.Forms.StatusBarPanel();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.mFile = new System.Windows.Forms.MenuItem();
			this.mOpenFile = new System.Windows.Forms.MenuItem();
			this.mSaveFile = new System.Windows.Forms.MenuItem();
			this.mnSaveAsDXF = new System.Windows.Forms.MenuItem();
			this.printMenuItem = new System.Windows.Forms.MenuItem();
			this.print2Item = new System.Windows.Forms.MenuItem();
			this.printprevItem = new System.Windows.Forms.MenuItem();
			this.closeMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mExit = new System.Windows.Forms.MenuItem();
			this.editMenuItem = new System.Windows.Forms.MenuItem();
			this.copyMenuItem = new System.Windows.Forms.MenuItem();
			this.mView = new System.Windows.Forms.MenuItem();
			this.entitiesMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem24 = new System.Windows.Forms.MenuItem();
			this.zoomInMenuItem = new System.Windows.Forms.MenuItem();
			this.zoomOutMenuItem = new System.Windows.Forms.MenuItem();
			this.mScale = new System.Windows.Forms.MenuItem();
			this.zoom10MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom25MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom50MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom100MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom200MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom400MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom800MenuItem = new System.Windows.Forms.MenuItem();
			this.fitMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem29 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.cADFilesMenuItem = new System.Windows.Forms.MenuItem();
			this.colorMenuItem = new System.Windows.Forms.MenuItem();
			this.blackMenuItem = new System.Windows.Forms.MenuItem();
			this.whiteBackMenuItem = new System.Windows.Forms.MenuItem();
			this.blackBackMenuItem = new System.Windows.Forms.MenuItem();
			this.changeBackMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem38 = new System.Windows.Forms.MenuItem();
			this.showLineWeightMenuItem = new System.Windows.Forms.MenuItem();
			this.arcsSplitMenuItem = new System.Windows.Forms.MenuItem();
			this.dimShowMenuItem = new System.Windows.Forms.MenuItem();
			this.textsShowMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem43 = new System.Windows.Forms.MenuItem();
			this.ViewMenuItem = new System.Windows.Forms.MenuItem();
			this.InitMenuItem = new System.Windows.Forms.MenuItem();
			this.topMenuItem = new System.Windows.Forms.MenuItem();
			this.bottomMenuItem = new System.Windows.Forms.MenuItem();
			this.leftMenuItem = new System.Windows.Forms.MenuItem();
			this.rightMenuItem = new System.Windows.Forms.MenuItem();
			this.frontMenuItem = new System.Windows.Forms.MenuItem();
			this.backMenuItem = new System.Windows.Forms.MenuItem();
			this.swMenuItem = new System.Windows.Forms.MenuItem();
			this.seMenuItem = new System.Windows.Forms.MenuItem();
			this.neMenuItem = new System.Windows.Forms.MenuItem();
			this.nwMenuItem = new System.Windows.Forms.MenuItem();
			this.orbitMenuItem = new System.Windows.Forms.MenuItem();
			this.helpMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemReg = new System.Windows.Forms.MenuItem();
			this.miFloatLic = new System.Windows.Forms.MenuItem();
			this.aboutMenuItem = new System.Windows.Forms.MenuItem();
			this.setColorDlg = new System.Windows.Forms.ColorDialog();
			this.tlbTool = new System.Windows.Forms.ToolBar();
			this.tlbOpen = new System.Windows.Forms.ToolBarButton();
			this.tlbMergeFiles = new System.Windows.Forms.ToolBarButton();
			this.tlbZoomIn = new System.Windows.Forms.ToolBarButton();
			this.tlbZoomOut = new System.Windows.Forms.ToolBarButton();
			this.tlbSave = new System.Windows.Forms.ToolBarButton();
			this.tlbWhite = new System.Windows.Forms.ToolBarButton();
			this.tlbBlack = new System.Windows.Forms.ToolBarButton();
			this.tlbColor = new System.Windows.Forms.ToolBarButton();
			this.tlb3d = new System.Windows.Forms.ToolBarButton();
			this.orbitViewMenu = new System.Windows.Forms.ContextMenu();
			this.InitialViewMenuItem = new System.Windows.Forms.MenuItem();
			this.TopViewMenuItem = new System.Windows.Forms.MenuItem();
			this.BottomViewMenuItem = new System.Windows.Forms.MenuItem();
			this.LeftViewMenuItem = new System.Windows.Forms.MenuItem();
			this.RightViewMenuItem = new System.Windows.Forms.MenuItem();
			this.FrontViewMenuItem = new System.Windows.Forms.MenuItem();
			this.BackViewMenuItem = new System.Windows.Forms.MenuItem();
			this.SWViewMenuItem = new System.Windows.Forms.MenuItem();
			this.SEViewMenuItem = new System.Windows.Forms.MenuItem();
			this.NEViewMenuItem = new System.Windows.Forms.MenuItem();
			this.NWViewMenuItem = new System.Windows.Forms.MenuItem();
			this.tlbOSX = new System.Windows.Forms.ToolBarButton();
			this.tlbBlackMode = new System.Windows.Forms.ToolBarButton();
			this.tlbColorMode = new System.Windows.Forms.ToolBarButton();
			this.tlbDefSize = new System.Windows.Forms.ToolBarButton();
			this.tlbTextShow = new System.Windows.Forms.ToolBarButton();
			this.tlbDimShow = new System.Windows.Forms.ToolBarButton();
			this.tlbSaveImageClip = new System.Windows.Forms.ToolBarButton();
			this.tlbPrint = new System.Windows.Forms.ToolBarButton();
			this.tlbRect = new System.Windows.Forms.ToolBarButton();
			this.toolBtnImageList = new System.Windows.Forms.ImageList(this.components);
			this.trvPanel = new System.Windows.Forms.Panel();
			this.trvEntity = new System.Windows.Forms.TreeView();
			this.cadPictBox = new System.Windows.Forms.PictureBox();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.printPrevDlg = new System.Windows.Forms.PrintPreviewDialog();
			this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
			this.saveDXFDlg = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).BeginInit();
			this.trvPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// saveImgDlg
			// 
			this.saveImgDlg.Filter = resources.GetString("saveImgDlg.Filter");
			this.saveImgDlg.RestoreDirectory = true;
			this.saveImgDlg.Title = resources.GetString("saveImgDlg.Title");
			// 
			// stBar
			// 
			this.stBar.AccessibleDescription = resources.GetString("stBar.AccessibleDescription");
			this.stBar.AccessibleName = resources.GetString("stBar.AccessibleName");
			this.stBar.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("stBar.Anchor")));
			this.stBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stBar.BackgroundImage")));
			this.stBar.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("stBar.Dock")));
			this.stBar.Enabled = ((bool)(resources.GetObject("stBar.Enabled")));
			this.stBar.Font = ((System.Drawing.Font)(resources.GetObject("stBar.Font")));
			this.stBar.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("stBar.ImeMode")));
			this.stBar.Location = ((System.Drawing.Point)(resources.GetObject("stBar.Location")));
			this.stBar.Name = "stBar";
			this.stBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					 this.sbOpen,
																					 this.sbScale,
																					 this.sbCoord});
			this.stBar.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("stBar.RightToLeft")));
			this.stBar.ShowPanels = true;
			this.stBar.Size = ((System.Drawing.Size)(resources.GetObject("stBar.Size")));
			this.stBar.TabIndex = ((int)(resources.GetObject("stBar.TabIndex")));
			this.stBar.Text = resources.GetString("stBar.Text");
			this.stBar.Visible = ((bool)(resources.GetObject("stBar.Visible")));
			// 
			// sbOpen
			// 
			this.sbOpen.Alignment = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("sbOpen.Alignment")));
			this.sbOpen.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbOpen.Icon = ((System.Drawing.Icon)(resources.GetObject("sbOpen.Icon")));
			this.sbOpen.MinWidth = ((int)(resources.GetObject("sbOpen.MinWidth")));
			this.sbOpen.Text = resources.GetString("sbOpen.Text");
			this.sbOpen.ToolTipText = resources.GetString("sbOpen.ToolTipText");
			this.sbOpen.Width = ((int)(resources.GetObject("sbOpen.Width")));
			// 
			// sbScale
			// 
			this.sbScale.Alignment = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("sbScale.Alignment")));
			this.sbScale.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbScale.Icon = ((System.Drawing.Icon)(resources.GetObject("sbScale.Icon")));
			this.sbScale.MinWidth = ((int)(resources.GetObject("sbScale.MinWidth")));
			this.sbScale.Text = resources.GetString("sbScale.Text");
			this.sbScale.ToolTipText = resources.GetString("sbScale.ToolTipText");
			this.sbScale.Width = ((int)(resources.GetObject("sbScale.Width")));
			// 
			// sbCoord
			// 
			this.sbCoord.Alignment = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("sbCoord.Alignment")));
			this.sbCoord.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbCoord.Icon = ((System.Drawing.Icon)(resources.GetObject("sbCoord.Icon")));
			this.sbCoord.MinWidth = ((int)(resources.GetObject("sbCoord.MinWidth")));
			this.sbCoord.Text = resources.GetString("sbCoord.Text");
			this.sbCoord.ToolTipText = resources.GetString("sbCoord.ToolTipText");
			this.sbCoord.Width = ((int)(resources.GetObject("sbCoord.Width")));
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mFile,
																					 this.editMenuItem,
																					 this.mView,
																					 this.cADFilesMenuItem,
																					 this.helpMenuItem});
			this.mainMenu.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("mainMenu.RightToLeft")));
			// 
			// mFile
			// 
			this.mFile.Enabled = ((bool)(resources.GetObject("mFile.Enabled")));
			this.mFile.Index = 0;
			this.mFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mOpenFile,
																				  this.mSaveFile,
																				  this.mnSaveAsDXF,
																				  this.printMenuItem,
																				  this.print2Item,
																				  this.printprevItem,
																				  this.closeMenuItem,
																				  this.menuItem2,
																				  this.mExit});
			this.mFile.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mFile.Shortcut")));
			this.mFile.ShowShortcut = ((bool)(resources.GetObject("mFile.ShowShortcut")));
			this.mFile.Text = resources.GetString("mFile.Text");
			this.mFile.Visible = ((bool)(resources.GetObject("mFile.Visible")));
			// 
			// mOpenFile
			// 
			this.mOpenFile.Enabled = ((bool)(resources.GetObject("mOpenFile.Enabled")));
			this.mOpenFile.Index = 0;
			this.mOpenFile.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mOpenFile.Shortcut")));
			this.mOpenFile.ShowShortcut = ((bool)(resources.GetObject("mOpenFile.ShowShortcut")));
			this.mOpenFile.Text = resources.GetString("mOpenFile.Text");
			this.mOpenFile.Visible = ((bool)(resources.GetObject("mOpenFile.Visible")));
			this.mOpenFile.Click += new System.EventHandler(this.Open_Click);
			// 
			// mSaveFile
			// 
			this.mSaveFile.Enabled = ((bool)(resources.GetObject("mSaveFile.Enabled")));
			this.mSaveFile.Index = 1;
			this.mSaveFile.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mSaveFile.Shortcut")));
			this.mSaveFile.ShowShortcut = ((bool)(resources.GetObject("mSaveFile.ShowShortcut")));
			this.mSaveFile.Text = resources.GetString("mSaveFile.Text");
			this.mSaveFile.Visible = ((bool)(resources.GetObject("mSaveFile.Visible")));
			this.mSaveFile.Click += new System.EventHandler(this.ImgSave_Click);
			// 
			// mnSaveAsDXF
			// 
			this.mnSaveAsDXF.Enabled = ((bool)(resources.GetObject("mnSaveAsDXF.Enabled")));
			this.mnSaveAsDXF.Index = 2;
			this.mnSaveAsDXF.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mnSaveAsDXF.Shortcut")));
			this.mnSaveAsDXF.ShowShortcut = ((bool)(resources.GetObject("mnSaveAsDXF.ShowShortcut")));
			this.mnSaveAsDXF.Text = resources.GetString("mnSaveAsDXF.Text");
			this.mnSaveAsDXF.Visible = ((bool)(resources.GetObject("mnSaveAsDXF.Visible")));
			this.mnSaveAsDXF.Click += new System.EventHandler(this.mnSaveAsDXF_Click);
			// 
			// printMenuItem
			// 
			this.printMenuItem.Enabled = ((bool)(resources.GetObject("printMenuItem.Enabled")));
			this.printMenuItem.Index = 3;
			this.printMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("printMenuItem.Shortcut")));
			this.printMenuItem.ShowShortcut = ((bool)(resources.GetObject("printMenuItem.ShowShortcut")));
			this.printMenuItem.Text = resources.GetString("printMenuItem.Text");
			this.printMenuItem.Visible = ((bool)(resources.GetObject("printMenuItem.Visible")));
			this.printMenuItem.Click += new System.EventHandler(this.printMenuItem_Click);
			// 
			// print2Item
			// 
			this.print2Item.Enabled = ((bool)(resources.GetObject("print2Item.Enabled")));
			this.print2Item.Index = 4;
			this.print2Item.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("print2Item.Shortcut")));
			this.print2Item.ShowShortcut = ((bool)(resources.GetObject("print2Item.ShowShortcut")));
			this.print2Item.Text = resources.GetString("print2Item.Text");
			this.print2Item.Visible = ((bool)(resources.GetObject("print2Item.Visible")));
			this.print2Item.Click += new System.EventHandler(this.btnPrintPrevCust_Click);
			// 
			// printprevItem
			// 
			this.printprevItem.Enabled = ((bool)(resources.GetObject("printprevItem.Enabled")));
			this.printprevItem.Index = 5;
			this.printprevItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("printprevItem.Shortcut")));
			this.printprevItem.ShowShortcut = ((bool)(resources.GetObject("printprevItem.ShowShortcut")));
			this.printprevItem.Text = resources.GetString("printprevItem.Text");
			this.printprevItem.Visible = ((bool)(resources.GetObject("printprevItem.Visible")));
			this.printprevItem.Click += new System.EventHandler(this.printprevItem_Click);
			// 
			// closeMenuItem
			// 
			this.closeMenuItem.Enabled = ((bool)(resources.GetObject("closeMenuItem.Enabled")));
			this.closeMenuItem.Index = 6;
			this.closeMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("closeMenuItem.Shortcut")));
			this.closeMenuItem.ShowShortcut = ((bool)(resources.GetObject("closeMenuItem.ShowShortcut")));
			this.closeMenuItem.Text = resources.GetString("closeMenuItem.Text");
			this.closeMenuItem.Visible = ((bool)(resources.GetObject("closeMenuItem.Visible")));
			this.closeMenuItem.Click += new System.EventHandler(this.closeMenuItem_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Enabled = ((bool)(resources.GetObject("menuItem2.Enabled")));
			this.menuItem2.Index = 7;
			this.menuItem2.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem2.Shortcut")));
			this.menuItem2.ShowShortcut = ((bool)(resources.GetObject("menuItem2.ShowShortcut")));
			this.menuItem2.Text = resources.GetString("menuItem2.Text");
			this.menuItem2.Visible = ((bool)(resources.GetObject("menuItem2.Visible")));
			// 
			// mExit
			// 
			this.mExit.Enabled = ((bool)(resources.GetObject("mExit.Enabled")));
			this.mExit.Index = 8;
			this.mExit.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mExit.Shortcut")));
			this.mExit.ShowShortcut = ((bool)(resources.GetObject("mExit.ShowShortcut")));
			this.mExit.Text = resources.GetString("mExit.Text");
			this.mExit.Visible = ((bool)(resources.GetObject("mExit.Visible")));
			this.mExit.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// editMenuItem
			// 
			this.editMenuItem.Enabled = ((bool)(resources.GetObject("editMenuItem.Enabled")));
			this.editMenuItem.Index = 1;
			this.editMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.copyMenuItem});
			this.editMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("editMenuItem.Shortcut")));
			this.editMenuItem.ShowShortcut = ((bool)(resources.GetObject("editMenuItem.ShowShortcut")));
			this.editMenuItem.Text = resources.GetString("editMenuItem.Text");
			this.editMenuItem.Visible = ((bool)(resources.GetObject("editMenuItem.Visible")));
			// 
			// copyMenuItem
			// 
			this.copyMenuItem.Enabled = ((bool)(resources.GetObject("copyMenuItem.Enabled")));
			this.copyMenuItem.Index = 0;
			this.copyMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("copyMenuItem.Shortcut")));
			this.copyMenuItem.ShowShortcut = ((bool)(resources.GetObject("copyMenuItem.ShowShortcut")));
			this.copyMenuItem.Text = resources.GetString("copyMenuItem.Text");
			this.copyMenuItem.Visible = ((bool)(resources.GetObject("copyMenuItem.Visible")));
			this.copyMenuItem.Click += new System.EventHandler(this.copyMenuItem_Click);
			// 
			// mView
			// 
			this.mView.Enabled = ((bool)(resources.GetObject("mView.Enabled")));
			this.mView.Index = 2;
			this.mView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.entitiesMenuItem,
																				  this.menuItem24,
																				  this.zoomInMenuItem,
																				  this.zoomOutMenuItem,
																				  this.mScale,
																				  this.fitMenuItem,
																				  this.menuItem29,
																				  this.menuItem3});
			this.mView.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mView.Shortcut")));
			this.mView.ShowShortcut = ((bool)(resources.GetObject("mView.ShowShortcut")));
			this.mView.Text = resources.GetString("mView.Text");
			this.mView.Visible = ((bool)(resources.GetObject("mView.Visible")));
			// 
			// entitiesMenuItem
			// 
			this.entitiesMenuItem.Checked = true;
			this.entitiesMenuItem.Enabled = ((bool)(resources.GetObject("entitiesMenuItem.Enabled")));
			this.entitiesMenuItem.Index = 0;
			this.entitiesMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("entitiesMenuItem.Shortcut")));
			this.entitiesMenuItem.ShowShortcut = ((bool)(resources.GetObject("entitiesMenuItem.ShowShortcut")));
			this.entitiesMenuItem.Text = resources.GetString("entitiesMenuItem.Text");
			this.entitiesMenuItem.Visible = ((bool)(resources.GetObject("entitiesMenuItem.Visible")));
			this.entitiesMenuItem.Click += new System.EventHandler(this.entitiesMenuItem_Click);
			// 
			// menuItem24
			// 
			this.menuItem24.Enabled = ((bool)(resources.GetObject("menuItem24.Enabled")));
			this.menuItem24.Index = 1;
			this.menuItem24.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem24.Shortcut")));
			this.menuItem24.ShowShortcut = ((bool)(resources.GetObject("menuItem24.ShowShortcut")));
			this.menuItem24.Text = resources.GetString("menuItem24.Text");
			this.menuItem24.Visible = ((bool)(resources.GetObject("menuItem24.Visible")));
			// 
			// zoomInMenuItem
			// 
			this.zoomInMenuItem.Enabled = ((bool)(resources.GetObject("zoomInMenuItem.Enabled")));
			this.zoomInMenuItem.Index = 2;
			this.zoomInMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoomInMenuItem.Shortcut")));
			this.zoomInMenuItem.ShowShortcut = ((bool)(resources.GetObject("zoomInMenuItem.ShowShortcut")));
			this.zoomInMenuItem.Text = resources.GetString("zoomInMenuItem.Text");
			this.zoomInMenuItem.Visible = ((bool)(resources.GetObject("zoomInMenuItem.Visible")));
			this.zoomInMenuItem.Click += new System.EventHandler(this.ZoomIn_Click);
			// 
			// zoomOutMenuItem
			// 
			this.zoomOutMenuItem.Enabled = ((bool)(resources.GetObject("zoomOutMenuItem.Enabled")));
			this.zoomOutMenuItem.Index = 3;
			this.zoomOutMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoomOutMenuItem.Shortcut")));
			this.zoomOutMenuItem.ShowShortcut = ((bool)(resources.GetObject("zoomOutMenuItem.ShowShortcut")));
			this.zoomOutMenuItem.Text = resources.GetString("zoomOutMenuItem.Text");
			this.zoomOutMenuItem.Visible = ((bool)(resources.GetObject("zoomOutMenuItem.Visible")));
			this.zoomOutMenuItem.Click += new System.EventHandler(this.ZoomOut_Click);
			// 
			// mScale
			// 
			this.mScale.Enabled = ((bool)(resources.GetObject("mScale.Enabled")));
			this.mScale.Index = 4;
			this.mScale.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.zoom10MenuItem,
																				   this.zoom25MenuItem,
																				   this.zoom50MenuItem,
																				   this.zoom100MenuItem,
																				   this.zoom200MenuItem,
																				   this.zoom400MenuItem,
																				   this.zoom800MenuItem});
			this.mScale.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mScale.Shortcut")));
			this.mScale.ShowShortcut = ((bool)(resources.GetObject("mScale.ShowShortcut")));
			this.mScale.Text = resources.GetString("mScale.Text");
			this.mScale.Visible = ((bool)(resources.GetObject("mScale.Visible")));
			// 
			// zoom10MenuItem
			// 
			this.zoom10MenuItem.Enabled = ((bool)(resources.GetObject("zoom10MenuItem.Enabled")));
			this.zoom10MenuItem.Index = 0;
			this.zoom10MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom10MenuItem.Shortcut")));
			this.zoom10MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom10MenuItem.ShowShortcut")));
			this.zoom10MenuItem.Text = resources.GetString("zoom10MenuItem.Text");
			this.zoom10MenuItem.Visible = ((bool)(resources.GetObject("zoom10MenuItem.Visible")));
			this.zoom10MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom25MenuItem
			// 
			this.zoom25MenuItem.Enabled = ((bool)(resources.GetObject("zoom25MenuItem.Enabled")));
			this.zoom25MenuItem.Index = 1;
			this.zoom25MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom25MenuItem.Shortcut")));
			this.zoom25MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom25MenuItem.ShowShortcut")));
			this.zoom25MenuItem.Text = resources.GetString("zoom25MenuItem.Text");
			this.zoom25MenuItem.Visible = ((bool)(resources.GetObject("zoom25MenuItem.Visible")));
			this.zoom25MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom50MenuItem
			// 
			this.zoom50MenuItem.Enabled = ((bool)(resources.GetObject("zoom50MenuItem.Enabled")));
			this.zoom50MenuItem.Index = 2;
			this.zoom50MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom50MenuItem.Shortcut")));
			this.zoom50MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom50MenuItem.ShowShortcut")));
			this.zoom50MenuItem.Text = resources.GetString("zoom50MenuItem.Text");
			this.zoom50MenuItem.Visible = ((bool)(resources.GetObject("zoom50MenuItem.Visible")));
			this.zoom50MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom100MenuItem
			// 
			this.zoom100MenuItem.Enabled = ((bool)(resources.GetObject("zoom100MenuItem.Enabled")));
			this.zoom100MenuItem.Index = 3;
			this.zoom100MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom100MenuItem.Shortcut")));
			this.zoom100MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom100MenuItem.ShowShortcut")));
			this.zoom100MenuItem.Text = resources.GetString("zoom100MenuItem.Text");
			this.zoom100MenuItem.Visible = ((bool)(resources.GetObject("zoom100MenuItem.Visible")));
			this.zoom100MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom200MenuItem
			// 
			this.zoom200MenuItem.Enabled = ((bool)(resources.GetObject("zoom200MenuItem.Enabled")));
			this.zoom200MenuItem.Index = 4;
			this.zoom200MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom200MenuItem.Shortcut")));
			this.zoom200MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom200MenuItem.ShowShortcut")));
			this.zoom200MenuItem.Text = resources.GetString("zoom200MenuItem.Text");
			this.zoom200MenuItem.Visible = ((bool)(resources.GetObject("zoom200MenuItem.Visible")));
			this.zoom200MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom400MenuItem
			// 
			this.zoom400MenuItem.Enabled = ((bool)(resources.GetObject("zoom400MenuItem.Enabled")));
			this.zoom400MenuItem.Index = 5;
			this.zoom400MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom400MenuItem.Shortcut")));
			this.zoom400MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom400MenuItem.ShowShortcut")));
			this.zoom400MenuItem.Text = resources.GetString("zoom400MenuItem.Text");
			this.zoom400MenuItem.Visible = ((bool)(resources.GetObject("zoom400MenuItem.Visible")));
			this.zoom400MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// zoom800MenuItem
			// 
			this.zoom800MenuItem.Enabled = ((bool)(resources.GetObject("zoom800MenuItem.Enabled")));
			this.zoom800MenuItem.Index = 6;
			this.zoom800MenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("zoom800MenuItem.Shortcut")));
			this.zoom800MenuItem.ShowShortcut = ((bool)(resources.GetObject("zoom800MenuItem.ShowShortcut")));
			this.zoom800MenuItem.Text = resources.GetString("zoom800MenuItem.Text");
			this.zoom800MenuItem.Visible = ((bool)(resources.GetObject("zoom800MenuItem.Visible")));
			this.zoom800MenuItem.Click += new System.EventHandler(this.menuItemZoom_Click);
			// 
			// fitMenuItem
			// 
			this.fitMenuItem.Enabled = ((bool)(resources.GetObject("fitMenuItem.Enabled")));
			this.fitMenuItem.Index = 5;
			this.fitMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("fitMenuItem.Shortcut")));
			this.fitMenuItem.ShowShortcut = ((bool)(resources.GetObject("fitMenuItem.ShowShortcut")));
			this.fitMenuItem.Text = resources.GetString("fitMenuItem.Text");
			this.fitMenuItem.Visible = ((bool)(resources.GetObject("fitMenuItem.Visible")));
			this.fitMenuItem.Click += new System.EventHandler(this.fitMenuItem_Click);
			// 
			// menuItem29
			// 
			this.menuItem29.Enabled = ((bool)(resources.GetObject("menuItem29.Enabled")));
			this.menuItem29.Index = 6;
			this.menuItem29.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem29.Shortcut")));
			this.menuItem29.ShowShortcut = ((bool)(resources.GetObject("menuItem29.ShowShortcut")));
			this.menuItem29.Text = resources.GetString("menuItem29.Text");
			this.menuItem29.Visible = ((bool)(resources.GetObject("menuItem29.Visible")));
			// 
			// menuItem3
			// 
			this.menuItem3.Enabled = ((bool)(resources.GetObject("menuItem3.Enabled")));
			this.menuItem3.Index = 7;
			this.menuItem3.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem3.Shortcut")));
			this.menuItem3.ShowShortcut = ((bool)(resources.GetObject("menuItem3.ShowShortcut")));
			this.menuItem3.Text = resources.GetString("menuItem3.Text");
			this.menuItem3.Visible = ((bool)(resources.GetObject("menuItem3.Visible")));
			this.menuItem3.Click += new System.EventHandler(this.Options_Click);
			// 
			// cADFilesMenuItem
			// 
			this.cADFilesMenuItem.Enabled = ((bool)(resources.GetObject("cADFilesMenuItem.Enabled")));
			this.cADFilesMenuItem.Index = 3;
			this.cADFilesMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							 this.colorMenuItem,
																							 this.blackMenuItem,
																							 this.whiteBackMenuItem,
																							 this.blackBackMenuItem,
																							 this.changeBackMenuItem,
																							 this.menuItem38,
																							 this.showLineWeightMenuItem,
																							 this.arcsSplitMenuItem,
																							 this.dimShowMenuItem,
																							 this.textsShowMenuItem,
																							 this.menuItem43,
																							 this.ViewMenuItem,
																							 this.orbitMenuItem});
			this.cADFilesMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("cADFilesMenuItem.Shortcut")));
			this.cADFilesMenuItem.ShowShortcut = ((bool)(resources.GetObject("cADFilesMenuItem.ShowShortcut")));
			this.cADFilesMenuItem.Text = resources.GetString("cADFilesMenuItem.Text");
			this.cADFilesMenuItem.Visible = ((bool)(resources.GetObject("cADFilesMenuItem.Visible")));
			// 
			// colorMenuItem
			// 
			this.colorMenuItem.Checked = true;
			this.colorMenuItem.Enabled = ((bool)(resources.GetObject("colorMenuItem.Enabled")));
			this.colorMenuItem.Index = 0;
			this.colorMenuItem.RadioCheck = true;
			this.colorMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("colorMenuItem.Shortcut")));
			this.colorMenuItem.ShowShortcut = ((bool)(resources.GetObject("colorMenuItem.ShowShortcut")));
			this.colorMenuItem.Text = resources.GetString("colorMenuItem.Text");
			this.colorMenuItem.Visible = ((bool)(resources.GetObject("colorMenuItem.Visible")));
			this.colorMenuItem.Click += new System.EventHandler(this.colorMenuItem_Click);
			// 
			// blackMenuItem
			// 
			this.blackMenuItem.Enabled = ((bool)(resources.GetObject("blackMenuItem.Enabled")));
			this.blackMenuItem.Index = 1;
			this.blackMenuItem.RadioCheck = true;
			this.blackMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("blackMenuItem.Shortcut")));
			this.blackMenuItem.ShowShortcut = ((bool)(resources.GetObject("blackMenuItem.ShowShortcut")));
			this.blackMenuItem.Text = resources.GetString("blackMenuItem.Text");
			this.blackMenuItem.Visible = ((bool)(resources.GetObject("blackMenuItem.Visible")));
			this.blackMenuItem.Click += new System.EventHandler(this.blackMenuItem_Click);
			// 
			// whiteBackMenuItem
			// 
			this.whiteBackMenuItem.Enabled = ((bool)(resources.GetObject("whiteBackMenuItem.Enabled")));
			this.whiteBackMenuItem.Index = 2;
			this.whiteBackMenuItem.RadioCheck = true;
			this.whiteBackMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("whiteBackMenuItem.Shortcut")));
			this.whiteBackMenuItem.ShowShortcut = ((bool)(resources.GetObject("whiteBackMenuItem.ShowShortcut")));
			this.whiteBackMenuItem.Text = resources.GetString("whiteBackMenuItem.Text");
			this.whiteBackMenuItem.Visible = ((bool)(resources.GetObject("whiteBackMenuItem.Visible")));
			this.whiteBackMenuItem.Click += new System.EventHandler(this.whiteBackMenuItem_Click);
			// 
			// blackBackMenuItem
			// 
			this.blackBackMenuItem.Enabled = ((bool)(resources.GetObject("blackBackMenuItem.Enabled")));
			this.blackBackMenuItem.Index = 3;
			this.blackBackMenuItem.RadioCheck = true;
			this.blackBackMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("blackBackMenuItem.Shortcut")));
			this.blackBackMenuItem.ShowShortcut = ((bool)(resources.GetObject("blackBackMenuItem.ShowShortcut")));
			this.blackBackMenuItem.Text = resources.GetString("blackBackMenuItem.Text");
			this.blackBackMenuItem.Visible = ((bool)(resources.GetObject("blackBackMenuItem.Visible")));
			this.blackBackMenuItem.Click += new System.EventHandler(this.blackBackMenuItem_Click);
			// 
			// changeBackMenuItem
			// 
			this.changeBackMenuItem.Enabled = ((bool)(resources.GetObject("changeBackMenuItem.Enabled")));
			this.changeBackMenuItem.Index = 4;
			this.changeBackMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("changeBackMenuItem.Shortcut")));
			this.changeBackMenuItem.ShowShortcut = ((bool)(resources.GetObject("changeBackMenuItem.ShowShortcut")));
			this.changeBackMenuItem.Text = resources.GetString("changeBackMenuItem.Text");
			this.changeBackMenuItem.Visible = ((bool)(resources.GetObject("changeBackMenuItem.Visible")));
			this.changeBackMenuItem.Click += new System.EventHandler(this.changeBackMenuItem_Click);
			// 
			// menuItem38
			// 
			this.menuItem38.Enabled = ((bool)(resources.GetObject("menuItem38.Enabled")));
			this.menuItem38.Index = 5;
			this.menuItem38.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem38.Shortcut")));
			this.menuItem38.ShowShortcut = ((bool)(resources.GetObject("menuItem38.ShowShortcut")));
			this.menuItem38.Text = resources.GetString("menuItem38.Text");
			this.menuItem38.Visible = ((bool)(resources.GetObject("menuItem38.Visible")));
			// 
			// showLineWeightMenuItem
			// 
			this.showLineWeightMenuItem.Checked = true;
			this.showLineWeightMenuItem.Enabled = ((bool)(resources.GetObject("showLineWeightMenuItem.Enabled")));
			this.showLineWeightMenuItem.Index = 6;
			this.showLineWeightMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("showLineWeightMenuItem.Shortcut")));
			this.showLineWeightMenuItem.ShowShortcut = ((bool)(resources.GetObject("showLineWeightMenuItem.ShowShortcut")));
			this.showLineWeightMenuItem.Text = resources.GetString("showLineWeightMenuItem.Text");
			this.showLineWeightMenuItem.Visible = ((bool)(resources.GetObject("showLineWeightMenuItem.Visible")));
			// 
			// arcsSplitMenuItem
			// 
			this.arcsSplitMenuItem.Checked = true;
			this.arcsSplitMenuItem.Enabled = ((bool)(resources.GetObject("arcsSplitMenuItem.Enabled")));
			this.arcsSplitMenuItem.Index = 7;
			this.arcsSplitMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("arcsSplitMenuItem.Shortcut")));
			this.arcsSplitMenuItem.ShowShortcut = ((bool)(resources.GetObject("arcsSplitMenuItem.ShowShortcut")));
			this.arcsSplitMenuItem.Text = resources.GetString("arcsSplitMenuItem.Text");
			this.arcsSplitMenuItem.Visible = ((bool)(resources.GetObject("arcsSplitMenuItem.Visible")));
			// 
			// dimShowMenuItem
			// 
			this.dimShowMenuItem.Checked = true;
			this.dimShowMenuItem.Enabled = ((bool)(resources.GetObject("dimShowMenuItem.Enabled")));
			this.dimShowMenuItem.Index = 8;
			this.dimShowMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("dimShowMenuItem.Shortcut")));
			this.dimShowMenuItem.ShowShortcut = ((bool)(resources.GetObject("dimShowMenuItem.ShowShortcut")));
			this.dimShowMenuItem.Text = resources.GetString("dimShowMenuItem.Text");
			this.dimShowMenuItem.Visible = ((bool)(resources.GetObject("dimShowMenuItem.Visible")));
			this.dimShowMenuItem.Click += new System.EventHandler(this.dimShowMenuItem_Click);
			// 
			// textsShowMenuItem
			// 
			this.textsShowMenuItem.Checked = true;
			this.textsShowMenuItem.Enabled = ((bool)(resources.GetObject("textsShowMenuItem.Enabled")));
			this.textsShowMenuItem.Index = 9;
			this.textsShowMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("textsShowMenuItem.Shortcut")));
			this.textsShowMenuItem.ShowShortcut = ((bool)(resources.GetObject("textsShowMenuItem.ShowShortcut")));
			this.textsShowMenuItem.Text = resources.GetString("textsShowMenuItem.Text");
			this.textsShowMenuItem.Visible = ((bool)(resources.GetObject("textsShowMenuItem.Visible")));
			this.textsShowMenuItem.Click += new System.EventHandler(this.textsShowMenuItem_Click);
			// 
			// menuItem43
			// 
			this.menuItem43.Enabled = ((bool)(resources.GetObject("menuItem43.Enabled")));
			this.menuItem43.Index = 10;
			this.menuItem43.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem43.Shortcut")));
			this.menuItem43.ShowShortcut = ((bool)(resources.GetObject("menuItem43.ShowShortcut")));
			this.menuItem43.Text = resources.GetString("menuItem43.Text");
			this.menuItem43.Visible = ((bool)(resources.GetObject("menuItem43.Visible")));
			// 
			// ViewMenuItem
			// 
			this.ViewMenuItem.Enabled = ((bool)(resources.GetObject("ViewMenuItem.Enabled")));
			this.ViewMenuItem.Index = 11;
			this.ViewMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.InitMenuItem,
																						 this.topMenuItem,
																						 this.bottomMenuItem,
																						 this.leftMenuItem,
																						 this.rightMenuItem,
																						 this.frontMenuItem,
																						 this.backMenuItem,
																						 this.swMenuItem,
																						 this.seMenuItem,
																						 this.neMenuItem,
																						 this.nwMenuItem});
			this.ViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("ViewMenuItem.Shortcut")));
			this.ViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("ViewMenuItem.ShowShortcut")));
			this.ViewMenuItem.Text = resources.GetString("ViewMenuItem.Text");
			this.ViewMenuItem.Visible = ((bool)(resources.GetObject("ViewMenuItem.Visible")));
			// 
			// InitMenuItem
			// 
			this.InitMenuItem.Enabled = ((bool)(resources.GetObject("InitMenuItem.Enabled")));
			this.InitMenuItem.Index = 0;
			this.InitMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("InitMenuItem.Shortcut")));
			this.InitMenuItem.ShowShortcut = ((bool)(resources.GetObject("InitMenuItem.ShowShortcut")));
			this.InitMenuItem.Text = resources.GetString("InitMenuItem.Text");
			this.InitMenuItem.Visible = ((bool)(resources.GetObject("InitMenuItem.Visible")));
			this.InitMenuItem.Click += new System.EventHandler(this.InitialViewMenuItem_Click);
			// 
			// topMenuItem
			// 
			this.topMenuItem.Enabled = ((bool)(resources.GetObject("topMenuItem.Enabled")));
			this.topMenuItem.Index = 1;
			this.topMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("topMenuItem.Shortcut")));
			this.topMenuItem.ShowShortcut = ((bool)(resources.GetObject("topMenuItem.ShowShortcut")));
			this.topMenuItem.Text = resources.GetString("topMenuItem.Text");
			this.topMenuItem.Visible = ((bool)(resources.GetObject("topMenuItem.Visible")));
			this.topMenuItem.Click += new System.EventHandler(this.TopViewMenuItem_Click);
			// 
			// bottomMenuItem
			// 
			this.bottomMenuItem.Enabled = ((bool)(resources.GetObject("bottomMenuItem.Enabled")));
			this.bottomMenuItem.Index = 2;
			this.bottomMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("bottomMenuItem.Shortcut")));
			this.bottomMenuItem.ShowShortcut = ((bool)(resources.GetObject("bottomMenuItem.ShowShortcut")));
			this.bottomMenuItem.Text = resources.GetString("bottomMenuItem.Text");
			this.bottomMenuItem.Visible = ((bool)(resources.GetObject("bottomMenuItem.Visible")));
			this.bottomMenuItem.Click += new System.EventHandler(this.BottomViewMenuItem_Click);
			// 
			// leftMenuItem
			// 
			this.leftMenuItem.Enabled = ((bool)(resources.GetObject("leftMenuItem.Enabled")));
			this.leftMenuItem.Index = 3;
			this.leftMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("leftMenuItem.Shortcut")));
			this.leftMenuItem.ShowShortcut = ((bool)(resources.GetObject("leftMenuItem.ShowShortcut")));
			this.leftMenuItem.Text = resources.GetString("leftMenuItem.Text");
			this.leftMenuItem.Visible = ((bool)(resources.GetObject("leftMenuItem.Visible")));
			this.leftMenuItem.Click += new System.EventHandler(this.LeftViewMenuItem_Click);
			// 
			// rightMenuItem
			// 
			this.rightMenuItem.Enabled = ((bool)(resources.GetObject("rightMenuItem.Enabled")));
			this.rightMenuItem.Index = 4;
			this.rightMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("rightMenuItem.Shortcut")));
			this.rightMenuItem.ShowShortcut = ((bool)(resources.GetObject("rightMenuItem.ShowShortcut")));
			this.rightMenuItem.Text = resources.GetString("rightMenuItem.Text");
			this.rightMenuItem.Visible = ((bool)(resources.GetObject("rightMenuItem.Visible")));
			this.rightMenuItem.Click += new System.EventHandler(this.RightViewMenuItem_Click);
			// 
			// frontMenuItem
			// 
			this.frontMenuItem.Enabled = ((bool)(resources.GetObject("frontMenuItem.Enabled")));
			this.frontMenuItem.Index = 5;
			this.frontMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("frontMenuItem.Shortcut")));
			this.frontMenuItem.ShowShortcut = ((bool)(resources.GetObject("frontMenuItem.ShowShortcut")));
			this.frontMenuItem.Text = resources.GetString("frontMenuItem.Text");
			this.frontMenuItem.Visible = ((bool)(resources.GetObject("frontMenuItem.Visible")));
			this.frontMenuItem.Click += new System.EventHandler(this.FrontViewMenuItem_Click);
			// 
			// backMenuItem
			// 
			this.backMenuItem.Enabled = ((bool)(resources.GetObject("backMenuItem.Enabled")));
			this.backMenuItem.Index = 6;
			this.backMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("backMenuItem.Shortcut")));
			this.backMenuItem.ShowShortcut = ((bool)(resources.GetObject("backMenuItem.ShowShortcut")));
			this.backMenuItem.Text = resources.GetString("backMenuItem.Text");
			this.backMenuItem.Visible = ((bool)(resources.GetObject("backMenuItem.Visible")));
			this.backMenuItem.Click += new System.EventHandler(this.BackViewMenuItem_Click);
			// 
			// swMenuItem
			// 
			this.swMenuItem.Enabled = ((bool)(resources.GetObject("swMenuItem.Enabled")));
			this.swMenuItem.Index = 7;
			this.swMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("swMenuItem.Shortcut")));
			this.swMenuItem.ShowShortcut = ((bool)(resources.GetObject("swMenuItem.ShowShortcut")));
			this.swMenuItem.Text = resources.GetString("swMenuItem.Text");
			this.swMenuItem.Visible = ((bool)(resources.GetObject("swMenuItem.Visible")));
			this.swMenuItem.Click += new System.EventHandler(this.SWViewMenuItem_Click);
			// 
			// seMenuItem
			// 
			this.seMenuItem.Enabled = ((bool)(resources.GetObject("seMenuItem.Enabled")));
			this.seMenuItem.Index = 8;
			this.seMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("seMenuItem.Shortcut")));
			this.seMenuItem.ShowShortcut = ((bool)(resources.GetObject("seMenuItem.ShowShortcut")));
			this.seMenuItem.Text = resources.GetString("seMenuItem.Text");
			this.seMenuItem.Visible = ((bool)(resources.GetObject("seMenuItem.Visible")));
			this.seMenuItem.Click += new System.EventHandler(this.SEViewMenuItem_Click);
			// 
			// neMenuItem
			// 
			this.neMenuItem.Enabled = ((bool)(resources.GetObject("neMenuItem.Enabled")));
			this.neMenuItem.Index = 9;
			this.neMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("neMenuItem.Shortcut")));
			this.neMenuItem.ShowShortcut = ((bool)(resources.GetObject("neMenuItem.ShowShortcut")));
			this.neMenuItem.Text = resources.GetString("neMenuItem.Text");
			this.neMenuItem.Visible = ((bool)(resources.GetObject("neMenuItem.Visible")));
			this.neMenuItem.Click += new System.EventHandler(this.NEViewMenuItem_Click);
			// 
			// nwMenuItem
			// 
			this.nwMenuItem.Enabled = ((bool)(resources.GetObject("nwMenuItem.Enabled")));
			this.nwMenuItem.Index = 10;
			this.nwMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("nwMenuItem.Shortcut")));
			this.nwMenuItem.ShowShortcut = ((bool)(resources.GetObject("nwMenuItem.ShowShortcut")));
			this.nwMenuItem.Text = resources.GetString("nwMenuItem.Text");
			this.nwMenuItem.Visible = ((bool)(resources.GetObject("nwMenuItem.Visible")));
			this.nwMenuItem.Click += new System.EventHandler(this.NWViewMenuItem_Click);
			// 
			// orbitMenuItem
			// 
			this.orbitMenuItem.Enabled = ((bool)(resources.GetObject("orbitMenuItem.Enabled")));
			this.orbitMenuItem.Index = 12;
			this.orbitMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("orbitMenuItem.Shortcut")));
			this.orbitMenuItem.ShowShortcut = ((bool)(resources.GetObject("orbitMenuItem.ShowShortcut")));
			this.orbitMenuItem.Text = resources.GetString("orbitMenuItem.Text");
			this.orbitMenuItem.Visible = ((bool)(resources.GetObject("orbitMenuItem.Visible")));
			this.orbitMenuItem.Click += new System.EventHandler(this.orbitMenuItem_Click);
			// 
			// helpMenuItem
			// 
			this.helpMenuItem.Enabled = ((bool)(resources.GetObject("helpMenuItem.Enabled")));
			this.helpMenuItem.Index = 4;
			this.helpMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem1,
																						 this.menuItemReg,
																						 this.miFloatLic,
																						 this.aboutMenuItem});
			this.helpMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("helpMenuItem.Shortcut")));
			this.helpMenuItem.ShowShortcut = ((bool)(resources.GetObject("helpMenuItem.ShowShortcut")));
			this.helpMenuItem.Text = resources.GetString("helpMenuItem.Text");
			this.helpMenuItem.Visible = ((bool)(resources.GetObject("helpMenuItem.Visible")));
			// 
			// menuItem1
			// 
			this.menuItem1.Enabled = ((bool)(resources.GetObject("menuItem1.Enabled")));
			this.menuItem1.Index = 0;
			this.menuItem1.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItem1.Shortcut")));
			this.menuItem1.ShowShortcut = ((bool)(resources.GetObject("menuItem1.ShowShortcut")));
			this.menuItem1.Text = resources.GetString("menuItem1.Text");
			this.menuItem1.Visible = ((bool)(resources.GetObject("menuItem1.Visible")));
			// 
			// menuItemReg
			// 
			this.menuItemReg.Enabled = ((bool)(resources.GetObject("menuItemReg.Enabled")));
			this.menuItemReg.Index = 1;
			this.menuItemReg.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("menuItemReg.Shortcut")));
			this.menuItemReg.ShowShortcut = ((bool)(resources.GetObject("menuItemReg.ShowShortcut")));
			this.menuItemReg.Text = resources.GetString("menuItemReg.Text");
			this.menuItemReg.Visible = ((bool)(resources.GetObject("menuItemReg.Visible")));
			this.menuItemReg.Click += new System.EventHandler(this.toolMenuItem_Click);
			// 
			// miFloatLic
			// 
			this.miFloatLic.Enabled = ((bool)(resources.GetObject("miFloatLic.Enabled")));
			this.miFloatLic.Index = 2;
			this.miFloatLic.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("miFloatLic.Shortcut")));
			this.miFloatLic.ShowShortcut = ((bool)(resources.GetObject("miFloatLic.ShowShortcut")));
			this.miFloatLic.Text = resources.GetString("miFloatLic.Text");
			this.miFloatLic.Visible = ((bool)(resources.GetObject("miFloatLic.Visible")));
			this.miFloatLic.Click += new System.EventHandler(this.miFloatLic_Click);
			// 
			// aboutMenuItem
			// 
			this.aboutMenuItem.Enabled = ((bool)(resources.GetObject("aboutMenuItem.Enabled")));
			this.aboutMenuItem.Index = 3;
			this.aboutMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("aboutMenuItem.Shortcut")));
			this.aboutMenuItem.ShowShortcut = ((bool)(resources.GetObject("aboutMenuItem.ShowShortcut")));
			this.aboutMenuItem.Text = resources.GetString("aboutMenuItem.Text");
			this.aboutMenuItem.Visible = ((bool)(resources.GetObject("aboutMenuItem.Visible")));
			this.aboutMenuItem.Click += new System.EventHandler(this.aboutMenuItem_Click);
			// 
			// tlbTool
			// 
			this.tlbTool.AccessibleDescription = resources.GetString("tlbTool.AccessibleDescription");
			this.tlbTool.AccessibleName = resources.GetString("tlbTool.AccessibleName");
			this.tlbTool.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("tlbTool.Anchor")));
			this.tlbTool.Appearance = ((System.Windows.Forms.ToolBarAppearance)(resources.GetObject("tlbTool.Appearance")));
			this.tlbTool.AutoSize = ((bool)(resources.GetObject("tlbTool.AutoSize")));
			this.tlbTool.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tlbTool.BackgroundImage")));
			this.tlbTool.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tlbTool.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.tlbOpen,
																					   this.tlbMergeFiles,
																					   this.tlbZoomIn,
																					   this.tlbZoomOut,
																					   this.tlbSave,
																					   this.tlbWhite,
																					   this.tlbBlack,
																					   this.tlbColor,
																					   this.tlb3d,
																					   this.tlbOSX,
																					   this.tlbBlackMode,
																					   this.tlbColorMode,
																					   this.tlbDefSize,
																					   this.tlbTextShow,
																					   this.tlbDimShow,
																					   this.tlbSaveImageClip,
																					   this.tlbPrint,
																					   this.tlbRect});
			this.tlbTool.ButtonSize = ((System.Drawing.Size)(resources.GetObject("tlbTool.ButtonSize")));
			this.tlbTool.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("tlbTool.Dock")));
			this.tlbTool.DropDownArrows = ((bool)(resources.GetObject("tlbTool.DropDownArrows")));
			this.tlbTool.Enabled = ((bool)(resources.GetObject("tlbTool.Enabled")));
			this.tlbTool.Font = ((System.Drawing.Font)(resources.GetObject("tlbTool.Font")));
			this.tlbTool.ImageList = this.toolBtnImageList;
			this.tlbTool.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("tlbTool.ImeMode")));
			this.tlbTool.Location = ((System.Drawing.Point)(resources.GetObject("tlbTool.Location")));
			this.tlbTool.Name = "tlbTool";
			this.tlbTool.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("tlbTool.RightToLeft")));
			this.tlbTool.ShowToolTips = ((bool)(resources.GetObject("tlbTool.ShowToolTips")));
			this.tlbTool.Size = ((System.Drawing.Size)(resources.GetObject("tlbTool.Size")));
			this.tlbTool.TabIndex = ((int)(resources.GetObject("tlbTool.TabIndex")));
			this.tlbTool.TextAlign = ((System.Windows.Forms.ToolBarTextAlign)(resources.GetObject("tlbTool.TextAlign")));
			this.tlbTool.Visible = ((bool)(resources.GetObject("tlbTool.Visible")));
			this.tlbTool.Wrappable = ((bool)(resources.GetObject("tlbTool.Wrappable")));
			this.tlbTool.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tlbTool_ButtonClick);
			// 
			// tlbOpen
			// 
			this.tlbOpen.Enabled = ((bool)(resources.GetObject("tlbOpen.Enabled")));
			this.tlbOpen.ImageIndex = ((int)(resources.GetObject("tlbOpen.ImageIndex")));
			this.tlbOpen.Text = resources.GetString("tlbOpen.Text");
			this.tlbOpen.ToolTipText = resources.GetString("tlbOpen.ToolTipText");
			this.tlbOpen.Visible = ((bool)(resources.GetObject("tlbOpen.Visible")));
			// 
			// tlbMergeFiles
			// 
			this.tlbMergeFiles.Enabled = ((bool)(resources.GetObject("tlbMergeFiles.Enabled")));
			this.tlbMergeFiles.ImageIndex = ((int)(resources.GetObject("tlbMergeFiles.ImageIndex")));
			this.tlbMergeFiles.Tag = "";
			this.tlbMergeFiles.Text = resources.GetString("tlbMergeFiles.Text");
			this.tlbMergeFiles.ToolTipText = resources.GetString("tlbMergeFiles.ToolTipText");
			this.tlbMergeFiles.Visible = ((bool)(resources.GetObject("tlbMergeFiles.Visible")));
			// 
			// tlbZoomIn
			// 
			this.tlbZoomIn.Enabled = ((bool)(resources.GetObject("tlbZoomIn.Enabled")));
			this.tlbZoomIn.ImageIndex = ((int)(resources.GetObject("tlbZoomIn.ImageIndex")));
			this.tlbZoomIn.Text = resources.GetString("tlbZoomIn.Text");
			this.tlbZoomIn.ToolTipText = resources.GetString("tlbZoomIn.ToolTipText");
			this.tlbZoomIn.Visible = ((bool)(resources.GetObject("tlbZoomIn.Visible")));
			// 
			// tlbZoomOut
			// 
			this.tlbZoomOut.Enabled = ((bool)(resources.GetObject("tlbZoomOut.Enabled")));
			this.tlbZoomOut.ImageIndex = ((int)(resources.GetObject("tlbZoomOut.ImageIndex")));
			this.tlbZoomOut.Text = resources.GetString("tlbZoomOut.Text");
			this.tlbZoomOut.ToolTipText = resources.GetString("tlbZoomOut.ToolTipText");
			this.tlbZoomOut.Visible = ((bool)(resources.GetObject("tlbZoomOut.Visible")));
			// 
			// tlbSave
			// 
			this.tlbSave.Enabled = ((bool)(resources.GetObject("tlbSave.Enabled")));
			this.tlbSave.ImageIndex = ((int)(resources.GetObject("tlbSave.ImageIndex")));
			this.tlbSave.Text = resources.GetString("tlbSave.Text");
			this.tlbSave.ToolTipText = resources.GetString("tlbSave.ToolTipText");
			this.tlbSave.Visible = ((bool)(resources.GetObject("tlbSave.Visible")));
			// 
			// tlbWhite
			// 
			this.tlbWhite.Enabled = ((bool)(resources.GetObject("tlbWhite.Enabled")));
			this.tlbWhite.ImageIndex = ((int)(resources.GetObject("tlbWhite.ImageIndex")));
			this.tlbWhite.Text = resources.GetString("tlbWhite.Text");
			this.tlbWhite.ToolTipText = resources.GetString("tlbWhite.ToolTipText");
			this.tlbWhite.Visible = ((bool)(resources.GetObject("tlbWhite.Visible")));
			// 
			// tlbBlack
			// 
			this.tlbBlack.Enabled = ((bool)(resources.GetObject("tlbBlack.Enabled")));
			this.tlbBlack.ImageIndex = ((int)(resources.GetObject("tlbBlack.ImageIndex")));
			this.tlbBlack.Text = resources.GetString("tlbBlack.Text");
			this.tlbBlack.ToolTipText = resources.GetString("tlbBlack.ToolTipText");
			this.tlbBlack.Visible = ((bool)(resources.GetObject("tlbBlack.Visible")));
			// 
			// tlbColor
			// 
			this.tlbColor.Enabled = ((bool)(resources.GetObject("tlbColor.Enabled")));
			this.tlbColor.ImageIndex = ((int)(resources.GetObject("tlbColor.ImageIndex")));
			this.tlbColor.Text = resources.GetString("tlbColor.Text");
			this.tlbColor.ToolTipText = resources.GetString("tlbColor.ToolTipText");
			this.tlbColor.Visible = ((bool)(resources.GetObject("tlbColor.Visible")));
			// 
			// tlb3d
			// 
			this.tlb3d.DropDownMenu = this.orbitViewMenu;
			this.tlb3d.Enabled = ((bool)(resources.GetObject("tlb3d.Enabled")));
			this.tlb3d.ImageIndex = ((int)(resources.GetObject("tlb3d.ImageIndex")));
			this.tlb3d.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.tlb3d.Text = resources.GetString("tlb3d.Text");
			this.tlb3d.ToolTipText = resources.GetString("tlb3d.ToolTipText");
			this.tlb3d.Visible = ((bool)(resources.GetObject("tlb3d.Visible")));
			// 
			// orbitViewMenu
			// 
			this.orbitViewMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.InitialViewMenuItem,
																						  this.TopViewMenuItem,
																						  this.BottomViewMenuItem,
																						  this.LeftViewMenuItem,
																						  this.RightViewMenuItem,
																						  this.FrontViewMenuItem,
																						  this.BackViewMenuItem,
																						  this.SWViewMenuItem,
																						  this.SEViewMenuItem,
																						  this.NEViewMenuItem,
																						  this.NWViewMenuItem});
			this.orbitViewMenu.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("orbitViewMenu.RightToLeft")));
			// 
			// InitialViewMenuItem
			// 
			this.InitialViewMenuItem.Enabled = ((bool)(resources.GetObject("InitialViewMenuItem.Enabled")));
			this.InitialViewMenuItem.Index = 0;
			this.InitialViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("InitialViewMenuItem.Shortcut")));
			this.InitialViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("InitialViewMenuItem.ShowShortcut")));
			this.InitialViewMenuItem.Text = resources.GetString("InitialViewMenuItem.Text");
			this.InitialViewMenuItem.Visible = ((bool)(resources.GetObject("InitialViewMenuItem.Visible")));
			this.InitialViewMenuItem.Click += new System.EventHandler(this.InitialViewMenuItem_Click);
			// 
			// TopViewMenuItem
			// 
			this.TopViewMenuItem.Enabled = ((bool)(resources.GetObject("TopViewMenuItem.Enabled")));
			this.TopViewMenuItem.Index = 1;
			this.TopViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("TopViewMenuItem.Shortcut")));
			this.TopViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("TopViewMenuItem.ShowShortcut")));
			this.TopViewMenuItem.Text = resources.GetString("TopViewMenuItem.Text");
			this.TopViewMenuItem.Visible = ((bool)(resources.GetObject("TopViewMenuItem.Visible")));
			this.TopViewMenuItem.Click += new System.EventHandler(this.TopViewMenuItem_Click);
			// 
			// BottomViewMenuItem
			// 
			this.BottomViewMenuItem.Enabled = ((bool)(resources.GetObject("BottomViewMenuItem.Enabled")));
			this.BottomViewMenuItem.Index = 2;
			this.BottomViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("BottomViewMenuItem.Shortcut")));
			this.BottomViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("BottomViewMenuItem.ShowShortcut")));
			this.BottomViewMenuItem.Text = resources.GetString("BottomViewMenuItem.Text");
			this.BottomViewMenuItem.Visible = ((bool)(resources.GetObject("BottomViewMenuItem.Visible")));
			this.BottomViewMenuItem.Click += new System.EventHandler(this.BottomViewMenuItem_Click);
			// 
			// LeftViewMenuItem
			// 
			this.LeftViewMenuItem.Enabled = ((bool)(resources.GetObject("LeftViewMenuItem.Enabled")));
			this.LeftViewMenuItem.Index = 3;
			this.LeftViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("LeftViewMenuItem.Shortcut")));
			this.LeftViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("LeftViewMenuItem.ShowShortcut")));
			this.LeftViewMenuItem.Text = resources.GetString("LeftViewMenuItem.Text");
			this.LeftViewMenuItem.Visible = ((bool)(resources.GetObject("LeftViewMenuItem.Visible")));
			this.LeftViewMenuItem.Click += new System.EventHandler(this.LeftViewMenuItem_Click);
			// 
			// RightViewMenuItem
			// 
			this.RightViewMenuItem.Enabled = ((bool)(resources.GetObject("RightViewMenuItem.Enabled")));
			this.RightViewMenuItem.Index = 4;
			this.RightViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("RightViewMenuItem.Shortcut")));
			this.RightViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("RightViewMenuItem.ShowShortcut")));
			this.RightViewMenuItem.Text = resources.GetString("RightViewMenuItem.Text");
			this.RightViewMenuItem.Visible = ((bool)(resources.GetObject("RightViewMenuItem.Visible")));
			this.RightViewMenuItem.Click += new System.EventHandler(this.RightViewMenuItem_Click);
			// 
			// FrontViewMenuItem
			// 
			this.FrontViewMenuItem.Enabled = ((bool)(resources.GetObject("FrontViewMenuItem.Enabled")));
			this.FrontViewMenuItem.Index = 5;
			this.FrontViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("FrontViewMenuItem.Shortcut")));
			this.FrontViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("FrontViewMenuItem.ShowShortcut")));
			this.FrontViewMenuItem.Text = resources.GetString("FrontViewMenuItem.Text");
			this.FrontViewMenuItem.Visible = ((bool)(resources.GetObject("FrontViewMenuItem.Visible")));
			this.FrontViewMenuItem.Click += new System.EventHandler(this.FrontViewMenuItem_Click);
			// 
			// BackViewMenuItem
			// 
			this.BackViewMenuItem.Enabled = ((bool)(resources.GetObject("BackViewMenuItem.Enabled")));
			this.BackViewMenuItem.Index = 6;
			this.BackViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("BackViewMenuItem.Shortcut")));
			this.BackViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("BackViewMenuItem.ShowShortcut")));
			this.BackViewMenuItem.Text = resources.GetString("BackViewMenuItem.Text");
			this.BackViewMenuItem.Visible = ((bool)(resources.GetObject("BackViewMenuItem.Visible")));
			this.BackViewMenuItem.Click += new System.EventHandler(this.BackViewMenuItem_Click);
			// 
			// SWViewMenuItem
			// 
			this.SWViewMenuItem.Enabled = ((bool)(resources.GetObject("SWViewMenuItem.Enabled")));
			this.SWViewMenuItem.Index = 7;
			this.SWViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("SWViewMenuItem.Shortcut")));
			this.SWViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("SWViewMenuItem.ShowShortcut")));
			this.SWViewMenuItem.Text = resources.GetString("SWViewMenuItem.Text");
			this.SWViewMenuItem.Visible = ((bool)(resources.GetObject("SWViewMenuItem.Visible")));
			this.SWViewMenuItem.Click += new System.EventHandler(this.SWViewMenuItem_Click);
			// 
			// SEViewMenuItem
			// 
			this.SEViewMenuItem.Enabled = ((bool)(resources.GetObject("SEViewMenuItem.Enabled")));
			this.SEViewMenuItem.Index = 8;
			this.SEViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("SEViewMenuItem.Shortcut")));
			this.SEViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("SEViewMenuItem.ShowShortcut")));
			this.SEViewMenuItem.Text = resources.GetString("SEViewMenuItem.Text");
			this.SEViewMenuItem.Visible = ((bool)(resources.GetObject("SEViewMenuItem.Visible")));
			this.SEViewMenuItem.Click += new System.EventHandler(this.SEViewMenuItem_Click);
			// 
			// NEViewMenuItem
			// 
			this.NEViewMenuItem.Enabled = ((bool)(resources.GetObject("NEViewMenuItem.Enabled")));
			this.NEViewMenuItem.Index = 9;
			this.NEViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("NEViewMenuItem.Shortcut")));
			this.NEViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("NEViewMenuItem.ShowShortcut")));
			this.NEViewMenuItem.Text = resources.GetString("NEViewMenuItem.Text");
			this.NEViewMenuItem.Visible = ((bool)(resources.GetObject("NEViewMenuItem.Visible")));
			this.NEViewMenuItem.Click += new System.EventHandler(this.NEViewMenuItem_Click);
			// 
			// NWViewMenuItem
			// 
			this.NWViewMenuItem.Enabled = ((bool)(resources.GetObject("NWViewMenuItem.Enabled")));
			this.NWViewMenuItem.Index = 10;
			this.NWViewMenuItem.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("NWViewMenuItem.Shortcut")));
			this.NWViewMenuItem.ShowShortcut = ((bool)(resources.GetObject("NWViewMenuItem.ShowShortcut")));
			this.NWViewMenuItem.Text = resources.GetString("NWViewMenuItem.Text");
			this.NWViewMenuItem.Visible = ((bool)(resources.GetObject("NWViewMenuItem.Visible")));
			this.NWViewMenuItem.Click += new System.EventHandler(this.NWViewMenuItem_Click);
			// 
			// tlbOSX
			// 
			this.tlbOSX.Enabled = ((bool)(resources.GetObject("tlbOSX.Enabled")));
			this.tlbOSX.ImageIndex = ((int)(resources.GetObject("tlbOSX.ImageIndex")));
			this.tlbOSX.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.tlbOSX.Text = resources.GetString("tlbOSX.Text");
			this.tlbOSX.ToolTipText = resources.GetString("tlbOSX.ToolTipText");
			this.tlbOSX.Visible = ((bool)(resources.GetObject("tlbOSX.Visible")));
			// 
			// tlbBlackMode
			// 
			this.tlbBlackMode.Enabled = ((bool)(resources.GetObject("tlbBlackMode.Enabled")));
			this.tlbBlackMode.ImageIndex = ((int)(resources.GetObject("tlbBlackMode.ImageIndex")));
			this.tlbBlackMode.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.tlbBlackMode.Text = resources.GetString("tlbBlackMode.Text");
			this.tlbBlackMode.ToolTipText = resources.GetString("tlbBlackMode.ToolTipText");
			this.tlbBlackMode.Visible = ((bool)(resources.GetObject("tlbBlackMode.Visible")));
			// 
			// tlbColorMode
			// 
			this.tlbColorMode.Enabled = ((bool)(resources.GetObject("tlbColorMode.Enabled")));
			this.tlbColorMode.ImageIndex = ((int)(resources.GetObject("tlbColorMode.ImageIndex")));
			this.tlbColorMode.Pushed = true;
			this.tlbColorMode.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.tlbColorMode.Text = resources.GetString("tlbColorMode.Text");
			this.tlbColorMode.ToolTipText = resources.GetString("tlbColorMode.ToolTipText");
			this.tlbColorMode.Visible = ((bool)(resources.GetObject("tlbColorMode.Visible")));
			// 
			// tlbDefSize
			// 
			this.tlbDefSize.Enabled = ((bool)(resources.GetObject("tlbDefSize.Enabled")));
			this.tlbDefSize.ImageIndex = ((int)(resources.GetObject("tlbDefSize.ImageIndex")));
			this.tlbDefSize.Text = resources.GetString("tlbDefSize.Text");
			this.tlbDefSize.ToolTipText = resources.GetString("tlbDefSize.ToolTipText");
			this.tlbDefSize.Visible = ((bool)(resources.GetObject("tlbDefSize.Visible")));
			// 
			// tlbTextShow
			// 
			this.tlbTextShow.Enabled = ((bool)(resources.GetObject("tlbTextShow.Enabled")));
			this.tlbTextShow.ImageIndex = ((int)(resources.GetObject("tlbTextShow.ImageIndex")));
			this.tlbTextShow.Pushed = true;
			this.tlbTextShow.Text = resources.GetString("tlbTextShow.Text");
			this.tlbTextShow.ToolTipText = resources.GetString("tlbTextShow.ToolTipText");
			this.tlbTextShow.Visible = ((bool)(resources.GetObject("tlbTextShow.Visible")));
			// 
			// tlbDimShow
			// 
			this.tlbDimShow.Enabled = ((bool)(resources.GetObject("tlbDimShow.Enabled")));
			this.tlbDimShow.ImageIndex = ((int)(resources.GetObject("tlbDimShow.ImageIndex")));
			this.tlbDimShow.Pushed = true;
			this.tlbDimShow.Text = resources.GetString("tlbDimShow.Text");
			this.tlbDimShow.ToolTipText = resources.GetString("tlbDimShow.ToolTipText");
			this.tlbDimShow.Visible = ((bool)(resources.GetObject("tlbDimShow.Visible")));
			// 
			// tlbSaveImageClip
			// 
			this.tlbSaveImageClip.Enabled = ((bool)(resources.GetObject("tlbSaveImageClip.Enabled")));
			this.tlbSaveImageClip.ImageIndex = ((int)(resources.GetObject("tlbSaveImageClip.ImageIndex")));
			this.tlbSaveImageClip.Text = resources.GetString("tlbSaveImageClip.Text");
			this.tlbSaveImageClip.ToolTipText = resources.GetString("tlbSaveImageClip.ToolTipText");
			this.tlbSaveImageClip.Visible = ((bool)(resources.GetObject("tlbSaveImageClip.Visible")));
			// 
			// tlbPrint
			// 
			this.tlbPrint.Enabled = ((bool)(resources.GetObject("tlbPrint.Enabled")));
			this.tlbPrint.ImageIndex = ((int)(resources.GetObject("tlbPrint.ImageIndex")));
			this.tlbPrint.Text = resources.GetString("tlbPrint.Text");
			this.tlbPrint.ToolTipText = resources.GetString("tlbPrint.ToolTipText");
			this.tlbPrint.Visible = ((bool)(resources.GetObject("tlbPrint.Visible")));
			// 
			// tlbRect
			// 
			this.tlbRect.Enabled = ((bool)(resources.GetObject("tlbRect.Enabled")));
			this.tlbRect.ImageIndex = ((int)(resources.GetObject("tlbRect.ImageIndex")));
			this.tlbRect.Text = resources.GetString("tlbRect.Text");
			this.tlbRect.ToolTipText = resources.GetString("tlbRect.ToolTipText");
			this.tlbRect.Visible = ((bool)(resources.GetObject("tlbRect.Visible")));
			// 
			// toolBtnImageList
			// 
			this.toolBtnImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
			this.toolBtnImageList.ImageSize = ((System.Drawing.Size)(resources.GetObject("toolBtnImageList.ImageSize")));
			this.toolBtnImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolBtnImageList.ImageStream")));
			this.toolBtnImageList.TransparentColor = System.Drawing.Color.Magenta;
			// 
			// trvPanel
			// 
			this.trvPanel.AccessibleDescription = resources.GetString("trvPanel.AccessibleDescription");
			this.trvPanel.AccessibleName = resources.GetString("trvPanel.AccessibleName");
			this.trvPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("trvPanel.Anchor")));
			this.trvPanel.AutoScroll = ((bool)(resources.GetObject("trvPanel.AutoScroll")));
			this.trvPanel.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("trvPanel.AutoScrollMargin")));
			this.trvPanel.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("trvPanel.AutoScrollMinSize")));
			this.trvPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("trvPanel.BackgroundImage")));
			this.trvPanel.Controls.Add(this.trvEntity);
			this.trvPanel.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("trvPanel.Dock")));
			this.trvPanel.Enabled = ((bool)(resources.GetObject("trvPanel.Enabled")));
			this.trvPanel.Font = ((System.Drawing.Font)(resources.GetObject("trvPanel.Font")));
			this.trvPanel.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("trvPanel.ImeMode")));
			this.trvPanel.Location = ((System.Drawing.Point)(resources.GetObject("trvPanel.Location")));
			this.trvPanel.Name = "trvPanel";
			this.trvPanel.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("trvPanel.RightToLeft")));
			this.trvPanel.Size = ((System.Drawing.Size)(resources.GetObject("trvPanel.Size")));
			this.trvPanel.TabIndex = ((int)(resources.GetObject("trvPanel.TabIndex")));
			this.trvPanel.Text = resources.GetString("trvPanel.Text");
			this.trvPanel.Visible = ((bool)(resources.GetObject("trvPanel.Visible")));
			// 
			// trvEntity
			// 
			this.trvEntity.AccessibleDescription = resources.GetString("trvEntity.AccessibleDescription");
			this.trvEntity.AccessibleName = resources.GetString("trvEntity.AccessibleName");
			this.trvEntity.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("trvEntity.Anchor")));
			this.trvEntity.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("trvEntity.BackgroundImage")));
			this.trvEntity.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.trvEntity.CheckBoxes = true;
			this.trvEntity.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("trvEntity.Dock")));
			this.trvEntity.Enabled = ((bool)(resources.GetObject("trvEntity.Enabled")));
			this.trvEntity.Font = ((System.Drawing.Font)(resources.GetObject("trvEntity.Font")));
			this.trvEntity.ImageIndex = ((int)(resources.GetObject("trvEntity.ImageIndex")));
			this.trvEntity.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("trvEntity.ImeMode")));
			this.trvEntity.Indent = ((int)(resources.GetObject("trvEntity.Indent")));
			this.trvEntity.ItemHeight = ((int)(resources.GetObject("trvEntity.ItemHeight")));
			this.trvEntity.Location = ((System.Drawing.Point)(resources.GetObject("trvEntity.Location")));
			this.trvEntity.Name = "trvEntity";
			this.trvEntity.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("trvEntity.RightToLeft")));
			this.trvEntity.SelectedImageIndex = ((int)(resources.GetObject("trvEntity.SelectedImageIndex")));
			this.trvEntity.Size = ((System.Drawing.Size)(resources.GetObject("trvEntity.Size")));
			this.trvEntity.TabIndex = ((int)(resources.GetObject("trvEntity.TabIndex")));
			this.trvEntity.Text = resources.GetString("trvEntity.Text");
			this.trvEntity.Visible = ((bool)(resources.GetObject("trvEntity.Visible")));
			this.trvEntity.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.trvEntity_AfterCheck);
			// 
			// cadPictBox
			// 
			this.cadPictBox.AccessibleDescription = resources.GetString("cadPictBox.AccessibleDescription");
			this.cadPictBox.AccessibleName = resources.GetString("cadPictBox.AccessibleName");
			this.cadPictBox.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("cadPictBox.Anchor")));
			this.cadPictBox.BackColor = System.Drawing.Color.White;
			this.cadPictBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cadPictBox.BackgroundImage")));
			this.cadPictBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.cadPictBox.Cursor = System.Windows.Forms.Cursors.Default;
			this.cadPictBox.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("cadPictBox.Dock")));
			this.cadPictBox.Enabled = ((bool)(resources.GetObject("cadPictBox.Enabled")));
			this.cadPictBox.Font = ((System.Drawing.Font)(resources.GetObject("cadPictBox.Font")));
			this.cadPictBox.Image = ((System.Drawing.Image)(resources.GetObject("cadPictBox.Image")));
			this.cadPictBox.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("cadPictBox.ImeMode")));
			this.cadPictBox.Location = ((System.Drawing.Point)(resources.GetObject("cadPictBox.Location")));
			this.cadPictBox.Name = "cadPictBox";
			this.cadPictBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("cadPictBox.RightToLeft")));
			this.cadPictBox.Size = ((System.Drawing.Size)(resources.GetObject("cadPictBox.Size")));
			this.cadPictBox.SizeMode = ((System.Windows.Forms.PictureBoxSizeMode)(resources.GetObject("cadPictBox.SizeMode")));
			this.cadPictBox.TabIndex = ((int)(resources.GetObject("cadPictBox.TabIndex")));
			this.cadPictBox.TabStop = false;
			this.cadPictBox.Text = resources.GetString("cadPictBox.Text");
			this.cadPictBox.Visible = ((bool)(resources.GetObject("cadPictBox.Visible")));
			this.cadPictBox.Paint += new System.Windows.Forms.PaintEventHandler(this.cadPictBox_Paint);
			this.cadPictBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseUp);
			this.cadPictBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseMove);
			this.cadPictBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseDown);
			// 
			// splitter1
			// 
			this.splitter1.AccessibleDescription = resources.GetString("splitter1.AccessibleDescription");
			this.splitter1.AccessibleName = resources.GetString("splitter1.AccessibleName");
			this.splitter1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("splitter1.Anchor")));
			this.splitter1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("splitter1.BackgroundImage")));
			this.splitter1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("splitter1.Dock")));
			this.splitter1.Enabled = ((bool)(resources.GetObject("splitter1.Enabled")));
			this.splitter1.Font = ((System.Drawing.Font)(resources.GetObject("splitter1.Font")));
			this.splitter1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("splitter1.ImeMode")));
			this.splitter1.Location = ((System.Drawing.Point)(resources.GetObject("splitter1.Location")));
			this.splitter1.MinExtra = ((int)(resources.GetObject("splitter1.MinExtra")));
			this.splitter1.MinSize = ((int)(resources.GetObject("splitter1.MinSize")));
			this.splitter1.Name = "splitter1";
			this.splitter1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("splitter1.RightToLeft")));
			this.splitter1.Size = ((System.Drawing.Size)(resources.GetObject("splitter1.Size")));
			this.splitter1.TabIndex = ((int)(resources.GetObject("splitter1.TabIndex")));
			this.splitter1.TabStop = false;
			this.splitter1.Visible = ((bool)(resources.GetObject("splitter1.Visible")));
			this.splitter1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter1_SplitterMoved);
			// 
			// printPrevDlg
			// 
			this.printPrevDlg.AccessibleDescription = resources.GetString("printPrevDlg.AccessibleDescription");
			this.printPrevDlg.AccessibleName = resources.GetString("printPrevDlg.AccessibleName");
			this.printPrevDlg.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("printPrevDlg.Anchor")));
			this.printPrevDlg.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.AutoScaleBaseSize")));
			this.printPrevDlg.AutoScroll = ((bool)(resources.GetObject("printPrevDlg.AutoScroll")));
			this.printPrevDlg.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.AutoScrollMargin")));
			this.printPrevDlg.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.AutoScrollMinSize")));
			this.printPrevDlg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("printPrevDlg.BackgroundImage")));
			this.printPrevDlg.ClientSize = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.ClientSize")));
			this.printPrevDlg.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("printPrevDlg.Dock")));
			this.printPrevDlg.Enabled = ((bool)(resources.GetObject("printPrevDlg.Enabled")));
			this.printPrevDlg.Font = ((System.Drawing.Font)(resources.GetObject("printPrevDlg.Font")));
			this.printPrevDlg.Icon = ((System.Drawing.Icon)(resources.GetObject("printPrevDlg.Icon")));
			this.printPrevDlg.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("printPrevDlg.ImeMode")));
			this.printPrevDlg.Location = ((System.Drawing.Point)(resources.GetObject("printPrevDlg.Location1")));
			this.printPrevDlg.MaximumSize = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.MaximumSize")));
			this.printPrevDlg.MinimumSize = ((System.Drawing.Size)(resources.GetObject("printPrevDlg.MinimumSize")));
			this.printPrevDlg.Name = "printPrevDlg";
			this.printPrevDlg.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("printPrevDlg.RightToLeft")));
			this.printPrevDlg.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("printPrevDlg.StartPosition")));
			this.printPrevDlg.Text = resources.GetString("printPrevDlg.Text");
			this.printPrevDlg.TransparencyKey = System.Drawing.Color.Empty;
			this.printPrevDlg.Visible = ((bool)(resources.GetObject("printPrevDlg.Visible")));
			// 
			// openFileDlg
			// 
			this.openFileDlg.DefaultExt = "*.dxf;*.dwg";
			this.openFileDlg.Filter = resources.GetString("openFileDlg.Filter");
			this.openFileDlg.ShowHelp = true;
			this.openFileDlg.Title = resources.GetString("openFileDlg.Title");
			// 
			// saveDXFDlg
			// 
			this.saveDXFDlg.DefaultExt = "*.dxf";
			this.saveDXFDlg.Filter = resources.GetString("saveDXFDlg.Filter");
			this.saveDXFDlg.Title = resources.GetString("saveDXFDlg.Title");
			// 
			// MainForm
			// 
			this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
			this.AccessibleName = resources.GetString("$this.AccessibleName");
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackColor = System.Drawing.SystemColors.Control;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.cadPictBox);
			this.Controls.Add(this.trvPanel);
			this.Controls.Add(this.tlbTool);
			this.Controls.Add(this.stBar);
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.Menu = this.mainMenu;
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "MainForm";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Resize += new System.EventHandler(this.MainForm_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).EndInit();
			this.trvPanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		
		static MainForm()
		{
			HPGLExt = new ArrayList(new string[]{".HPG", ".PLT", ".RTL", ".SPL", ".PRN", ".GL2", ".HPGL2", ".HPGL",
													".HP2", ".HP1", ".HP", ".PLO", ".HG", ".HGL"});
		}

		[STAThread]
		static void Main(string[] args) 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Disabled;
			actForm = new MainForm();
			if(args.Length != 0)
				if(File.Exists(args[0]))
					actForm.openFileDlg.FileName = args[0];
			Application.Run(actForm);	
		}

		#region Help
		/// <summary>
		/// Adjusts the image size according to the specified scale.
		/// </summary>
		/// <param name="i">A scale value.</param>
		/// <remarks>If the scale value is more than one the image size increases; otherwise, decreases.</remarks>
		#endregion Help
		public void Zoom(float i)
		{
			if(FCADImage == null) return;
			scale = scale*i;
			if(scale < 0.005f) scale = 0.005f;	
			cadPictBox.Invalidate();
			cadPictBox_MouseMove(cadPictBox, new MouseEventArgs(MouseButtons.Left, 0, (int)old_Pos.X, (int)old_Pos.Y, 0));
			stBar.Panels[1].Text = "" + scale;
		}

		private void Shift()
		{
			pos.X = old_Pos.X - (old_Pos.X - pos.X)*scale / prev_scale;
			pos.Y = old_Pos.Y - (old_Pos.Y - pos.Y)*scale / prev_scale;
			prev_scale = scale;		
		}

		#region Help
		/// <summary>
		/// Processes Windows messages and allows the user to zoom in(out) the CAD image by mouse wheel.
		/// </summary>
		/// <param name="m">The Windows <see cref="System.Windows.Forms.Message">Message</see> to process.</param>
		#endregion Help
		protected override void WndProc(ref Message m)
		{
			if(m.Msg == 0x0112)
			{
				if(m.WParam.ToInt32() == 0xF020)
					deactiv = true;
			}
			if(m.Msg == OnMouseScroll) 
			{
				if(m.WParam.ToInt32() < 0)  Zoom(0.7f);
				else Zoom(1.3f);
			} 
			base.WndProc(ref m);
		}

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="CADImportForm.MainForm">MainForm</see> class.
		/// </summary>
		#endregion Help
		public MainForm()
		{
			curLngInd = 0;
			scale = 1;
			colorDraw = true;
			ScaleRect = new DPoint();
			old_Pos = new PointF();
			layouts = new ArrayList();
			Orb3D = new Orbit3D();
			lForm = new LayerForm();
			aboutFrm = new AboutForm();
			shxFrm = new SHXForm();
			#region protect
#if (protect && floatprotect)
			floatLicFrm = new FloatLicForm();
			floatLicFrm.Change += new System.EventHandler(InvalidateImage);
#endif
#if protect
			regFrm = new RegForm();
#endif
			#endregion protect
			optForm = new OptionsForm();
			prtForm = new PrintingForm();
			dl1 = new System.Windows.Forms.ItemCheckEventHandler(this.chLay_ItemCheck);
			InitializeComponent();
			Initial3DOrbit();
			#region protect
#if ((! floatprotect) && protect)
			this.miFloatLic.Enabled = false;
#endif
			#endregion
			//lng
			mlng = new MultipleLanguage(this.GetType());
			//Save value of NoName elements
			if(this.mainMenu != null)
				mlng.SaveNameMenuItem(this.mainMenu.MenuItems);
			if(this.ContextMenu != null)
				mlng.SaveNameMenuItem(this.ContextMenu.MenuItems);
			mlng.SaveNameNoNameElement(this.Controls);
			//Load settings
			svSet = new SaveSettings(this.fileSettingsName);
			settingsLst = svSet.LoadOptions();
			if(settingsLst != null)
			{
				string key = "LanguagePath";
				if(settingsLst.ContainsKey(key))
					MultipleLanguage.path = Convert.ToString(settingsLst[key]);
			} 
			else
			{
				MultipleLanguage.path = cnstLngPath;
			}
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			if(settingsLst == null)
				CreateNewSettingsList();
			else
				SetSettings();
			this.clipRectangle = new ClipRect(this.cadPictBox);
			this.copyMenuItem.Shortcut = Shortcut.CtrlC;
		}

		private void InvalidateImage(object sender, System.EventArgs e)
		{
			this.cadPictBox.Invalidate();
		}

		private void Initial3DOrbit()
		{
			Orb3D.Parent = this.cadPictBox;
		}
		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void Open_Click(object sender, System.EventArgs e)
		{
			LoadFile(true);	
		}

		#region Help
		/// <summary>
		/// Loads a CAD file.
		/// </summary>
		/// <param name="dlg">A value indicating if an <see cref="System.Windows.Forms.OpenFileDialog">OpenFileDialog</see> 
		/// box is invoked for selecting and loading a CAD file. <b>true</b>, if an <see cref="System.Windows.Forms.OpenFileDialog">OpenFileDialog</see> 
		/// box is invoked; otherwise, <b>false</b>.</param>
		#endregion Help
		public void LoadFile(bool dlg)
		{
			cadPictBox.Visible = false;
			lForm.lstViewLay.Items.Clear();
			lForm.lstViewLay.ItemCheck -= dl1;
			if(dlg)
				if(openFileDlg.ShowDialog() != DialogResult.OK) 
				{
					cadPictBox.Visible = true;
					return;
				}
			if (openFileDlg.FileName != null)
			{
				if(FCADImage != null)
				{	
					FCADImage.Dispose();
					FCADImage = null;
				}
				this.Cursor = Cursors.WaitCursor;
				stBar.Panels[0].Text = "Load file...";
				scale = 1;
				prev_scale = 1;
				pos = new PointF();
				string ext = Path.GetExtension(openFileDlg.FileName).ToUpper();
				if(ext == ".DWG")
				{
					#region DWGModule
#if DWGModule
					FCADImage = new DWG.DWGImage();
					LoadFile(openFileDlg.FileName, true);
#else
						NotSupportedInCurrentVersion();
						return;

#endif
					#endregion
				}
				else  if (ext == ".DXF")
				{
					FCADImage = new CADImage();
					LoadFile(openFileDlg.FileName, true);
				}
				else if(ext == ".CGM")
				{
#if UseCGM
					bool tmpshx = CADConst.UseSHXFonts;
					if(CADConst.UseSHXFonts)
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = false;
					}
					else 
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = true;
					}
					FCADImage = new CGM.CGMImage();
					LoadFile(openFileDlg.FileName, true);
#else
					NotSupportedInCurrentVersion();
					return;
#endif
				}
				else 
					if(HPGLExt.IndexOf(ext) != -1)
				{
					FCADImage = new HPGLImage();
					LoadFile(openFileDlg.FileName, true);
				}
				else
				{
					FCADImage = new CADRasterImage(this.cadPictBox);
					LoadFile(openFileDlg.FileName, true);
				}
			} 
			tlbTool.Buttons[9].Pushed = FCADImage.IsDraw3DAxes;
			tlbTool.Buttons[10].Pushed = false;
			tlbTool.Buttons[8].Pushed = false;
			tlbTool.Buttons[11].Pushed = true;
			FCADImage.UseWinEllipse = false;
			Orb3D.CADImage = FCADImage;
			Orb3D.Visible = false;
			Orb3D.Disable3dOrbit();
			EnableButton(true);
			if(cadPictBox.BackColor == Color.White)
				White_Click();
			else 
				Black_Click();
			DoResize();
			stBar.Panels[1].Text = "" + scale;
			this.Cursor = Cursors.Default;
			if(this.trvPanel.Visible == true)
				CADImportFace.LoadTreeNodes(trvEntity.Nodes, FCADImage);
			if(this.colorDraw == false)
				this.DoBlackColor();
		}

		private void NotSupportedInCurrentVersion()
		{
			this.Cursor = Cursors.Default;
			cadPictBox.Visible = true;
			stBar.Panels[0].Text = "not supported";
			MessageBox.Show("Not supported in current version!", "CADImport .Net");
			return;
		}
		
		private void LoadFile(string fileName, bool det3dBt)
		{
			stBar.Panels[0].Text = Path.GetFileName(fileName) + " - ";
			FCADImage.LoadFromFile(fileName);
		}


		#region Help
		/// <summary>
		/// Loads an empty image into the <see cref="CADImportForm.MainForm">MainForm</see>.
		/// </summary>
		#endregion Help
		public void LoadEmptyImage()
		{
			cadPictBox.Visible = false;
			lForm.lstViewLay.Items.Clear();
			lForm.lstViewLay.ItemCheck -= dl1;
			
			if(FCADImage != null)
			{	
				FCADImage.Dispose();
				FCADImage = null;
			}
			this.Cursor = Cursors.WaitCursor;
			stBar.Panels[0].Text = "Load file...";
			scale = 1;
			prev_scale = 1;
			pos = new PointF();
			FCADImage = new CADImage();
			tlbTool.Buttons[9].Pushed = FCADImage.IsDraw3DAxes;
			tlbTool.Buttons[10].Pushed = false;
			tlbTool.Buttons[8].Pushed = false;
			tlbTool.Buttons[11].Pushed = true;
			FCADImage.UseWinEllipse = false;
			Orb3D.CADImage = FCADImage;
			Orb3D.Visible = false;
			Orb3D.Disable3dOrbit();
			EnableButton(true);
			if(cadPictBox.BackColor == Color.White)
				White_Click();
			else 
				Black_Click();
			DoResize();
			stBar.Panels[1].Text = "" + scale;
			this.Cursor = Cursors.Default;
			if(this.trvPanel.Visible == true)
				CADImportFace.LoadTreeNodes(trvEntity.Nodes, FCADImage);
			if(this.colorDraw == false)
				this.DoBlackColor();
		}

		#region Help
		/// <summary>
		/// Loads entities of the CAD image to the entities tree.
		/// </summary>
		#endregion Help
		public void LoadTreeNodes()
		{
			if(this.trvPanel.Visible == true)
				CADImportFace.LoadTreeNodes(trvEntity.Nodes, FCADImage);
		}

		#region Help
		/// <summary>
		/// Enables or disables buttons of the toolbar and menu items of the main menu.
		/// </summary>
		/// <param name="aVal"><b>true</b> if to enable the buttons and menu items; <b>false</b> if to disable them.</param>
		/// <remarks>The buttons and menu items are enabled after loading a CAD file and become disabled after closing the file.</remarks>
		#endregion Help
		public void EnableButton(bool aVal)
		{
			for(int i = 1; i < 18; i++)
				tlbTool.Buttons[i].Enabled = aVal;
			mScale.Enabled = aVal;
			mSaveFile.Enabled = aVal;
			cadPictBox.Visible = aVal;
			copyMenuItem.Enabled = aVal;
			zoomInMenuItem.Enabled = aVal;
			zoomOutMenuItem.Enabled = aVal;
			fitMenuItem.Enabled = aVal;
			colorMenuItem.Enabled = aVal;
			blackMenuItem.Enabled = aVal;
			whiteBackMenuItem.Enabled = aVal;
			blackBackMenuItem.Enabled = aVal;
			changeBackMenuItem.Enabled = aVal;
			showLineWeightMenuItem.Enabled = aVal;
			arcsSplitMenuItem.Enabled = aVal;
			dimShowMenuItem.Enabled = aVal;
			textsShowMenuItem.Enabled = aVal;
			ViewMenuItem.Enabled = aVal;
			orbitMenuItem.Enabled = aVal;
			closeMenuItem.Enabled = aVal;
			printMenuItem.Enabled = aVal;
			printprevItem.Enabled = aVal;
			print2Item.Enabled = aVal;
			#if Export
				this.mnSaveAsDXF.Enabled = aVal;
			#endif
		}

		private void ZoomIn_Click(object sender, System.EventArgs e)
		{
			DoZoomIn();
		}

		#region Help
		/// <summary>
		/// Increases a scale of the CAD image in two times.
		/// </summary>
		#endregion Help
		public void DoZoomIn()
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = scale * 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void ZoomOut_Click(object sender, System.EventArgs e)
		{
			DoZoomOut();
		}

		#region Help
		/// <summary>
		/// Decreases a scale of the CAD image in two times.
		/// </summary>
		#endregion Help
		public void DoZoomOut()
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = scale / 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void cadPictBox_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			DrawCADImage(e.Graphics);
		}

		#region Help
		/// <summary>
		/// Draws a CAD image from the loaded CAD file.
		/// </summary>
		/// <param name="gr">A <see cref="System.Drawing.Graphics">Graphics</see> object used to draw the CAD entities.</param>
		#endregion Help
		public void DrawCADImage(Graphics gr)
		{
			if(FCADImage == null) return;
			try
			{
				deactiv = false;
				Shift();
				RectangleF tmp = new RectangleF(pos.X, pos.Y, curClRect.Width*scale,
					curClRect.Height*scale);
				FCADImage.Draw(gr, tmp);		
			}
			catch(Exception e)
			{ 
				#region Debug
				#if DEBUG
					MessageBox.Show("Message [" + e.Message + "]" + (char)13 + e.StackTrace, "CADImport Net debug", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				#endif	
				#endregion Debug
				return;
			}
		}

		private void cadPictBox_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			det1 = false;
			cadPictBox.Cursor = Cursors.Default;
			if(this.clipRectangle.Enabled)
				if((this.clipRectangle.Type == RectangleType.Zooming))
				{
					if((this.clipRectangle.ClientRectangle.Width <= 5)||
						(this.clipRectangle.ClientRectangle.Height <= 5)) { cadPictBox.Invalidate(); return; }
					if(this.scale > 1000) { cadPictBox.Invalidate(); return; }
					float tmp1 = this.curClRect.Width / this.clipRectangle.ClientRectangle.Width;
					float tmp2 = this.curClRect.Height / this.clipRectangle.ClientRectangle.Height;
					if(tmp1 > tmp2) tmp1 = tmp2;
					pos.X += this.clipRectangle.ClientRectangle.Width / 2; 
					pos.Y += this.clipRectangle.ClientRectangle.Height / 2; 
					this.Zoom(tmp1);
				}
			cadPictBox.Invalidate();
		}

		private void cadPictBox_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if((e.Button == MouseButtons.Right)||(e.Button == MouseButtons.Middle))
			{
				MainForm.ActiveForm.Cursor = Cursors.Hand;
				cX = e.X;
				cY = e.Y;
				det1 = true;
			}
			else
			{
				if((! this.clipRectangle.Enabled)&&(this.FCADImage != null)&&(! this.Orb3D.Visible))
				{
					this.clipRectangle.EnableRect(RectangleType.Zooming, new Rectangle(e.X, e.Y, 0, 0));
				}
			}
		}

		private void cadPictBox_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			cadPictBox.Focus();
			if(FCADImage == null) return;
			if((det1)&&(!Orb3D.Visible))
			{
				pos.X -= (cX - e.X);
				pos.Y -= (cY - e.Y);
				cX = e.X;
				cY = e.Y;
				cadPictBox.Invalidate();
			}
			old_Pos = new PointF(e.X, e.Y);
			DPoint vPt = GetRealPointUsingsgImagePoint(e.X, e.Y);
			stBar.Panels[2].Text = "" + vPt.X + " : " + vPt.Y + " : 0";
		}

		private DPoint GetRealPointUsingsgImagePoint(float X, float Y)
		{
			Rectangle tmp = new Rectangle();
			tmp = curClRect;
			DRect Rect = new DRect(tmp.Left, tmp.Top,
				tmp.Right, tmp.Bottom);
			float fKoef = (float)(FCADImage.AbsHeight / FCADImage.AbsWidth);
			Rect.left = Rect.left  * scale + pos.X;
			Rect.right = Rect.right * scale + pos.X;
			Rect.top = Rect.top * scale + pos.Y;			
			Rect.bottom = Rect.top  + (Rect.right - Rect.left) *   fKoef;						
			ScaleRect.X = FCADImage.AbsWidth / (Rect.right - Rect.left);
			ScaleRect.Y = FCADImage.AbsHeight / (Rect.bottom - Rect.top);
			DPoint mousePt = new DPoint(0 ,0, 0);
			DPoint newmousePt = new DPoint(0 ,0, 0);
			DPoint pX, pY, pCenter;
			DRect DRectExtentsCAD = FCADImage.Extents;
			mousePt.X = DRectExtentsCAD.left + (X - pos.X) * ScaleRect.X;
			mousePt.Y = DRectExtentsCAD.top  - (Y - pos.Y) * ScaleRect.Y;
			pCenter.X = 0.5f * (DRectExtentsCAD.right + DRectExtentsCAD.left);
			pCenter.Y = 0.5f * (DRectExtentsCAD.top + DRectExtentsCAD.bottom);
			pCenter.Z = 0.5f * (DRectExtentsCAD.z2 + DRectExtentsCAD.z1);
			pX.X = 1; pX.Y = 0;	pX.Z = 0;
			pY.X = 0; pY.Y = 1;	pY.Z = 0;		
			pX = FCADImage.GetRealImagePoint(pX);
			pY = FCADImage.GetRealImagePoint(pY);
			MoveToPosition(ref mousePt, pCenter, -1);
			newmousePt.X = mousePt.X * pX.X + mousePt.Y * pX.Y;
			newmousePt.Y = mousePt.X * pY.X + mousePt.Y * pY.Y;
			MoveToPosition(ref newmousePt, pCenter, +1);
			return newmousePt;
		}

		private void MoveToPosition(ref DPoint point, DPoint aPos, int direction)
		{  
			point.X = point.X + direction * aPos.X;
			point.Y = point.Y + direction * aPos.Y;
			point.Z = point.Z + direction * aPos.Z;
		}

		#region Help
		/// <summary>
		/// Invokes a <see cref="System.Windows.Forms.SaveFileDialog">SaveFileDialog</see> box where 
		/// a user can select a directory and format for saving the current CAD image.
		/// </summary>
		/// <remarks><p>This method can be invoked from the toolbar and from the main menu.</p>
		/// <p>Images can be saved in the following formats: JPG, BMP, TIFF, GIF, EMF.</p></remarks>
		#endregion Help
		public void SaveAsImage()
		{
			if(FCADImage == null) return;
			if(saveImgDlg.ShowDialog() != DialogResult.OK) return;
			DRect tmpRect = new DRect(0, 0, curClRect.Width*scale, curClRect.Height*scale);
			ImageFormat imgFrm = ImageFormat.Bmp;
			if(saveImgDlg.FileName != null) 
			{
				string tmp = saveImgDlg.FileName;	
				if(tmp.ToUpper().IndexOf(".JPG") != -1)
					imgFrm = ImageFormat.Jpeg;
				if(tmp.ToUpper().IndexOf(".BMP") != -1)
					imgFrm = ImageFormat.Bmp;
				if(tmp.ToUpper().IndexOf(".TIFF") != -1)
					imgFrm = ImageFormat.Tiff;
				if(tmp.ToUpper().IndexOf(".GIF") != -1)
					imgFrm = ImageFormat.Gif;
				if(tmp.ToUpper().IndexOf(".EMF") != -1)
					imgFrm = ImageFormat.Emf;
				if(tmp.ToUpper().IndexOf(".DXF") != -1)
				{
					SaveAsDXF(saveImgDlg.FileName);
					return;
				}
			}
			if(this.clipRectangle.Enabled)
			{
				tmpRect = new DRect(pos.X, pos.Y, curClRect.Width*scale, curClRect.Height*scale);
				FCADImage.SaveToFile(saveImgDlg.FileName, imgFrm, tmpRect, this.clipRectangle.ClientRectangle);
			}
			else
			{
				if(imgFrm == ImageFormat.Emf)
					FCADImage.ExportToMetafile(saveImgDlg.FileName, actForm, tmpRect);
				else
					FCADImage.SaveToFile(saveImgDlg.FileName, imgFrm, tmpRect);
			}
			if((!(FCADImage is CADRasterImage))&&(!this.clipRectangle.Enabled))
				this.DoResize();
		}

		private void menuItemZoom_Click(object sender, System.EventArgs e)
		{
			if(FCADImage == null) return;
			float i = scale;
			switch((sender as MenuItem).Index)
			{
				case 0:
					i = 0.1f;
					break;
				case 1:
					i = 0.25f;
					break;
				case 2:
					i = 0.5f;
					break;
				case 3:
					i = 1;
					break;
				case 4:
					i = 2;
					break;
				case 5:
					i = 4;
					break;
				case 6:
					i = 8;
					break;
			}
			ResetScaling();
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = i;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		#region Help
		/// <summary>
		/// Paints the CAD image background in the white color.
		/// </summary>
		#endregion Help
		public void White_Click()
		{
			whiteBackMenuItem.Checked = true;
			blackBackMenuItem.Checked = false;
			tlbTool.Buttons[5].Pushed = true;
			tlbTool.Buttons[6].Pushed = false;
			cadPictBox.BackColor = Color.White;
			if(FCADImage != null)
				FCADImage.DefaultColor = Color.Black;
			if(this.clipRectangle != null)
				this.clipRectangle.Color = Color.Black;
		}

		#region Help
		/// <summary>
		/// Paints the CAD image background in the black color.
		/// </summary>
		#endregion Help
		public void Black_Click()
		{
			whiteBackMenuItem.Checked = false;
			blackBackMenuItem.Checked = true;
			tlbTool.Buttons[5].Pushed = false;
			tlbTool.Buttons[6].Pushed = true;
			cadPictBox.BackColor = Color.Black;
			if(FCADImage != null)
				FCADImage.DefaultColor = Color.White;
			if(this.clipRectangle != null)
				this.clipRectangle.Color = Color.White;
		}

		#region Help
		/// <summary>
		/// Paints the CAD image background in the user defined color.
		/// </summary>
		#endregion Help
		public void Color_Click()
		{
			if(setColorDlg.ShowDialog() == DialogResult.OK)
			{
				cadPictBox.BackColor = setColorDlg.Color;
			}
		}

		private void tlbTool_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if((FCADImage == null)&&(tlbTool.Buttons.IndexOf(e.Button) == 8)) return;
			switch(tlbTool.Buttons.IndexOf(e.Button))
			{
				case 0:
					LoadFile(true);
					break; 
				case 1:
					mgForm = new MergeForm();
					mgForm.ShowDialog();
					break;
				case 2:
					DoZoomIn();
					break; 
				case 3:
					DoZoomOut();
					break;
				case 4:
					SaveAsImage();
					break;
				case 5:
					White_Click();
					break;
				case 6:
					Black_Click();
					break;
				case 7:
					Color_Click();
					break;
				case 8:
					Go3dOrbit(! this.Orb3D.Visible);
					break;
				case 9:
					Change3DAxesVisiblity();
					break;
				case 10:
					DoBlackColor();
					break;
				case 11:
					DoNormalColor();
					break;
				case 12:
					ResetScaling();
					break;
				case 13:
					ChangeTextsVisiblity();
					break;
				case 14:
					ChangeDimensionsVisiblity();
					break;
				case 15:
					PutToClipboard();
					break;
				case 16:
					FCADImage.Print(true, true);
					break;
				case 17:
					DoEnableRectangle(! this.clipRectangle.Enabled);
					break;
			}
		}

		private void PutToClipboard()
		{
			if(this.clipRectangle.Enabled)
			{
				DRect tmpRect = new DRect(pos.X, pos.Y, curClRect.Width*scale, curClRect.Height*scale);
				FCADImage.SaveImageToClipboard(tmpRect, this.clipRectangle.ClientRectangle);
			}
			else
			{
				DRect tmp = new DRect(0, 0, curClRect.Width*scale, curClRect.Height*scale);
				FCADImage.SaveImageToClipboard(tmp);
			}
		}

		private void DoEnableRectangle(bool val)
		{
			if(val)
			{
				Go3dOrbit(false);
				this.clipRectangle.Color = FCADImage.DefaultColor;
				this.clipRectangle.EnableRect(RectangleType.Selecting);
			}
			else this.clipRectangle.DisableRect();
			tlbTool.Buttons[17].Pushed = val;
		}

		#region Help
		/// <summary>
		/// Shows or hides 3D axes.
		/// </summary>
		#endregion Help
		public void Change3DAxesVisiblity()
		{
			FCADImage.IsDraw3DAxes = !FCADImage.IsDraw3DAxes;
			tlbTool.Buttons[9].Pushed = FCADImage.IsDraw3DAxes;
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Shows or hides texts in the current CAD image.
		/// </summary>
		#endregion Help
		public void ChangeTextsVisiblity()
		{
			tlbTool.Buttons[13].Pushed = ! tlbTool.Buttons[13].Pushed;
			textsShowMenuItem.Checked = ! textsShowMenuItem.Checked;
			FCADImage.TextVisible = ! FCADImage.TextVisible;
			cadPictBox.Invalidate();
		}
		
		#region Help
		/// <summary>
		/// Shows or hides dimensions in the current CAD image.
		/// </summary>
		#endregion Help
		public void ChangeDimensionsVisiblity()
		{
			tlbTool.Buttons[14].Pushed = ! tlbTool.Buttons[14].Pushed;
			dimShowMenuItem.Checked = ! dimShowMenuItem.Checked;
			FCADImage.DimensionsVisible = ! FCADImage.DimensionsVisible;
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Sets the scale and position of the current CAD image to its original values.
		/// </summary>
		#endregion Help
		public void ResetScaling()
		{
			scale = 1.0f;
			prev_scale = 1;
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;
			cadPictBox.Invalidate();
		}
  
		private void SetLayList()
		{
			if((lForm.lstViewLay.Items.Count != 0)||(FCADImage == null)) return;
			ObjEntity.LayersList = new string[FCADImage.LayersCount];
			string tmp;
			Color colorLay;
			Bitmap b1 = new Bitmap(32, 16);
			lForm.imgColor.Images.Clear();
			lForm.listColor.Items.Clear();
			for(int I = 0; I < FCADImage.LayersCount; I++)
			{
				tmp = FCADImage.GetLayerName(I);
				ObjEntity.LayersList[I] = tmp;
				lForm.lstViewLay.Items.Add(new ListViewItem(new string[1]{tmp}));	
				lForm.lstViewLay.Items[I].Checked = FCADImage.GetLayerVisible(I);

				try
				{
					colorLay = ((CADLayer)FCADImage.Converter.Layers[I]).Color;
					Graphics gr = Graphics.FromImage(b1);
					gr.FillRectangle(new SolidBrush(colorLay), 0, 0, 16, 16);
					gr.DrawRectangle(new Pen(Brushes.Black, 1.2f), 0, 0, 15, 15);
				
					lForm.imgColor.Images.Add((Bitmap)b1.Clone());
					lForm.listColor.Items.Add(new ListViewItem(new string[1]{string.Empty}));
					lForm.listColor.Items[I].ImageIndex = I;
				}
				catch(Exception e)
				{
					MessageBox.Show(e.Message + " - " + e.StackTrace);
				}
			}
			int len = lForm.imgColor.Images.Count * 18 + 18;
			lForm.listColor.Height = len;
			lForm.listColor.Top = 0;
			lForm.lstViewLay.Height = len;
			lForm.lstViewLay.Top = 0;
			lForm.lstViewLay.ItemCheck += dl1;
		}

		#region Help
		/// <summary>
		/// Alternately displays or hides a 3D Orbit tool.
		/// </summary>
		#endregion Help
		public void Go3dOrbit(bool val)
		{
			Orb3D.Visible = val;
			tlbTool.Buttons[7].Pushed = val;
			orbitMenuItem.Checked = val;
			det1 = false;
			if(val) 
			{
				DoEnableRectangle(false);
				Orb3D.Enable3dOrbit();
			}
			else
			{
				Orb3D.Disable3dOrbit();
			}
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Resizes the CAD image to fit drawing's bounds.
		/// </summary>
		/// <remarks>This method is invoked when changing layout or working with a 3D Orbit tool.</remarks>
		#endregion Help
		public void DoResize()
		{			
			if((FCADImage == null)||(deactiv)) return;
			wh = (float)(FCADImage.AbsWidth / FCADImage.AbsHeight); 
			float new_wh = (float)cadPictBox.ClientRectangle.Width / (float)cadPictBox.ClientRectangle.Height;
			curClRect = cadPictBox.ClientRectangle;
			if(new_wh > wh)
				curClRect.Width	= (int)(curClRect.Height * wh);
			else 
			{
				if(new_wh < wh)
					curClRect.Height = (int)(curClRect.Width / wh);
				else
					curClRect = cadPictBox.ClientRectangle;
			}
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;				
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Shows or hides a panel that contains the entities tree.
		/// </summary>
		#endregion Help
		public void ChangeTreeVisiblity()
		{
			bool val = !this.trvEntity.Visible;
			if(val)
				CADImportFace.LoadTreeNodes(trvEntity.Nodes, FCADImage);
			this.trvPanel.Visible = val;
			entitiesMenuItem.Checked = val;
			this.DoResize();
		}

		#region Help
		/// <summary>
		/// Closes a currently open CAD file.
		/// </summary>
		#endregion Help
		public void CloseFile()
		{
			FCADImage.Dispose();
			FCADImage = null;
			EnableButton(false);
			this.trvEntity.Nodes.Clear();
			this.cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Displays a CAD image in all used colors.
		/// </summary>
		#endregion Help
		public void DoNormalColor()
		{
			if(FCADImage == null) return;
			FCADImage.DrawMode = CADDrawMode.Normal;
			this.colorDraw = true;
			tlbTool.Buttons[10].Pushed = false;
			tlbTool.Buttons[11].Pushed = true;
			colorMenuItem.Checked = true;
			blackMenuItem.Checked = false;
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Displays a CAD image in black and white colors.
		/// </summary>
		#endregion Help
		public void DoBlackColor()
		{
			if(FCADImage == null) return;
			FCADImage.DrawMode = CADDrawMode.Black;
			this.colorDraw = false;
			tlbTool.Buttons[10].Pushed = true;
			tlbTool.Buttons[11].Pushed = false;
			colorMenuItem.Checked = false;
			blackMenuItem.Checked = true;
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Makes the layers of the loaded CAD image visible or invisible.
		/// </summary>
		/// <param name="sender">A <see cref="System.Windows.Forms.CheckedListBox">CheckedListBox</see> that initializes changing a visibility of the layers.</param>
		/// <param name="e">An <see cref="System.Windows.Forms.ItemCheckEventArgs">ItemCheckEventArgs</see> object that provides data for the event of changing a layer visibility.</param>
		#endregion Help
		private void chLay_ItemCheck(object sender, System.Windows.Forms.ItemCheckEventArgs e)
		{
			if(e.NewValue == CheckState.Checked)
				FCADImage.SetLayerVisible(e.Index, true);
			else if(e.NewValue == CheckState.Unchecked) 
				FCADImage.SetLayerVisible(e.Index, false);
			cadPictBox.Invalidate();
		}

		private void ImgSave_Click(object sender, System.EventArgs e)
		{
			SaveAsImage();
		}

		private void MainForm_Deactivate(object sender, System.EventArgs e)
		{
			det1 = false;
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void aboutMenuItem_Click(object sender, System.EventArgs e)
		{
			aboutFrm.ShowDialog();
		}

		private void MainForm_Resize(object sender, System.EventArgs e)
		{
			DoResize();
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			CreateNewSettingsList();
			svSet.SaveOptions(settingsLst);
			#region protect
#if protect
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.DisableFloating();
			}
			else
			{
				Protection.CloseApplication();
			}
#else
			Protection.CloseApplication();
#endif
#endif
			#endregion
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			wh = 1f;
			curClRect = cadPictBox.ClientRectangle;
			#region protect
#if protect
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.FloatingLicRegister();
			}
			else	
			{
				Protection.Register();
			}
#else
			Protection.Register();
#endif
#endif
			#endregion
			if(this.openFileDlg.FileName != null)
				if(File.Exists(this.openFileDlg.FileName))
					LoadFile(false);
			#region demo
			#if Demo
				DemoForm d1 = new DemoForm();
				d1.ShowDialog();
			#endif
			#endregion demo
		}

		private void BackViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Back);
			cadPictBox.Invalidate();
		}

		private void TopViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Top);
			cadPictBox.Invalidate();
		}

		private void BottomViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Bottom);
			cadPictBox.Invalidate();
		}

		private void LeftViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Left);
			cadPictBox.Invalidate();
		}

		private void RightViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Right);
			cadPictBox.Invalidate();
		}

		private void FrontViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.Front);
			cadPictBox.Invalidate();
		}

		private void SWViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.SWIsometric);
			cadPictBox.Invalidate();
		}

		private void SEViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.SEIsometric);
			cadPictBox.Invalidate();
		}

		private void NEViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.NEIsometric);
			cadPictBox.Invalidate();
		}

		private void NWViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotToView(CADViewDirection.NWIsometric);
			cadPictBox.Invalidate();
		}

		private void InitialViewMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.RotDefault();
			cadPictBox.Invalidate();
		}

		private void toolMenuItem_Click(object sender, System.EventArgs e)
		{
			#region protect
			#if protect
			regFrm.ShowDialog();
			#endif
			#endregion protect
		}

		private void trvEntity_AfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			CADImportFace.DoCheckTreeNode(FCADImage, trvEntity.Nodes, e.Node);
			cadPictBox.Invalidate();
		}

		private void entitiesMenuItem_Click(object sender, System.EventArgs e)
		{
			ChangeTreeVisiblity();
		}

		private void fitMenuItem_Click(object sender, System.EventArgs e)
		{
			ResetScaling();
		}

		private void copyMenuItem_Click(object sender, System.EventArgs e)
		{
			DRect tmp = new DRect(0, 0, curClRect.Width*scale,
				curClRect.Height*scale);
			FCADImage.SaveImageToClipboard(tmp);
		}

		private void closeMenuItem_Click(object sender, System.EventArgs e)
		{
			CloseFile();
		}

		private void printMenuItem_Click(object sender, System.EventArgs e)
		{
			FCADImage.Print(true, true);
		}
		
		private void colorMenuItem_Click(object sender, System.EventArgs e)
		{
			DoNormalColor();
		}

		private void blackMenuItem_Click(object sender, System.EventArgs e)
		{
			DoBlackColor();
		}

		private void whiteBackMenuItem_Click(object sender, System.EventArgs e)
		{
			White_Click();
		}

		private void blackBackMenuItem_Click(object sender, System.EventArgs e)
		{
			Black_Click();
		}

		private void changeBackMenuItem_Click(object sender, System.EventArgs e)
		{
			Color_Click();
		}

		private void dimShowMenuItem_Click(object sender, System.EventArgs e)
		{
			ChangeDimensionsVisiblity();
		}

		private void textsShowMenuItem_Click(object sender, System.EventArgs e)
		{
			ChangeTextsVisiblity();
		}

		private void layersShowMenuItem_Click(object sender, System.EventArgs e)
		{
			SetLayList();
			lForm.ShowDialog();
		}

		private void orbitMenuItem_Click(object sender, System.EventArgs e)
		{
			Go3dOrbit(! this.Orb3D.Visible);
		}

		private void splitter1_SplitterMoved(object sender, System.Windows.Forms.SplitterEventArgs e)
		{
			this.DoResize();
			this.cadPictBox.Invalidate();
		}

		private void LanguageSelect_Click(object sender, System.EventArgs e)
		{
			if(!(sender is MenuItem))
				return;
			if(curLngInd < this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count)
				this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[curLngInd].Checked = false;
			MenuItem mn = (sender as MenuItem);
			curLngInd = (byte)mn.Index;
			lngFile = mn.Text + ".lng"; 
			mn.Checked = true;
			SetLNG();
		}

		private void SetLNG()
		{
			mlng.LoadLNG(lngFile);
			mlng.RestoreLanguage(this.Controls, this.Menu);
			this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Clear();
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			if(this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count > this.curLngInd)
				this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[this.curLngInd].Checked = true;
			this.Text = "CADImport.Net Demo";
			this.Text = mlng.SetLanguage(this.Controls, this.Menu, this.Text);
		}

		//set loads settings
		internal void SetSettings()
		{
			if(settingsLst == null)
				return;
			string tmp;
			int cn = 0;
			//Language path
			string key = "LanguagePath";
			if(settingsLst.ContainsKey(key))
				MultipleLanguage.path = Convert.ToString(settingsLst[key]);
			//Language
			key = "Language";
			if(settingsLst.ContainsKey(key))
				lngFile = (string)settingsLst[key];
			mlng.LoadLNG(lngFile);
			this.Text = mlng.SetLanguage(this.Controls, this.Menu, this.Text);
			//Language ID
			key = "LanguageID";
			if(settingsLst.ContainsKey(key))
			{
				this.curLngInd = Convert.ToByte(settingsLst[key]);
				if(this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count > this.curLngInd)
					this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[this.curLngInd].Checked = true;
			}
			//BackgroundColor
			key = "BackgroundColor";
			tmp = "BLACK";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "BLACK")
				this.Black_Click();
			else this.White_Click();
			//Show entity panel
			key = "ShowEntity";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "TRUE") 
			{
				this.entitiesMenuItem.Checked = true;
				this.trvPanel.Visible = true;
			}
			else
			{
				this.entitiesMenuItem.Checked = false;
				this.trvPanel.Visible = false;
			}
			//Color drawing
			key = "ColorDraw";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "TRUE") 
				this.colorDraw = true;
			else this.colorDraw = false;
			//SHXPathCount
			key = "SHXPathCount";
			if(settingsLst.ContainsKey(key))
				cn = Convert.ToInt32(settingsLst[key]);
			//SHXPaths
			for(int i = 0; i < cn; i++)
			{
				key = "SHXPath_" + (i + 1);
				if(settingsLst.ContainsKey(key))
					this.shxFrm.AddPath(Convert.ToString(settingsLst[key]));
			}
			if((CADConst.SearchSHXPaths)&&(cn == 0))
			{
				ArrayList vPaths = new ArrayList();
				CADConst.FindAutoCADSHXPaths(vPaths);
				for(int i = 0; i < vPaths.Count; i++)
				{
					tmp = (string)vPaths[i];
					this.shxFrm.lstDir.Items.Add(tmp);
					this.shxFrm.lstPath.Add(tmp, "");
					CADConst.SHXSearchPaths += CADConst.SHXSearchPaths + tmp + ";";
				}
			}
			//First start
			key = "Install";
			if(settingsLst.ContainsKey(key))
			{
				if(CADConst.SearchSHXPaths)
				{
					this.shxFrm.lstDir.Items.Clear();
					this.shxFrm.lstPath.Clear();
					ArrayList vPaths = new ArrayList();
					CADConst.FindAutoCADSHXPaths(vPaths);
					for(int i = 0; i < vPaths.Count; i++)
					{
						tmp = (string)vPaths[i];
						this.shxFrm.lstDir.Items.Add(tmp);
						this.shxFrm.lstPath.Add(tmp, "");
						CADConst.SHXSearchPaths += CADConst.SHXSearchPaths + tmp + ";";
					}
				}
			}
			#region protect
#if protect
			//License
			key = "Type_license";
			if(settingsLst.ContainsKey(key))
			{
				tmp = (string)settingsLst[key];
#if floatprotect
				if(tmp == "floating")
				{
					Protection.LicenseType = LicenseType.Floating;
					key = "Host";
					if(settingsLst.ContainsKey(key))
					{
						this.floatLicFrm.Host = (string)settingsLst[key];
					}
					key = "Port";
					if(settingsLst.ContainsKey(key))
					{
						this.floatLicFrm.Port = Convert.ToInt32(settingsLst[key]);
					}
					key = "Application";
					if(settingsLst.ContainsKey(key))
					{
						this.floatLicFrm.App = (string)settingsLst[key];
					}
				}
				else
				{
					Protection.LicenseType = LicenseType.Register;
				}
#else
				Protection.LicenseType = LicenseType.Register;
#endif
			}
#endif
			#endregion
		}

		private void CreateNewSettingsList()
		{
			string tmp;
			settingsLst = new SortedList();
			//Language path
			settingsLst.Add("LanguagePath", MultipleLanguage.path);
			//Language
			settingsLst.Add("Language", lngFile);
			//Language ID
			settingsLst.Add("LanguageID", this.curLngInd);
			//BackgroundColor
			if(cadPictBox.BackColor == Color.Black)
				tmp = "Black";
			else tmp = "White";
			settingsLst.Add("BackgroundColor", tmp);
			//Show entity panel
			settingsLst.Add("ShowEntity", this.trvPanel.Visible);
			//Color drawing
			settingsLst.Add("ColorDraw", this.colorDraw);
			//SHXPathCount
			int cn = this.shxFrm.lstDir.Items.Count;
			settingsLst.Add("SHXPathCount", this.shxFrm.lstDir.Items.Count);
			//SHXPaths
			for(int i = 0; i < cn; i++)
			{
				settingsLst.Add("SHXPath_" + (i + 1), this.shxFrm.lstDir.Items[i]);
			}
			#region protect
#if protect
			//License
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				settingsLst.Add("Type_license", "floating");
				settingsLst.Add("Host", this.floatLicFrm.Host);
				settingsLst.Add("Port", this.floatLicFrm.Port);
				settingsLst.Add("Application", this.floatLicFrm.App);
			}
			else
				settingsLst.Add("Type license", "register");
#else
			settingsLst.Add("Type license", "register");
#endif
#endif
			#endregion
		}

		private void Options_Click(object sender, System.EventArgs e)
		{
			//old lng files path
			string tmp = MultipleLanguage.path;
			bool blackcolor = this.colorDraw;
			//create current options list
			CreateNewSettingsList();
			if(this.optForm.ShowDialog() == DialogResult.Cancel) return;
			//clear current lists
			MultipleLanguage.lngList.Clear();
			this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Clear();
			//default language
			mlng.RestoreLanguage(this.Controls, this.mainMenu);
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			//set new options
			SetSettings();
			//set colors draw
			if(blackcolor != this.colorDraw) 
			{
				if(this.colorDraw) DoNormalColor();
				else this.DoBlackColor();
			}
		}

		internal void ReloadLNG()
		{
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
		}

		private void printprevItem_Click(object sender, System.EventArgs e)
		{
			printPrevDlg.Document = FCADImage.Print(false, false);
			printPrevDlg.ShowDialog();
			printPrevDlg.Document.Dispose();
		}

		private void btnPrintPrevCust_Click(object sender, System.EventArgs e)
		{
			prtForm.ShowDialog();
		}

		private void mnSaveAsDXF_Click(object sender, System.EventArgs e)
		{
			if(this.FCADImage == null) return;
			if(this.saveDXFDlg.ShowDialog() != DialogResult.OK) return;
			SaveAsDXF(this.saveDXFDlg.FileName);
		}

		private void SaveAsDXF(string fName)
		{
			#region Export
#if Export
			if(FCADImage == null) return;
			if(FCADImage is CADRasterImage) 
			{
				return;
			}
			CADtoDXFModule.CADtoDXF vExp = new CADtoDXFModule.CADtoDXF(FCADImage);
			vExp.SaveToFile(fName);
#else
				MessageBox.Show("Not supported in current version!", "CADImport .Net");
#endif
			#endregion Export

			#region ExportOverMetafile 
			/*#region Export
#if Export
				if(! (this.FCADImage is RasterImage.CADRasterImage)) 
					this.FCADImage.SaveAsDXF(fName, this.cadPictBox.Handle, actForm);
				else
					MessageBox.Show("This operation is not supported for current file format", "CADImport .Net");
#else
					MessageBox.Show("Not supported in current version!", "CADImport .Net");
#endif
			#endregion Export*/
			#endregion
		}

		private void miFloatLic_Click(object sender, System.EventArgs e)
		{
			#region protect
#if floatprotect
				floatLicFrm.ShowDialog();
#endif
			#endregion
		}

	}
}
