//To compile the project you need the extended version of the CADImport .NET library
//that allows to access CAD entities directly.  You can get this version of the 
//library free of charge by emailing your request to: info@cadsofttools.com
using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using CADImport;
using CADImportForm;
using HPGL2;
using RasterImage;

namespace ImportDemoApplication
{
	#region Help
	/// <summary>
	/// Represents the main application form in which CAD image can be viewed.
	/// </summary>
	#endregion Help
	public class MainForm : System.Windows.Forms.Form
	{
		private const int OnMouseScroll = 522;
		private CADIterate CADParams;
		private bool deactiv;
		private PointF old_Pos = new PointF();
		private LayerForm lForm = new LayerForm();
		private AboutForm aboutFrm = new AboutForm();
		private PointF pos;
		private static MainForm actForm;
		#region protect
		#if protect
			private RegForm regFrm;
		#endif
		#if (protect && floatprotect)
			private FloatLicForm floatLicFrm;
		#endif
		#endregion protect
		private Rectangle curClRect;
		private float wh;
		private ArrayList TextFile = new ArrayList();
		private float scale = 1;
		private DPoint ScaleRect = new DPoint();
		private ArrayList layouts = new ArrayList();
		private int cX, cY;
		private bool det1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.StatusBar stBar;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem mExit;
		private System.Windows.Forms.MenuItem mOpenFile;
		private System.Windows.Forms.MenuItem mSaveFile;
		private System.Windows.Forms.MenuItem mFile;
		private System.Windows.Forms.MenuItem mView;
		private System.Windows.Forms.MenuItem mScale;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.StatusBarPanel sbOpen;
		private System.Windows.Forms.StatusBarPanel sbScale;
		private System.Windows.Forms.SaveFileDialog saveImgDlg;
		private System.Windows.Forms.StatusBarPanel sbCoord;
		private System.Windows.Forms.Panel pnlLayouts;
		private System.Windows.Forms.PictureBox cadPictBox;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem miFloatLic;
		private System.Windows.Forms.SaveFileDialog dlgSaveEnt;
		private static readonly ArrayList HPGLExt;

		static MainForm()
		{
			HPGLExt = new ArrayList(new string[]{".HPG", ".PLT", ".RTL", ".SPL", ".PRN", ".GL2", ".HPGL2", ".HPGL",
													".HP2", ".HP1", ".HP", ".PLO", ".HG", ".HGL"});
		}

		private void Zoom(float i)
		{
			if(FCADImage == null) return;
			scale = scale*i;
			if(scale < 0.005f) scale = 0.005f;	
			cadPictBox.Invalidate();
			cadPictBox_MouseMove(cadPictBox, new MouseEventArgs(MouseButtons.Left, 0, (int)old_Pos.X, (int)old_Pos.Y, 0));
			stBar.Panels[1].Text = "" + scale;
		}

		private float prev_scale = 1;
		private void Shift()
		{
			pos.X = old_Pos.X - (old_Pos.X - pos.X)*scale / prev_scale;
			pos.Y = old_Pos.Y - (old_Pos.Y - pos.Y)*scale / prev_scale;
			prev_scale = scale;		
		}

		#region Help
		/// <summary>
		/// Processes Windows messages and allows the user to zoom in(out) the CAD image by mouse wheel.
		/// </summary>
		/// <param name="m">The Windows <see cref="System.Windows.Forms.Message">Message</see> to process.</param>
		#endregion Help
		protected override void WndProc(ref Message m)
		{
			if(m.Msg == 0x0112)
			{
				if(m.WParam.ToInt32() == 0xF020)
					deactiv = true;
			}
			if(m.Msg == OnMouseScroll) 
			{
				if(m.WParam.ToInt32() < 0)  Zoom(0.7f);
				else Zoom(1.3f);
			} 
			else base.WndProc(ref m);
		}

		private System.ComponentModel.IContainer components = null;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="ImportDemoApplication.MainForm">MainForm</see> class.
		/// </summary>
		#endregion Help
		public MainForm()
		{
			#region protect
#if (protect && floatprotect)
			floatLicFrm = new FloatLicForm();
			floatLicFrm.Change += new System.EventHandler(InvalidateImage);
#endif
#if protect
			regFrm = new RegForm();
#endif
			#endregion protect
			InitializeComponent();
			#region protect
#if ((! floatprotect) && protect)
			this.miFloatLic.Enabled = false;
#endif
			#endregion
		}

		private void InvalidateImage(object sender, System.EventArgs e)
		{
			this.cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveImgDlg = new System.Windows.Forms.SaveFileDialog();
			this.stBar = new System.Windows.Forms.StatusBar();
			this.sbOpen = new System.Windows.Forms.StatusBarPanel();
			this.sbScale = new System.Windows.Forms.StatusBarPanel();
			this.sbCoord = new System.Windows.Forms.StatusBarPanel();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mFile = new System.Windows.Forms.MenuItem();
			this.mOpenFile = new System.Windows.Forms.MenuItem();
			this.mSaveFile = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mExit = new System.Windows.Forms.MenuItem();
			this.mView = new System.Windows.Forms.MenuItem();
			this.mScale = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.miFloatLic = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.pnlLayouts = new System.Windows.Forms.Panel();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.cadPictBox = new System.Windows.Forms.PictureBox();
			this.dlgSaveEnt = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).BeginInit();
			this.pnlLayouts.SuspendLayout();
			this.SuspendLayout();
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.DefaultExt = "*.dxf;*.dwg";
			this.openFileDialog1.Filter = @"All(*.dxf,*.dwg,*.hpg,*.plt,*.rtl, *.spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1, *.hp, *.plo, *.hg,*.hgl,*.cgm, *.bmp,*.jpg, *.jpeg,*.tiff, *.gif, *.ico, *.cur, *.png, *.emf, *.wmf)|*.bmp;*.jpg;*.jpeg;*.tiff; *.gif; *.ico;*.dxf;*.dwg;*.hpg;*.plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;*.hgl;*.cur;*.png; *.emf; *.wmf; *.cgm|CAD files(*.dxf, *.dwg)|*.dxf;*.dwg|All raster files (*.bmp,*.jpg, *.jpeg,*.tiff,*.tif, *.gif, *.ico, *.cur, *.png)|*.bmp;*.jpg;*.jpeg;*.tiff;*.tif; *.gif;*.ico;*.cur; *.png|Metafiles ( *.emf, *.wmf)| *.emf; *.wmf|DXF files(*.dxf)|*.dxf|DWG files(*.dwg)|*.dwg|BMP(*.bmp)|*.bmp|JPG(*.jpg, *.jpeg)| *.jpg; *.jpeg|TIFF(*.tiff, *.tif)|*.tiff;*.tif|GIF(*.gif)|*.gif|ICO(*.ico)|*.ico|PNG(*.png)|*.png|Cursors(*.cur)|*.cur|HPGL(*.hpg,*.plt,*.rtl, *.spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1, *.hp, *.plo, *.hg,*.hgl)|*.hpg;*.plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;*.hgl|CGM (*.cgm)|*.cgm";
			this.openFileDialog1.ShowHelp = true;
			// 
			// saveImgDlg
			// 
			this.saveImgDlg.Filter = "*.bmp|*.bmp|*.jpg|*.jpg|*.tiff|*.tiff|*.gif|*.gif|*.emf|*.emf";
			this.saveImgDlg.RestoreDirectory = true;
			// 
			// stBar
			// 
			this.stBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.stBar.Location = new System.Drawing.Point(0, 300);
			this.stBar.Name = "stBar";
			this.stBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					 this.sbOpen,
																					 this.sbScale,
																					 this.sbCoord});
			this.stBar.ShowPanels = true;
			this.stBar.Size = new System.Drawing.Size(687, 16);
			this.stBar.TabIndex = 9;
			// 
			// sbOpen
			// 
			this.sbOpen.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbOpen.MinWidth = 100;
			this.sbOpen.ToolTipText = "File Name";
			// 
			// sbScale
			// 
			this.sbScale.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbScale.ToolTipText = "Scale";
			this.sbScale.Width = 520;
			// 
			// sbCoord
			// 
			this.sbCoord.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
			this.sbCoord.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbCoord.Text = "0 - 0 - 0";
			this.sbCoord.Width = 51;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mFile,
																					  this.mView,
																					  this.menuItem9});
			// 
			// mFile
			// 
			this.mFile.Index = 0;
			this.mFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mOpenFile,
																				  this.mSaveFile,
																				  this.menuItem2,
																				  this.mExit});
			this.mFile.Text = "&File";
			// 
			// mOpenFile
			// 
			this.mOpenFile.Index = 0;
			this.mOpenFile.Text = "&Open File...";
			this.mOpenFile.Click += new System.EventHandler(this.Open_Click);
			// 
			// mSaveFile
			// 
			this.mSaveFile.Enabled = false;
			this.mSaveFile.Index = 1;
			this.mSaveFile.Text = "Save File As...";
			this.mSaveFile.Click += new System.EventHandler(this.button2_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 2;
			this.menuItem2.Text = "-";
			// 
			// mExit
			// 
			this.mExit.Index = 3;
			this.mExit.Text = "&Exit";
			this.mExit.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// mView
			// 
			this.mView.Index = 1;
			this.mView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mScale});
			this.mView.Text = "&View";
			// 
			// mScale
			// 
			this.mScale.Enabled = false;
			this.mScale.Index = 0;
			this.mScale.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem1,
																				   this.menuItem3,
																				   this.menuItem4,
																				   this.menuItem5,
																				   this.menuItem6,
																				   this.menuItem7,
																				   this.menuItem8});
			this.mScale.Text = "&Scale";
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "10%";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "25%";
			this.menuItem3.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "50%";
			this.menuItem4.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 3;
			this.menuItem5.Text = "100%";
			this.menuItem5.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 4;
			this.menuItem6.Text = "200%";
			this.menuItem6.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 5;
			this.menuItem7.Text = "400%";
			this.menuItem7.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 6;
			this.menuItem8.Text = "800%";
			this.menuItem8.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 2;
			this.menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem11,
																					  this.miFloatLic,
																					  this.menuItem10});
			this.menuItem9.Text = "&?";
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 0;
			this.menuItem11.Text = "Register";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// miFloatLic
			// 
			this.miFloatLic.Index = 1;
			this.miFloatLic.Text = "Floating License Registration...";
			this.miFloatLic.Click += new System.EventHandler(this.miFloatLic_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 2;
			this.menuItem10.Text = "&About";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// pnlLayouts
			// 
			this.pnlLayouts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlLayouts.Controls.Add(this.button2);
			this.pnlLayouts.Controls.Add(this.button1);
			this.pnlLayouts.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlLayouts.Location = new System.Drawing.Point(0, 0);
			this.pnlLayouts.Name = "pnlLayouts";
			this.pnlLayouts.Size = new System.Drawing.Size(687, 32);
			this.pnlLayouts.TabIndex = 11;
			// 
			// button2
			// 
			this.button2.Enabled = false;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button2.Location = new System.Drawing.Point(96, 4);
			this.button2.Name = "button2";
			this.button2.TabIndex = 1;
			this.button2.Text = "Save";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(9, 3);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "Load";
			this.button1.Click += new System.EventHandler(this.Open_Click);
			// 
			// cadPictBox
			// 
			this.cadPictBox.BackColor = System.Drawing.Color.White;
			this.cadPictBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.cadPictBox.Cursor = System.Windows.Forms.Cursors.Default;
			this.cadPictBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.cadPictBox.Location = new System.Drawing.Point(0, 0);
			this.cadPictBox.Name = "cadPictBox";
			this.cadPictBox.Size = new System.Drawing.Size(687, 316);
			this.cadPictBox.TabIndex = 8;
			this.cadPictBox.TabStop = false;
			this.cadPictBox.Paint += new System.Windows.Forms.PaintEventHandler(this.cadPictBox_Paint);
			this.cadPictBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseUp);
			this.cadPictBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseMove);
			this.cadPictBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseDown);
			// 
			// dlgSaveEnt
			// 
			this.dlgSaveEnt.DefaultExt = "*.txt";
			this.dlgSaveEnt.Filter = "*.txt|*.txt";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(687, 316);
			this.Controls.Add(this.pnlLayouts);
			this.Controls.Add(this.stBar);
			this.Controls.Add(this.cadPictBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "MainForm";
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CADImport.NET - Import";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Resize += new System.EventHandler(this.MainForm_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).EndInit();
			this.pnlLayouts.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Help
		/// <summary>
		/// A CAD image displayed in the main application form.
		/// </summary>
		#endregion Help
		protected CADImage FCADImage;
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Disabled;
			actForm = new MainForm();
			Application.Run(actForm);			
		}

		private void Open_Click(object sender, System.EventArgs e)
		{
			cadPictBox.Visible = false;
			if(openFileDialog1.ShowDialog(this) != DialogResult.OK) 
			{
				cadPictBox.Visible = true;
				return;
			}
			if (openFileDialog1.FileName != null)
			{
				if(FCADImage != null)
				{	
					FCADImage.Dispose();
					FCADImage = null;
				}
				this.Cursor = Cursors.WaitCursor;
				stBar.Panels[0].Text = "Load file...";
				scale = 1;
				prev_scale = 1;
				pos = new PointF();
				string ext = Path.GetExtension(this.openFileDialog1.FileName).ToUpper();
				if(ext == ".DWG")
				{
					#region DWGModule
#if DWGModule
					FCADImage = new DWG.DWGImage();
					FCADImage.LoadFromFile(this.openFileDialog1.FileName);
#else
						NotSupportedInCurrentVersion();
						return;

#endif
					#endregion
				}
				else  if (ext == ".DXF")
				{
					FCADImage = new CADImage();
					FCADImage.LoadFromFile(this.openFileDialog1.FileName);
				}
				else if(ext == ".CGM")
				{
#if UseCGM
					bool tmpshx = CADConst.UseSHXFonts;
					if(CADConst.UseSHXFonts)
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = false;
					}
					else 
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = true;
					}
					FCADImage = new CGM.CGMImage();
					FCADImage.LoadFromFile(this.openFileDialog1.FileName);
#else
					NotSupportedInCurrentVersion();
					return;
#endif
				}
				else 
					if(HPGLExt.IndexOf(ext) != -1)
				{
					FCADImage = new HPGLImage();
					FCADImage.LoadFromFile(this.openFileDialog1.FileName);
				}
				else
				{
					FCADImage = new CADRasterImage(this.cadPictBox);
					FCADImage.LoadFromFile(this.openFileDialog1.FileName);
				}
			} 
			FCADImage.UseWinEllipse = false;
			mScale.Enabled = true;
			mSaveFile.Enabled = true;
			button2.Enabled = true;
			cadPictBox.Visible = true;
			DoResize();
			stBar.Panels[1].Text = "" + scale;
			this.Cursor = Cursors.Default;
		}

		private void NotSupportedInCurrentVersion()
		{
			this.Cursor = Cursors.Default;
			cadPictBox.Visible = true;
			stBar.Panels[0].Text = "not supported";
			MessageBox.Show("Not supported in current version!", "CADImport .Net");
			return;
		}

		private void ZoomIn_Click(object sender, System.EventArgs e)
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
								 cadPictBox.ClientRectangle.Height / 2);
			scale = scale * 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void ZoomOut_Click(object sender, System.EventArgs e)
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
								 cadPictBox.ClientRectangle.Height / 2);
			scale = scale / 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void cadPictBox_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if(FCADImage == null) return;
			try
			{
				deactiv = false;
				Shift();
				RectangleF tmp = new RectangleF(pos.X, pos.Y, curClRect.Width*scale,
												curClRect.Height*scale);
				FCADImage.Draw(e.Graphics, tmp);		
			}
			catch 
			{	
				return;
			}
		}

		private void cadPictBox_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			det1 = false;
			cadPictBox.Cursor = Cursors.Default;
			cadPictBox.Invalidate();
		}

		private void cadPictBox_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(e.Button == MouseButtons.Right) 
			{
				MainForm.ActiveForm.Cursor = Cursors.Hand;
				cX = e.X;
				cY = e.Y;
				det1 = true;
			}
		}

		private void cadPictBox_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			cadPictBox.Focus();
			if(FCADImage == null) return;
			if(det1)
			{
				pos.X -= (cX - e.X);
				pos.Y -= (cY - e.Y);
				cX = e.X;
				cY = e.Y;
				cadPictBox.Invalidate();
			}
			old_Pos = new PointF(e.X, e.Y);
			DPoint vPt = GetRealPointUsingsgImagePoint(e.X, e.Y);
			stBar.Panels[2].Text = "" + vPt.X + " : " + vPt.Y + " : 0";
		}

		private DPoint GetRealPointUsingsgImagePoint(float X, float Y)
		{
			Rectangle tmp = new Rectangle();
			tmp = curClRect;
			DRect Rect = new DRect(tmp.Left, tmp.Top,
				tmp.Right, tmp.Bottom);
			float fKoef = (float)(FCADImage.AbsHeight / FCADImage.AbsWidth);
			Rect.left = Rect.left  * scale + pos.X;
			Rect.right = Rect.right * scale + pos.X;
			Rect.top = Rect.top * scale + pos.Y;			
			Rect.bottom = Rect.top  + (Rect.right - Rect.left) *   fKoef;						
			ScaleRect.X = FCADImage.AbsWidth / (Rect.right - Rect.left);
			ScaleRect.Y = FCADImage.AbsHeight / (Rect.bottom - Rect.top);
			DPoint mousePt = new DPoint(0 ,0, 0);
			DPoint newmousePt = new DPoint(0 ,0, 0);
			DPoint pX, pY, pCenter;
			DRect DRectExtentsCAD = FCADImage.Extents;
			mousePt.X = DRectExtentsCAD.left + (X - pos.X) * ScaleRect.X;
			mousePt.Y = DRectExtentsCAD.top  - (Y - pos.Y) * ScaleRect.Y;
			pCenter.X = 0.5f * (DRectExtentsCAD.right + DRectExtentsCAD.left);
			pCenter.Y = 0.5f * (DRectExtentsCAD.top + DRectExtentsCAD.bottom);
			pCenter.Z = 0.5f * (DRectExtentsCAD.z2 + DRectExtentsCAD.z1);
			pX.X = 1; pX.Y = 0;	pX.Z = 0;
			pY.X = 0; pY.Y = 1;	pY.Z = 0;		
			pX = FCADImage.GetRealImagePoint(pX);
			pY = FCADImage.GetRealImagePoint(pY);
			MoveToPosition(ref mousePt, pCenter, -1);
			newmousePt.X = mousePt.X * pX.X + mousePt.Y * pX.Y;
			newmousePt.Y = mousePt.X * pY.X + mousePt.Y * pY.Y;
			MoveToPosition(ref newmousePt, pCenter, +1);
			return newmousePt;
		}

		private void MoveToPosition(ref DPoint point, DPoint aPos, int direction)
		{  
			point.X = point.X + direction * aPos.X;
			point.Y = point.Y + direction * aPos.Y;
			point.Z = point.Z + direction * aPos.Z;
		}

		private void MainForm_Deactivate(object sender, System.EventArgs e)
		{
			det1 = false;
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			aboutFrm.ShowDialog();
		}

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			if(FCADImage == null) return;
			float i = scale;
			switch((sender as MenuItem).Index)
			{
				case 0:
					i = 0.1f;
					break;
				case 1:
					i = 0.25f;
					break;
				case 2:
					i = 0.5f;
					break;
				case 3:
					i = 1;
					break;
				case 4:
					i = 2;
					break;
				case 5:
					i = 4;
					break;
				case 6:
					i = 8;
					break;
			}
			float old_x = cadPictBox.ClientRectangle.Width / 2;
			float old_y = cadPictBox.ClientRectangle.Height / 2;
			old_Pos = new PointF(old_x, old_y);
			scale = i;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void ResetScaling()
		{
			scale = 1.0f;
			prev_scale = 1;
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;
		}

		private void MainForm_Resize(object sender, System.EventArgs e)
		{
			DoResize();
		}

		private void DoResize()
		{			
			if((FCADImage == null)||(deactiv)) return;
			wh = (float)(FCADImage.AbsWidth / FCADImage.AbsHeight); 
			float new_wh = (float)cadPictBox.ClientRectangle.Width / (float)cadPictBox.ClientRectangle.Height;
			curClRect = cadPictBox.ClientRectangle;
			if(new_wh > wh)
				curClRect.Width	= (int)(curClRect.Height * wh);
			else 
			{
				if(new_wh < wh)
					curClRect.Height = (int)(curClRect.Width / wh);
				else
					curClRect = cadPictBox.ClientRectangle;
			}
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;				
			cadPictBox.Invalidate();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			if(dlgSaveEnt.ShowDialog() !=  DialogResult.OK) return;
			if(dlgSaveEnt.FileName != null)
				ReadAll(dlgSaveEnt.FileName);
		}

		private void ReadAll(string aFileName)
		{
			if(FCADImage == null) return;
			TextFile.Clear();
			StreamWriter wr1 = File.CreateText(aFileName);
			CADParams = new CADIterate();
			CADParams.matrix = new CADMatrix();
			CADParams.matrix.data[0, 0] = 1;
			CADParams.matrix.data[1, 1] = 1;
			CADParams.matrix.data[2, 2] = 1;
			FCADImage.Converter.AutoInsert = true; // to get all the elements inside of inserts
			FCADImage.Converter.Iterate(new CADEntityProc(ReadCADEntities), CADParams);
			for(int i = 0; i < TextFile.Count; i++)
				wr1.WriteLine((string)TextFile[i]);
			wr1.Close();
		}

		/*All elements inside inserts can be reached in the next procedure.
		Proc called for Inserts too */
		private void ReadCADEntities(CADEntity Entity)
		{
			string[] PS = new string[4]{"psSolid","psDash","psDot","psDashDot"};
			string S;
			CADLayer L;
			Color C;
			string tmp = CADImportFaceModule.CADImportFace.SetName(Entity);
			S = "ClassName = CADImport.CAD" + tmp + "; Entity name = " + tmp;
			CADConst.DoScale2D(ref CADParams); // calculates 2d scale and rotation
			// layer
			L = CADConst.EntLayer(Entity, CADParams.insert);
			if(L != null) S = S + " layer = " + L.Name;
			// color
			S = S + " style = " + PS[(int)CADConst.EntStyle(Entity)];
			C = CADConst.EntColor(Entity, CADParams.insert);
			if(C == CADConst.clNone) S = S + " color = black/white";
			else
				S = S + " color = " + C.Name;
			// particular properties
			TextFile.Add(S);
			//Face - see CADImage.cs CADImage.DrawFace
			//Solid  - see CADImage.cs CADImage.DrawSolid
			if(Entity is CADSolid) 
			{
				ImportSolid(Entity as CADSolid);
				return;
			}
			//point - see CADImage.cs CADImage.DrawPoint
			//line  - see CADImage.cs CADImage.DrawLine
			if(Entity is CADLine)
			{
				ImportLine(Entity as CADLine);
				return;
			}
			//viewport - see CADImage.cs CADImage.Draw
			//hatch - see CADImage.cs CADImage.DrawHatch
			//ellipse - see CADImage.cs CADImage.DrawEllipse
			if(Entity is CADEllipse) 
			{
				ImportEllipse(Entity as CADEllipse);
				return;
			}
			//arc - see CADImage.cs CADImage.DrawArc
			if(Entity is CADArc)
			{
				ImportArc(Entity as CADArc);
				return;
			}
			//Circle - see CADImage.cs CADImage.DrawCircle
			if(Entity is CADCircle)
			{
				ImportCircle(Entity as CADCircle);
				return;
			}
			//Leader - see CADImage.cs CADImage.DrawLeader
			//Spline - see CADImage.cs CADImage.DrawSpline
			if(Entity is CADSpline)
			{
				ImportSpline(Entity as CADSpline);
				return;
			}
			//PolyLine - see CADImage.cs CADImage.DrawPolyLine
			if(Entity is CADPolyLine)
			{
				ImportPolyLine(Entity as CADPolyLine);
				return;
			}
			//attdef - see CADImage.cs CADImage.DrawText
			if(Entity is CADAttdef)
			{
				ImportAttdef(Entity as CADAttdef);
				return;
			}
			//text - see CADImage.cs CADImage.DrawText
			if(Entity is CADText)
			{
				ImportText(Entity as CADText);
				return;
			}
			if(Entity is CADHatch)
			{
				ImportHatch(Entity as CADHatch);
				return;
			}
		}

		private string[] hatchStyle = new string[8]{"BDiagonal", "Cross", "DiagCross", "FDiagonal",
		"Horizontal", "PatternData", "Solid", "Vertical"};
		private void ImportHatch(CADHatch Sender)
		{
			CADHatchStyle style;
			DPoint P;
			string S = "";
			S = S + "HatchName = " + Sender.HatchName;
			S = S + (char)13 + (char)10;
			style = Sender.HatchStyle;
			S = S + "HatchStyle = " + hatchStyle[(int)style];
			S = S + (char)13 + (char)10;
			S = S + "Color = " + Sender.Color.Name;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Elevation); 
			S = S + "Elevation: ";	
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Extrusion); 
			S = S + "Extrusion: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportSolid(CADSolid Sender)
		{
			DPoint P;
			string S = "";
			P = CADParams.matrix.PtXMat(Sender.Point);
			S = S + " P1: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Point1);
			S = S + " P2: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Point3);
			S = S + " P3: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Point2);
			S = S + " P4: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportLine(CADLine Sender)
		{
			DPoint P;
			string S = "";
			P = CADParams.matrix.PtXMat(Sender.Point);
			S = S + " Begin point: ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			P = CADParams.matrix.PtXMat(Sender.Point1);
			S = S + " End point: ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			//getting the real screen coordinates
			/*Point p1;
			S = S + "------------------------";
			S = S + (char)13 + (char)10;
			p1 = FCADImage.GetPoint(Sender.Point);
			S = S + " Begin point(screen coordinates): ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + p1.X;
			S = S + " Y=" + p1.Y;
			S = S + (char)13 + (char)10;
			p1 = FCADImage.GetPoint(Sender.Point1);
			S = S + " End point(screen coordinates): ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + p1.X;
			S = S + " Y=" + p1.Y;
			S = S + (char)13 + (char)10;
			S = S + "------------------------";
			S = S + (char)13 + (char)10;*/
			TextFile.Add(S);
		}

		private void ImportEllipse(CADEllipse Sender)
		{
			DPoint P;
			string S = "";
			P = CADParams.matrix.PtXMat(Sender.Point);
			S = S + " Center of Ellipse: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			S = S + " Start Angle: " + Sender.StartAngle;
			S = S + (char)13 + (char)10;
			S = S + " End Angle: " + Sender.EndAngle;
			S = S + (char)13 + (char)10;
			S = S + " Rx: " + Sender.Radius;
			S = S + " Ry: " + Sender.Radius * Sender.Ratio;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}
		//To compile the project you need the extended version of the CADImport .NET library
		//that allows to access CAD entities directly.  You can get this version of the 
		//library free of charge by emailing your request to: info@cadsofttools.com
		private void ImportArc(CADArc Sender)
		{
			DPoint P;
			string S = "";
			P = CADParams.matrix.PtXMat(Sender.Point);
			S = S + " Center of RoundArc: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			S = S + " Start Angle: " + Sender.StartAngle;
			S = S + (char)13 + (char)10;
			S = S + " End Angle: " + Sender.EndAngle;
			S = S + (char)13 + (char)10;
			S = S + " Rx: " + Sender.Radius;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportCircle(CADCircle Sender)
		{
			DPoint P;
			string S = "";
			P = CADParams.matrix.PtXMat(Sender.Point);
			S = S + " Center of Circle: ";
			S = S + " X=" + P.X;
			S = S + " Y=" + P.Y;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportPolyLine(CADPolyLine Sender)
		{
			DPoint P;
			string S = "";
			CADVertex Vertex;
			if(Sender.Closed)
				S = S + " Points of Rect: ";
			else
				S = S + " Points of PolyLine: ";
			for(int i = 0; i < Sender.Count; i++)
			{
				S = S + (char)13 + (char)10;
				S = S + " P" + (i + 1) + ": ";
				Vertex = ((CADVertex)Sender.Entities[i]);
				P = CADParams.matrix.PtXMat(Vertex.Point);
				S = S + " X=" + P.X;
				S = S + " Y=" + P.Y;
				S = S + " Z=" + P.Z;
			}
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}
		//To compile the project you need the extended version of the CADImport .NET library
		//that allows to access CAD entities directly.  You can get this version of the 
		//library free of charge by emailing your request to: info@cadsofttools.com
		private void ImportAttdef(CADAttdef Sender)
		{
			DPoint P;
			string S = "", S1 = "", S2 = "";
			CADAttrib CurAttrib;
			DRect vBox;
			S1 = ((CADText)Sender).Text;
			P = CADParams.matrix.PtXMat(((CADText)Sender).StartPoint);
			S2 = " Angle=" + ((CADText)Sender).Rotation;
			if(CADParams.insert != null)
			{
				CurAttrib = CADParams.insert.Attrib(S1,ref P);
				if(CurAttrib != null) 
				{
					S1 = CurAttrib.Text;
					vBox = CurAttrib.Box;
					P = vBox.TopLeft;
					S2 = " Angle=" + CurAttrib.Rotation;
				}
			}
			S = S + " Start point of Attdef: ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + P.X;
			S = S + (char)13 + (char)10;
			S = S + " Y=" + P.Y;
			S = S + (char)13 + (char)10;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			S = S + " Text of Attdef: " + S1;
			S = S + S2;
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportText(CADText Sender)
		{
			DPoint P;
			string S = "", S1 = "";
			CADConst.DoScale2D(ref CADParams);
			S1 = Sender.Text;
			DPoint tmp = Sender.StartPoint;
			tmp.Y += Sender.Height * 1.3; //for not shx
			P = CADParams.matrix.PtXMat(tmp);
			S = S + " Start point of Text: ";
			S = S + (char)13 + (char)10;
			S = S + " X=" + P.X;
			S = S + (char)13 + (char)10;
			S = S + " Y=" + P.Y;
			S = S + (char)13 + (char)10;
			S = S + " Z=" + P.Z;
			S = S + (char)13 + (char)10;
			S = S + " The text is: " + S1;
			S = S + " Angle=" + Sender.Rotation + CADParams.angle;
			S = S + (char)13 + (char)10;
			//text size and coordinates
			DPoint d1 = new DPoint(Sender.Box.left, Sender.Box.top, Sender.Box.z1);
			DPoint d2 = new DPoint(Sender.Box.right, Sender.Box.bottom, Sender.Box.z2);
			Point p1 = FCADImage.GetPoint(d1);
			Point p2 = FCADImage.GetPoint(d2);
			Point p3 = FCADImage.GetPoint(P);
			int left = p3.X;
			int top = p3.Y;
			int width = (p2.X - p1.X);
			int height = (p2.Y - p1.Y);
			S = S + "Box size: ";
			S = S + " Left: " + P.X; 
			S = S + " Top: " + P.Y; 
			S = S + " Width: " + Sender.Box.Width; 
			S = S + " Height: " + Math.Abs(Sender.Box.Height); 
			S = S + (char)13 + (char)10;
			S = S + "Box size(screen): ";
			S = S + " Left: " + left; 
			S = S + " Top: " + top; 
			S = S + " Width: " + width; 
			S = S + " Height: " + height; 
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void ImportSpline(CADSpline sender)
		{
			DPoint P;
			string S = "";
			int I;
			CADVertex Vertex;
			S = S + " Points of Spline: ";
			for(I = 0; I < sender.Count; I++)
			{
				S = S + (char)13 + (char)10;
				S = S + " P" + (I + 1) + ": ";
				Vertex = ((CADVertex)sender.Entities[I]);
				P = CADParams.matrix.PtXMat(Vertex.Point);
				S = S + " X=" + P.X;
				S = S + " Y=" + P.Y;
				S = S + " Z=" + P.Z;
			}
			S = S + (char)13 + (char)10;
			TextFile.Add(S);
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			wh = 1f;
			curClRect = cadPictBox.ClientRectangle;
			#region protect
#if protect
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.FloatingLicRegister();
			}
			else	
			{
				Protection.Register();
			}
#else
			Protection.Register();
#endif
#endif
			#endregion
			#region demo
			#if Demo
				DemoForm d1 = new DemoForm();
				d1.ShowDialog();
			#endif
			#endregion demo
			CADConst.UseSHXFonts = false;
			CADConst.UseMultyTTFFonts = true;
			CADConst.UseTTFFonts = true;
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			#region protect
			#if protect
				regFrm.ShowDialog();
			#endif
			#endregion
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			#region protect
#if protect
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.DisableFloating();
			}
			else
			{
				Protection.CloseApplication();
			}
#else
			Protection.CloseApplication();
#endif
#endif
			#endregion
		}

		private void miFloatLic_Click(object sender, System.EventArgs e)
		{
			#region protect
			#if floatprotect
				floatLicFrm.ShowDialog();
			#endif
			#endregion
		}
	}
}
