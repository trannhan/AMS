'To compile the project you need the extended version of the CADImport .NET library
'that allows to access CAD entities directly.  You can get this version of the 
'library free of charge by emailing your request to: info@cadsofttools.com
Imports CADImport
Imports CADImportForm
Imports System.IO
Imports System.Drawing.Imaging
Imports HPGL2
Imports RasterImage

Public Class MainForm
    Inherits System.Windows.Forms.Form

    Private Const OnMouseScroll As Integer = 522
    Private lForm As LayerForm = New LayerForm
#Region "protect"
#If protect Then
    Private regFrm As RegForm
#End If
#If (protect And floatprotect) Then
    Private floatLicFrm As FloatLicForm
#End If
#End Region
    Private pos As PointF = New PointF
    Private curClRect As Rectangle
    Private wh As Single
    Private TextFile As ArrayList = New ArrayList
    Private cX, cY As Integer
    Private det1 As Boolean
    Private Orb3D As Orbit3D = New Orbit3D
    Public Shared FCADImage As CADImage
    Private scl As Single = 1
    Private sclRect As DPoint
    Private layouts As ArrayList = New ArrayList
    Private aboutFrm As AboutForm = New AboutForm
    Private vPt As DPoint
    Private old_x, old_y As Integer
    Private shxFrm As SHXForm = New SHXForm
    Private old_Pos As PointF
    Private prev_scale As Single
    Private deactiv As Boolean
    Private CADParams As CADIterate
    Private dl1 As ItemCheckEventHandler
    Private Shared ReadOnly HPGLExt As ArrayList

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
#If (protect And floatprotect) Then
        floatLicFrm = New FloatLicForm
        AddHandler Me.floatLicFrm.Change, New System.EventHandler(AddressOf Me.InvalidateImage)
#End If
#If protect Then
        regFrm = New RegForm
#End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call
        Initial3DOrbit()
#If ((Not floatprotect) And protect) Then
        Me.miFloatLic.Enabled = False
#End If
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents openFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents stBar As System.Windows.Forms.StatusBar
    Public WithEvents sbOpen As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbscl As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbCoord As System.Windows.Forms.StatusBarPanel
    Friend WithEvents saveImgDlg As System.Windows.Forms.SaveFileDialog
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents mFile As System.Windows.Forms.MenuItem
    Friend WithEvents mOpenFile As System.Windows.Forms.MenuItem
    Friend WithEvents mSaveFile As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mExit As System.Windows.Forms.MenuItem
    Friend WithEvents mView As System.Windows.Forms.MenuItem
    Friend WithEvents mScale As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem22 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents pnlLayouts As System.Windows.Forms.Panel
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents dlgSaveEnt As System.Windows.Forms.SaveFileDialog
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents miFloatLic As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.stBar = New System.Windows.Forms.StatusBar
        Me.sbOpen = New System.Windows.Forms.StatusBarPanel
        Me.sbscl = New System.Windows.Forms.StatusBarPanel
        Me.sbCoord = New System.Windows.Forms.StatusBarPanel
        Me.saveImgDlg = New System.Windows.Forms.SaveFileDialog
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.mFile = New System.Windows.Forms.MenuItem
        Me.mOpenFile = New System.Windows.Forms.MenuItem
        Me.mSaveFile = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.mExit = New System.Windows.Forms.MenuItem
        Me.mView = New System.Windows.Forms.MenuItem
        Me.mScale = New System.Windows.Forms.MenuItem
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        Me.menuItem6 = New System.Windows.Forms.MenuItem
        Me.menuItem7 = New System.Windows.Forms.MenuItem
        Me.menuItem8 = New System.Windows.Forms.MenuItem
        Me.menuItem22 = New System.Windows.Forms.MenuItem
        Me.menuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.miFloatLic = New System.Windows.Forms.MenuItem
        Me.menuItem10 = New System.Windows.Forms.MenuItem
        Me.pnlLayouts = New System.Windows.Forms.Panel
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.dlgSaveEnt = New System.Windows.Forms.SaveFileDialog
        CType(Me.sbOpen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbscl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbCoord, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLayouts.SuspendLayout()
        Me.SuspendLayout()
        '
        'pictureBox1
        '
        Me.pictureBox1.BackColor = System.Drawing.Color.White
        Me.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(712, 414)
        Me.pictureBox1.TabIndex = 11
        Me.pictureBox1.TabStop = False
        '
        'openFileDialog1
        '
        Me.openFileDialog1.DefaultExt = "*.dxf"
        Me.openFileDialog1.Filter = "All(*.dxf,*.dwg,*.hpg,*.plt,*.rtl, *.spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1" & _
        ", *.hp, *.plo, *.hg,*.hgl,*.cgm, *.bmp,*.jpg, *.jpeg,*.tiff, *.gif, *.ico, *.cur" & _
        ", *.png, *.emf, *.wmf)|*.bmp;*.jpg;*.jpeg;*.tiff; *.gif; *.ico;*.dxf;*.dwg;*.hpg" & _
        ";*.plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;" & _
        "*.hgl;*.cur;*.png; *.emf; *.wmf; *.cgm|CAD files(*.dxf, *.dwg)|*.dxf;*.dwg|All r" & _
        "aster files (*.bmp,*.jpg, *.jpeg,*.tiff,*.tif, *.gif, *.ico, *.cur, *.png)|*.bmp" & _
        ";*.jpg;*.jpeg;*.tiff;*.tif; *.gif;*.ico;*.cur; *.png|Metafiles ( *.emf, *.wmf)| " & _
        "*.emf; *.wmf|DXF files(*.dxf)|*.dxf|DWG files(*.dwg)|*.dwg|BMP(*.bmp)|*.bmp|JPG(" & _
        "*.jpg, *.jpeg)| *.jpg; *.jpeg|TIFF(*.tiff, *.tif)|*.tiff;*.tif|GIF(*.gif)|*.gif|" & _
        "ICO(*.ico)|*.ico|PNG(*.png)|*.png|Cursors(*.cur)|*.cur|HPGL(*.hpg,*.plt,*.rtl, *" & _
        ".spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1, *.hp, *.plo, *.hg,*.hgl)|*.hpg;*." & _
        "plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;*.h" & _
        "gl|CGM (*.cgm)|*.cgm"
        '
        'stBar
        '
        Me.stBar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.stBar.Location = New System.Drawing.Point(0, 398)
        Me.stBar.Name = "stBar"
        Me.stBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbOpen, Me.sbscl, Me.sbCoord})
        Me.stBar.ShowPanels = True
        Me.stBar.Size = New System.Drawing.Size(712, 16)
        Me.stBar.TabIndex = 18
        '
        'sbOpen
        '
        Me.sbOpen.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents
        Me.sbOpen.MinWidth = 100
        Me.sbOpen.ToolTipText = "File Name"
        '
        'sbscl
        '
        Me.sbscl.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbscl.ToolTipText = "scl"
        Me.sbscl.Width = 545
        '
        'sbCoord
        '
        Me.sbCoord.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.sbCoord.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents
        Me.sbCoord.Text = "0 - 0 - 0"
        Me.sbCoord.Width = 51
        '
        'saveImgDlg
        '
        Me.saveImgDlg.Filter = "*.bmp|*.bmp|*.jpg|*.jpg|*.tiff|*.tiff|*.gif|*.gif|*.emf|*.emf"
        Me.saveImgDlg.RestoreDirectory = True
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFile, Me.mView, Me.menuItem9})
        '
        'mFile
        '
        Me.mFile.Index = 0
        Me.mFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mOpenFile, Me.mSaveFile, Me.menuItem2, Me.mExit})
        Me.mFile.Text = "&File"
        '
        'mOpenFile
        '
        Me.mOpenFile.Index = 0
        Me.mOpenFile.Text = "&Open File..."
        '
        'mSaveFile
        '
        Me.mSaveFile.Enabled = False
        Me.mSaveFile.Index = 1
        Me.mSaveFile.Text = "Save File As..."
        '
        'menuItem2
        '
        Me.menuItem2.Index = 2
        Me.menuItem2.Text = "-"
        '
        'mExit
        '
        Me.mExit.Index = 3
        Me.mExit.Text = "&Exit"
        '
        'mView
        '
        Me.mView.Index = 1
        Me.mView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mScale, Me.menuItem22})
        Me.mView.Text = "&View"
        '
        'mScale
        '
        Me.mScale.Enabled = False
        Me.mScale.Index = 0
        Me.mScale.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem3, Me.menuItem4, Me.menuItem5, Me.menuItem6, Me.menuItem7, Me.menuItem8})
        Me.mScale.Text = "&Scale"
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.Text = "10%"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.Text = "25%"
        '
        'menuItem4
        '
        Me.menuItem4.Index = 2
        Me.menuItem4.Text = "50%"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 3
        Me.menuItem5.Text = "100%"
        '
        'menuItem6
        '
        Me.menuItem6.Index = 4
        Me.menuItem6.Text = "200%"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 5
        Me.menuItem7.Text = "400%"
        '
        'menuItem8
        '
        Me.menuItem8.Index = 6
        Me.menuItem8.Text = "800%"
        '
        'menuItem22
        '
        Me.menuItem22.Index = 1
        Me.menuItem22.Text = "SHX Fonts..."
        '
        'menuItem9
        '
        Me.menuItem9.Index = 2
        Me.menuItem9.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem11, Me.miFloatLic, Me.menuItem10})
        Me.menuItem9.Text = "&?"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 0
        Me.MenuItem11.Text = "Register"
        '
        'miFloatLic
        '
        Me.miFloatLic.Index = 1
        Me.miFloatLic.Text = "Floating License Registration..."
        '
        'menuItem10
        '
        Me.menuItem10.Index = 2
        Me.menuItem10.Text = "&About"
        '
        'pnlLayouts
        '
        Me.pnlLayouts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlLayouts.Controls.Add(Me.button2)
        Me.pnlLayouts.Controls.Add(Me.button1)
        Me.pnlLayouts.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlLayouts.Location = New System.Drawing.Point(0, 0)
        Me.pnlLayouts.Name = "pnlLayouts"
        Me.pnlLayouts.Size = New System.Drawing.Size(712, 32)
        Me.pnlLayouts.TabIndex = 19
        '
        'button2
        '
        Me.button2.Enabled = False
        Me.button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.button2.Location = New System.Drawing.Point(96, 4)
        Me.button2.Name = "button2"
        Me.button2.TabIndex = 1
        Me.button2.Text = "Save"
        '
        'button1
        '
        Me.button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.button1.Location = New System.Drawing.Point(9, 3)
        Me.button1.Name = "button1"
        Me.button1.TabIndex = 0
        Me.button1.Text = "Load"
        '
        'dlgSaveEnt
        '
        Me.dlgSaveEnt.DefaultExt = "*.txt"
        Me.dlgSaveEnt.Filter = "*.txt|*.txt"
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(712, 414)
        Me.Controls.Add(Me.pnlLayouts)
        Me.Controls.Add(Me.stBar)
        Me.Controls.Add(Me.pictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.mainMenu1
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Viewer Vb.Net Demo"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.sbOpen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbscl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbCoord, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLayouts.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Shared Sub New()
        HPGLExt = New ArrayList(New String() {".HPG", ".PLT", ".RTL", ".SPL", ".PRN", ".GL2", ".HPGL2", ".HPGL", _
              ".HP2", ".HP1", ".HP", ".PLO", ".HG", ".HGL"})
    End Sub

    Private Sub Zoom(ByVal i As Single)
        If (Not Me.FCADImage Is Nothing) Then
            Me.scl = (Me.scl * i)
            If (Me.scl < 0.005!) Then
                Me.scl = 0.005!
            End If
            Me.pictureBox1.Invalidate()
            Me.pictureBox1_MouseMove(Me.pictureBox1, New MouseEventArgs(MouseButtons.Left, 0, CType(Me.old_Pos.X, Integer), CType(Me.old_Pos.Y, Integer), 0))
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Private Sub InvalidateImage(ByVal sender As Object, ByVal e As EventArgs)
        Me.pictureBox1().Invalidate()
    End Sub

    Private Sub Shift()
        Me.pos.X = (Me.old_Pos.X - (((Me.old_Pos.X - Me.pos.X) * Me.scl) / Me.prev_scale))
        Me.pos.Y = (Me.old_Pos.Y - (((Me.old_Pos.Y - Me.pos.Y) * Me.scl) / Me.prev_scale))
        Me.prev_scale = Me.scl
    End Sub

    <System.Security.Permissions.PermissionSetAttribute(System.Security.Permissions.SecurityAction.Demand, Name:="FullTrust")> _
     Protected Overrides Sub WndProc(ByRef m As Message)
        If ((m.Msg = 274) AndAlso (m.WParam.ToInt32 = 61472)) Then
            Me.deactiv = True
        End If
        If (m.Msg = 522) Then
            If (m.WParam.ToInt32 < 0) Then
                Me.Zoom(0.7!)
            Else
                Me.Zoom(1.3!)
            End If
        Else
            MyBase.WndProc(m)
        End If
    End Sub

    <System.STAThread()> _
      Public Shared Sub Main()
        Application.EnableVisualStyles()
        Application.DoEvents()
        Application.Run(New MainForm)
    End Sub

    Private Sub Initial3DOrbit()
        Me.Orb3D.Parent = Me.pictureBox1
    End Sub

    Private Sub Open_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mOpenFile.Click, button1.Click
        Me.pictureBox1.Visible = False
        If (Me.openFileDialog1.ShowDialog(Me) <> DialogResult.OK) Then
            Me.pictureBox1.Visible = True
        Else
            If (Not Me.openFileDialog1.FileName Is Nothing) Then
                If (Not Me.FCADImage Is Nothing) Then
                    Me.FCADImage.Dispose()
                    Me.FCADImage = Nothing
                End If
                Me.Cursor = Cursors.WaitCursor
                Me.stBar.Panels.Item(0).Text = "Load file..."
                Me.scl = 1.0!
                Me.prev_scale = 1.0!
                Me.pos = New PointF
                Dim ext As String = Path.GetExtension(Me.openFileDialog1.FileName).ToUpper()
                If (ext = ".DWG") Then
#If DWGModule Then
                    FCADImage = New DWG.DWGImage
                    FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
#Else
						NotSupportedInCurrentVersion()
						return

#End If
                Else
                    If (ext = ".DXF") Then
                        FCADImage = New CADImage
                        FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
                    Else
                        If (ext = ".CGM") Then
#If UseCGM Then
					dim tmpshx as Boolean = CADConst.UseSHXFonts
					if(CADConst.UseSHXFonts) then
						CADConst.UseMultyTTFFonts = true
						CADConst.UseTTFFonts = false
					else 
						CADConst.UseMultyTTFFonts = true
						CADConst.UseTTFFonts = true
					end if
					FCADImage = new CGM.CGMImage()
                            FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
#Else
                            NotSupportedInCurrentVersion()
                            Return
#End If
                        Else
                            If (HPGLExt.IndexOf(ext) <> -1) Then
                                FCADImage = New HPGLImage
                                FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
                            Else
                                FCADImage = New CADRasterImage(Me.pictureBox1)
                                FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
                            End If
                        End If
                    End If
                End If
            End If
            Me.FCADImage.UseWinEllipse = False
            Me.mScale.Enabled = True
            Me.mSaveFile.Enabled = True
            Me.button2.Enabled = True
            Me.Orb3D.CADImage = Me.FCADImage
            Me.Orb3D.Visible = False
            Me.Orb3D.Disable3dOrbit()
            Me.pictureBox1.Visible = True
            Me.DoResize()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub NotSupportedInCurrentVersion()
        Me.Cursor = Cursors.Default
        Me.pictureBox1().Visible = True
        Me.stBar.Panels(0).Text = "not supported"
        MessageBox.Show("Not supported in current version!", "CADImport .Net")
        Return
    End Sub


    Private Sub ZoomIn_Click(ByVal sender As Object, ByVal e As EventArgs)
        If (Not Me.FCADImage Is Nothing) Then
            Me.old_Pos = New PointF(CType((Me.pictureBox1.ClientRectangle.Width / 2), Single), CType((Me.pictureBox1.ClientRectangle.Height / 2), Single))
            Me.scl = (Me.scl * 2.0!)
            Me.pictureBox1.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Private Sub ZoomOut_Click(ByVal sender As Object, ByVal e As EventArgs)
        If (Not Me.FCADImage Is Nothing) Then
            Me.old_Pos = New PointF(CType((Me.pictureBox1.ClientRectangle.Width / 2), Single), CType((Me.pictureBox1.ClientRectangle.Height / 2), Single))
            Me.scl = (Me.scl / 2.0!)
            Me.pictureBox1.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Private Sub pictureBox1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles pictureBox1.Paint
        If (Not Me.FCADImage Is Nothing) Then
            Try
                Me.deactiv = False
                Me.Shift()
                Dim ef1 As New RectangleF(Me.pos.X, Me.pos.Y, (Me.curClRect.Width * Me.scl), (Me.curClRect.Height * Me.scl))
                Me.FCADImage.Draw(e.Graphics, ef1)
            Catch obj1 As Exception
            End Try
        End If
    End Sub

    Private Sub pictureBox1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles pictureBox1.MouseUp
        Me.det1 = False
        Me.pictureBox1.Cursor = Cursors.Default
        Me.pictureBox1.Invalidate()
    End Sub

    Private Sub pictureBox1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles pictureBox1.MouseDown
        If (e.Button = MouseButtons.Right) Then
            Form.ActiveForm.Cursor = Cursors.Hand
            Me.cX = e.X
            Me.cY = e.Y
            Me.det1 = True
        End If
    End Sub

    Private Sub pictureBox1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles pictureBox1.MouseMove
        Me.pictureBox1.Focus()
        If (Not Me.FCADImage Is Nothing) Then
            If (Me.det1 AndAlso Not Me.Orb3D.Visible) Then
                Me.pos.X = (Me.pos.X - (Me.cX - e.X))
                Me.pos.Y = (Me.pos.Y - (Me.cY - e.Y))
                Me.cX = e.X
                Me.cY = e.Y
                Me.pictureBox1.Invalidate()
            End If
            Me.old_Pos = New PointF(CType(e.X, Single), CType(e.Y, Single))
            Dim point1 As DPoint = Me.GetRealPointUsingsgImagePoint(CType(e.X, Single), CType(e.Y, Single))
            Me.stBar.Panels.Item(2).Text = String.Concat(New Object() {"", point1.X, " : ", point1.Y, " : 0"})
        End If
    End Sub

    Private Function GetRealPointUsingsgImagePoint(ByVal X As Single, ByVal Y As Single) As DPoint
        Dim point3 As DPoint
        Dim point4 As DPoint
        Dim point5 As DPoint
        Dim rectangle1 As Rectangle = New Rectangle
        rectangle1 = Me.curClRect
        Dim rect1 As New DRect(CType(rectangle1.Left, Double), CType(rectangle1.Top, Double), CType(rectangle1.Right, Double), CType(rectangle1.Bottom, Double))
        Dim single1 As Single = CType((Me.FCADImage.AbsHeight / Me.FCADImage.AbsWidth), Single)
        rect1.left = ((rect1.left * Me.scl) + Me.pos.X)
        rect1.right = ((rect1.right * Me.scl) + Me.pos.X)
        rect1.top = ((rect1.top * Me.scl) + Me.pos.Y)
        rect1.bottom = (rect1.top + ((rect1.right - rect1.left) * single1))
        Me.sclRect.X = (Me.FCADImage.AbsWidth / (rect1.right - rect1.left))
        Me.sclRect.Y = (Me.FCADImage.AbsHeight / (rect1.bottom - rect1.top))
        Dim point1 As New DPoint(0, 0, 0)
        Dim point2 As New DPoint(0, 0, 0)
        Dim rect2 As DRect = Me.FCADImage.Extents
        point1.X = (rect2.left + ((X - Me.pos.X) * Me.sclRect.X))
        point1.Y = (rect2.top - ((Y - Me.pos.Y) * Me.sclRect.Y))
        point5.X = (0.5 * (rect2.right + rect2.left))
        point5.Y = (0.5 * (rect2.top + rect2.bottom))
        point5.Z = (0.5 * (rect2.z2 + rect2.z1))
        point3.X = 1
        point3.Y = 0
        point3.Z = 0
        point4.X = 0
        point4.Y = 1
        point4.Z = 0
        point3 = Me.FCADImage.GetRealImagePoint(point3)
        point4 = Me.FCADImage.GetRealImagePoint(point4)
        Me.MoveToPosition(point1, point5, -1)
        point2.X = ((point1.X * point3.X) + (point1.Y * point3.Y))
        point2.Y = ((point1.X * point4.X) + (point1.Y * point4.Y))
        Me.MoveToPosition(point2, point5, 1)
        Return point2
    End Function

    Private Sub MoveToPosition(ByRef point As DPoint, ByVal aPos As DPoint, ByVal direction As Integer)
        point.X = (point.X + (direction * aPos.X))
        point.Y = (point.Y + (direction * aPos.Y))
        point.Z = (point.Z + (direction * aPos.Z))
    End Sub

    Private Sub ImgSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mSaveFile.Click
        If ((Not Me.FCADImage Is Nothing) AndAlso (Me.saveImgDlg.ShowDialog = DialogResult.OK)) Then
            If (Not Me.saveImgDlg.FileName Is Nothing) Then
                Dim text1 As String = Me.saveImgDlg.FileName
                Dim tmpRect As DRect = New DRect(0, 0, curClRect.Width * scl, curClRect.Height * scl)
                If (text1.ToUpper.IndexOf(".JPG") <> -1) Then
                    Me.FCADImage.SaveToFile(Me.saveImgDlg.FileName, ImageFormat.Jpeg, tmpRect)
                End If
                If (text1.ToUpper.IndexOf(".BMP") <> -1) Then
                    Me.FCADImage.SaveToFile(Me.saveImgDlg.FileName, ImageFormat.Bmp, tmpRect)
                End If
                If (text1.ToUpper.IndexOf(".TIFF") <> -1) Then
                    Me.FCADImage.SaveToFile(Me.saveImgDlg.FileName, ImageFormat.Tiff, tmpRect)
                End If
                If (text1.ToUpper.IndexOf(".GIF") <> -1) Then
                    Me.FCADImage.SaveToFile(Me.saveImgDlg.FileName, ImageFormat.Gif, tmpRect)
                End If
                If (text1.ToUpper.IndexOf(".EMF") <> -1) Then
                    Me.FCADImage.ExportToMetafile(Me.saveImgDlg.FileName, MyBase.ActiveForm, tmpRect)
                End If
            End If
            Me.DoResize()
        End If
    End Sub

    Private Sub Form1_Deactivate(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Deactivate
        Me.det1 = False
    End Sub

    Private Sub menuItem3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mExit.Click
        MyBase.Close()
    End Sub

    Private Sub menuItem1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuItem1.Click, menuItem3.Click, menuItem4.Click, menuItem5.Click, menuItem6.Click, menuItem7.Click, menuItem8.Click
        If (Not Me.FCADImage Is Nothing) Then
            Dim single1 As Single = Me.scl
            Select Case CType(sender, MenuItem).Index
                Case 0
                    single1 = 0.1!
                Case 1
                    single1 = 0.25!
                Case 2
                    single1 = 0.5!
                Case 3
                    single1 = 1.0!
                Case 4
                    single1 = 2.0!
                Case 5
                    single1 = 4.0!
                Case 6
                    single1 = 8.0!
            End Select
            Dim single2 As Single = (Me.pictureBox1.ClientRectangle.Width / 2)
            Dim single3 As Single = (Me.pictureBox1.ClientRectangle.Height / 2)
            Me.old_Pos = New PointF(single2, single3)
            Me.scl = single1
            Me.pictureBox1.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Private Sub ResetScaling()
        Me.scl = 1.0!
        Me.prev_scale = 1.0!
        Me.pos.X = ((Me.pictureBox1.ClientRectangle.Width - Me.curClRect.Width) / 2)
        Me.pos.Y = ((Me.pictureBox1.ClientRectangle.Height - Me.curClRect.Height) / 2)
    End Sub

    Private Sub SetLayList()
        If ((Me.lForm.lstViewLay.Items.Count = 0) AndAlso (Not Me.FCADImage Is Nothing)) Then
            ObjEntity.layersList = New String(Me.FCADImage.LayersCount - 1) {}
            Dim bitmap1 As New Bitmap(32, 16)
            Me.lForm.imgColor.Images.Clear()
            Me.lForm.listColor.Items.Clear()
            Dim num1 As Integer = 0
            Do While (num1 < Me.FCADImage.LayersCount)
                Dim text1 As String = Me.FCADImage.GetLayerName(num1)
                ObjEntity.layersList(num1) = text1
                Me.lForm.lstViewLay.Items.Add(New ListViewItem(New String() {text1}))
                Me.lForm.lstViewLay.Items.Item(num1).Checked = Me.FCADImage.GetLayerVisible(num1)
                Try
                    Dim color1 As Color = FCADImage.GetLayerColor(num1)
                    Dim graphics1 As Graphics = Graphics.FromImage(bitmap1)
                    graphics1.FillRectangle(New SolidBrush(color1), 0, 0, 16, 16)
                    graphics1.DrawRectangle(New Pen(Brushes.Black, 1.2!), 0, 0, 15, 15)
                    Me.lForm.imgColor.Images.Add(DirectCast(bitmap1.Clone, Bitmap))
                    Me.lForm.listColor.Items.Add(New ListViewItem(New String() {String.Empty}))
                    Me.lForm.listColor.Items.Item(num1).ImageIndex = num1
                Catch exception1 As Exception
                    MessageBox.Show((exception1.Message & " - " & exception1.StackTrace))
                End Try
                num1 += 1
            Loop
            Dim num2 As Integer = ((Me.lForm.imgColor.Images.Count * 18) + 18)
            Me.lForm.listColor.Height = num2
            Me.lForm.listColor.Top = 0
            Me.lForm.lstViewLay.Height = num2
            Me.lForm.lstViewLay.Top = 0
            AddHandler Me.lForm.lstViewLay.ItemCheck, Me.dl1
        End If
    End Sub

    Private Sub chLay_ItemCheck(ByVal sender As Object, ByVal e As ItemCheckEventArgs)
        If (e.NewValue = CheckState.Checked) Then
            Me.FCADImage.SetLayerVisible(e.Index, True)
        Else
            If (e.NewValue = CheckState.Unchecked) Then
                Me.FCADImage.SetLayerVisible(e.Index, False)
            End If
        End If
        Me.pictureBox1.Invalidate()
    End Sub

    Private Sub Go3dOrbit()
        Me.Orb3D.Visible = Not Me.Orb3D.Visible
        Me.det1 = False
        If Me.Orb3D.Visible Then
            Me.Orb3D.Enable3dOrbit()
        Else
            Me.Orb3D.Disable3dOrbit()
        End If
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Resize
        Me.DoResize()
    End Sub

    Private Sub DoResize()
        If ((Not Me.FCADImage Is Nothing) AndAlso Not Me.deactiv) Then
            Me.wh = CType((Me.FCADImage.AbsWidth / Me.FCADImage.AbsHeight), Single)
            Dim single1 As Single = (CType(Me.pictureBox1.ClientRectangle.Width, Single) / CType(Me.pictureBox1.ClientRectangle.Height, Single))
            Me.curClRect = Me.pictureBox1.ClientRectangle
            If (single1 > Me.wh) Then
                Me.curClRect.Width = CType((Me.curClRect.Height * Me.wh), Integer)
            Else
                If (single1 < Me.wh) Then
                    Me.curClRect.Height = CType((CType(Me.curClRect.Width, Single) / Me.wh), Integer)
                Else
                    Me.curClRect = Me.pictureBox1.ClientRectangle
                End If
            End If
            Me.pos.X = ((Me.pictureBox1.ClientRectangle.Width - Me.curClRect.Width) / 2)
            Me.pos.Y = ((Me.pictureBox1.ClientRectangle.Height - Me.curClRect.Height) / 2)
            Me.pictureBox1.Invalidate()
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Disabled
        Me.wh = 1.0!
        Me.curClRect = Me.pictureBox1.ClientRectangle
#If protect Then
#If floatprotect Then
        If (Protection.LicenseType = LicenseType.Floating) Then
            Me.floatLicFrm.FloatingLicRegister()
        Else
            Protection.Register()
        End If
#Else
        Protection.Register()
#End If
#End If
    End Sub

    Private Sub menuItem10_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuItem10.Click
        Me.aboutFrm.ShowDialog()
    End Sub

    Private Sub menuItem22_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuItem22.Click
        Me.shxFrm.ShowDialog()
        CADConst.SHXSearchPaths = ""
        Dim num1 As Integer = 0
        Do While (num1 < Me.shxFrm.lstDir.Items.Count)
            Dim obj1 As Object = CADConst.SHXSearchPaths
            CADConst.SHXSearchPaths = String.Concat(New Object() {obj1, CADConst.SHXSearchPaths, Me.shxFrm.lstDir.Items.Item(num1), ";"})
            num1 += 1
        Loop
        If ((CADConst.SearchSHXPaths AndAlso (Not Me.openFileDialog1.FileName Is "")) AndAlso File.Exists(Me.openFileDialog1.FileName)) Then
            Me.FCADImage.LoadFromFile(Me.openFileDialog1.FileName)
            Me.pictureBox1.Invalidate()
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles button2.Click
        If ((Me.dlgSaveEnt.ShowDialog = DialogResult.OK) AndAlso (Not Me.dlgSaveEnt.FileName Is Nothing)) Then
            Me.ReadAll(Me.dlgSaveEnt.FileName)
        End If
    End Sub

    Private Sub ReadAll(ByVal aFileName As String)
        If (Not Me.FCADImage Is Nothing) Then
            Me.TextFile.Clear()
            Dim writer1 As StreamWriter = File.CreateText(aFileName)
            Me.CADParams = New CADIterate
            Me.CADParams.matrix = New CADMatrix
            Me.CADParams.matrix.data(0, 0) = 1
            Me.CADParams.matrix.data(1, 1) = 1
            Me.CADParams.matrix.data(2, 2) = 1
            Me.FCADImage.Converter.AutoInsert = True
            Me.FCADImage.Converter.Iterate(New CADEntityProc(AddressOf Me.ReadCADEntities), Me.CADParams)
            Dim num1 As Integer = 0
            Do While (num1 < Me.TextFile.Count)
                writer1.WriteLine(CType(Me.TextFile.Item(num1), String))
                num1 += 1
            Loop
            writer1.Close()
        End If
    End Sub

    Private Sub ReadCADEntities(ByVal Entity As CADEntity)
        Dim textArray1 As String() = New String() {"psSolid", "psDash", "psDot", "psDashDot"}
        Dim text1 As String = ("ClassName = " & Entity.ToString & "; Entity name = " & Entity.EntName)
        CADConst.DoScale2D(Me.CADParams)
        Dim layer1 As CADLayer = CADConst.EntLayer(Entity, Me.CADParams.insert)
        If (Not layer1 Is Nothing) Then
            text1 = (text1 & " layer = " & layer1.Name)
        End If
        text1 = (text1 & " style = " & textArray1(CType(CADConst.EntStyle(Entity), Integer)))
        Dim color1 As Color = CADConst.EntColor(Entity, Me.CADParams.insert)
        If (color1.Equals(CADConst.clNone)) Then
            text1 = (text1 & " color=black/white")
        Else
            text1 = (text1 & " color = " & color1.Name)
        End If
        Me.TextFile.Add(text1)
        If TypeOf Entity Is CADSolid Then
            Me.ImportSolid(CType(Entity, CADSolid))
        Else
            If TypeOf Entity Is CADLine Then
                Me.ImportLine(CType(Entity, CADLine))
            Else
                If TypeOf Entity Is CADEllipse Then
                    Me.ImportEllipse(CType(Entity, CADEllipse))
                Else
                    If TypeOf Entity Is CADArc Then
                        Me.ImportArc(CType(Entity, CADArc))
                    Else
                        If TypeOf Entity Is CADCircle Then
                            Me.ImportCircle(CType(Entity, CADCircle))
                        Else
                            If TypeOf Entity Is CADSpline Then
                                Me.ImportSpline(CType(Entity, CADSpline))
                            Else
                                If TypeOf Entity Is CADPolyLine Then
                                    Me.ImportPolyLine(CType(Entity, CADPolyLine))
                                Else
                                    If TypeOf Entity Is CADAttdef Then
                                        Me.ImportAttdef(CType(Entity, CADAttdef))
                                    Else
                                        If TypeOf Entity Is CADText Then
                                            Me.ImportText(CType(Entity, CADText))
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    'To compile the project you need the extended version of the CADImport .NET library
    'that allows to access CAD entities directly.  You can get this version of the 
    'library free of charge by emailing your request to: info@cadsofttools.com
    Private Sub ImportArc(ByVal Sender As CADArc)
        Dim text1 As String = ""
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.Point)
        text1 = (text1 & " Center of RoundArc: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Start Angle: " & Sender.StartAngle)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " End Angle: " & Sender.EndAngle)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Rx: " & Sender.Radius)
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportAttdef(ByVal Sender As CADAttdef)
        Dim text1 As String = ""
        Dim text2 As String = ""
        Dim text3 As String = ""
        text2 = Sender.Text
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.StartPoint)
        text3 = (" Angle=" & Sender.Rotation)
        If (Not Me.CADParams.insert Is Nothing) Then
            Dim attrib1 As CADAttrib = Me.CADParams.insert.Attrib(text2, point1)
            If (Not attrib1 Is Nothing) Then
                text2 = attrib1.Text
                point1 = attrib1.Box.TopLeft
                text3 = (" Angle=" & attrib1.Rotation)
            End If
        End If
        text1 = (text1 & " Start point of Attdef: ")
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Text of Attdef: " & text2)
        text1 = (text1 & text3)
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportCircle(ByVal Sender As CADCircle)
        Dim text1 As String = ""
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.Point)
        text1 = (text1 & " Center of Circle: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportEllipse(ByVal Sender As CADEllipse)
        Dim text1 As String = ""
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.Point)
        text1 = (text1 & " Center of Ellipse: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Start Angle: " & Sender.StartAngle)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " End Angle: " & Sender.EndAngle)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Rx: " & Sender.Radius)
        text1 = (text1 & " Ry: " & (Sender.Radius * Sender.Ratio))
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportLine(ByVal Sender As CADLine)
        Dim text1 As String = ""
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.Point)
        text1 = (text1 & " Begin point: ")
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        point1 = Me.CADParams.matrix.PtXMat(Sender.Point1)
        text1 = (text1 & " End point: ")
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportPolyLine(ByVal Sender As CADPolyLine)
        Dim text1 As String = ""
        If Sender.Closed Then
            text1 = (text1 & " Points of Rect: ")
        Else
            text1 = (text1 & " Points of PolyLine: ")
        End If
        Dim num1 As Integer = 0
        Do While (num1 < Sender.Count)
            text1 = (text1 & ChrW(13) & ChrW(10))
            text1 = String.Concat(New Object() {text1, " P", (num1 + 1), ": "})
            Dim vertex1 As CADVertex = CType(Sender.Entities.Item(num1), CADVertex)
            Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(vertex1.Point)
            text1 = (text1 & " X=" & point1.X)
            text1 = (text1 & " Y=" & point1.Y)
            text1 = (text1 & " Z=" & point1.Z)
            num1 += 1
        Loop
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportSolid(ByVal Sender As CADSolid)
        Dim text1 As String = ""
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.Point)
        text1 = (text1 & " P1: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        point1 = Me.CADParams.matrix.PtXMat(Sender.Point1)
        text1 = (text1 & " P2: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        point1 = Me.CADParams.matrix.PtXMat(Sender.Point3)
        text1 = (text1 & " P3: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        point1 = Me.CADParams.matrix.PtXMat(Sender.Point2)
        text1 = (text1 & " P4: ")
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportSpline(ByVal sender As CADSpline)
        Dim text1 As String = ""
        text1 = (text1 & " Points of Spline: ")
        Dim num1 As Integer = 0
        Do While (num1 < sender.Count)
            text1 = (text1 & ChrW(13) & ChrW(10))
            text1 = String.Concat(New Object() {text1, " P", (num1 + 1), ": "})
            Dim vertex1 As CADVertex = CType(sender.Entities.Item(num1), CADVertex)
            Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(vertex1.Point)
            text1 = (text1 & " X=" & point1.X)
            text1 = (text1 & " Y=" & point1.Y)
            text1 = (text1 & " Z=" & point1.Z)
            num1 += 1
        Loop
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub ImportText(ByVal Sender As CADText)
        Dim text1 As String = ""
        Dim text2 As String = ""
        CADConst.DoScale2D(Me.CADParams)
        text2 = Sender.Text
        Dim point1 As DPoint = Me.CADParams.matrix.PtXMat(Sender.StartPoint)
        text1 = (text1 & " Start point of Text: ")
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " X=" & point1.X)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Y=" & point1.Y)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " Z=" & point1.Z)
        text1 = (text1 & ChrW(13) & ChrW(10))
        text1 = (text1 & " The text is: " & text2)
        text1 = String.Concat(New Object() {text1, " Angle=", Sender.Rotation, Me.CADParams.angle})
        text1 = (text1 & ChrW(13) & ChrW(10))
        Me.TextFile.Add(text1)
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
#If protect Then
        regFrm.ShowDialog()
#End If
    End Sub

    Private Sub MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
#If protect Then
#If floatprotect Then
        If (Protection.LicenseType = LicenseType.Floating) Then
            Me.floatLicFrm.DisableFloating()
        Else

            Protection.CloseApplication()
        End If
#Else
        Protection.CloseApplication()
#End If
#End If
    End Sub

    Private Sub miFloatLic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miFloatLic.Click
#If floatprotect Then
        floatLicFrm.ShowDialog()
#End If
    End Sub
End Class
