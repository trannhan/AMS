Imports System.IO
Imports CADImportForm
Imports CADImportFaceModule

Public Class OptionsForm
    Inherits System.Windows.Forms.Form
    Private old_path As String
    Private mlng As MultipleLanguage = New MultipleLanguage(Me.GetType())


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents btDefPath As System.Windows.Forms.Button
    Friend WithEvents chbEnt As System.Windows.Forms.CheckBox
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdColorDraw As System.Windows.Forms.RadioButton
    Friend WithEvents rdDrawBlack As System.Windows.Forms.RadioButton
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbBlack As System.Windows.Forms.RadioButton
    Friend WithEvents rdbWhite As System.Windows.Forms.RadioButton
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents cbLang As System.Windows.Forms.ComboBox
    Friend WithEvents btClose As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents tbLnPath As System.Windows.Forms.TextBox
    Friend WithEvents fldBrow As System.Windows.Forms.FolderBrowserDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(OptionsForm))
        Me.button4 = New System.Windows.Forms.Button
        Me.button3 = New System.Windows.Forms.Button
        Me.btDefPath = New System.Windows.Forms.Button
        Me.chbEnt = New System.Windows.Forms.CheckBox
        Me.groupBox2 = New System.Windows.Forms.GroupBox
        Me.rdColorDraw = New System.Windows.Forms.RadioButton
        Me.rdDrawBlack = New System.Windows.Forms.RadioButton
        Me.button2 = New System.Windows.Forms.Button
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.rdbBlack = New System.Windows.Forms.RadioButton
        Me.rdbWhite = New System.Windows.Forms.RadioButton
        Me.label2 = New System.Windows.Forms.Label
        Me.cbLang = New System.Windows.Forms.ComboBox
        Me.btClose = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.label1 = New System.Windows.Forms.Label
        Me.tbLnPath = New System.Windows.Forms.TextBox
        Me.fldBrow = New System.Windows.Forms.FolderBrowserDialog
        Me.groupBox2.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'button4
        '
        Me.button4.AccessibleDescription = resources.GetString("button4.AccessibleDescription")
        Me.button4.AccessibleName = resources.GetString("button4.AccessibleName")
        Me.button4.Anchor = CType(resources.GetObject("button4.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.button4.BackgroundImage = CType(resources.GetObject("button4.BackgroundImage"), System.Drawing.Image)
        Me.button4.Dock = CType(resources.GetObject("button4.Dock"), System.Windows.Forms.DockStyle)
        Me.button4.Enabled = CType(resources.GetObject("button4.Enabled"), Boolean)
        Me.button4.FlatStyle = CType(resources.GetObject("button4.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.button4.Font = CType(resources.GetObject("button4.Font"), System.Drawing.Font)
        Me.button4.Image = CType(resources.GetObject("button4.Image"), System.Drawing.Image)
        Me.button4.ImageAlign = CType(resources.GetObject("button4.ImageAlign"), System.Drawing.ContentAlignment)
        Me.button4.ImageIndex = CType(resources.GetObject("button4.ImageIndex"), Integer)
        Me.button4.ImeMode = CType(resources.GetObject("button4.ImeMode"), System.Windows.Forms.ImeMode)
        Me.button4.Location = CType(resources.GetObject("button4.Location"), System.Drawing.Point)
        Me.button4.Name = "button4"
        Me.button4.RightToLeft = CType(resources.GetObject("button4.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.button4.Size = CType(resources.GetObject("button4.Size"), System.Drawing.Size)
        Me.button4.TabIndex = CType(resources.GetObject("button4.TabIndex"), Integer)
        Me.button4.Text = resources.GetString("button4.Text")
        Me.button4.TextAlign = CType(resources.GetObject("button4.TextAlign"), System.Drawing.ContentAlignment)
        Me.button4.Visible = CType(resources.GetObject("button4.Visible"), Boolean)
        '
        'button3
        '
        Me.button3.AccessibleDescription = resources.GetString("button3.AccessibleDescription")
        Me.button3.AccessibleName = resources.GetString("button3.AccessibleName")
        Me.button3.Anchor = CType(resources.GetObject("button3.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.button3.BackgroundImage = CType(resources.GetObject("button3.BackgroundImage"), System.Drawing.Image)
        Me.button3.Dock = CType(resources.GetObject("button3.Dock"), System.Windows.Forms.DockStyle)
        Me.button3.Enabled = CType(resources.GetObject("button3.Enabled"), Boolean)
        Me.button3.FlatStyle = CType(resources.GetObject("button3.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.button3.Font = CType(resources.GetObject("button3.Font"), System.Drawing.Font)
        Me.button3.Image = CType(resources.GetObject("button3.Image"), System.Drawing.Image)
        Me.button3.ImageAlign = CType(resources.GetObject("button3.ImageAlign"), System.Drawing.ContentAlignment)
        Me.button3.ImageIndex = CType(resources.GetObject("button3.ImageIndex"), Integer)
        Me.button3.ImeMode = CType(resources.GetObject("button3.ImeMode"), System.Windows.Forms.ImeMode)
        Me.button3.Location = CType(resources.GetObject("button3.Location"), System.Drawing.Point)
        Me.button3.Name = "button3"
        Me.button3.RightToLeft = CType(resources.GetObject("button3.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.button3.Size = CType(resources.GetObject("button3.Size"), System.Drawing.Size)
        Me.button3.TabIndex = CType(resources.GetObject("button3.TabIndex"), Integer)
        Me.button3.Text = resources.GetString("button3.Text")
        Me.button3.TextAlign = CType(resources.GetObject("button3.TextAlign"), System.Drawing.ContentAlignment)
        Me.button3.Visible = CType(resources.GetObject("button3.Visible"), Boolean)
        '
        'btDefPath
        '
        Me.btDefPath.AccessibleDescription = resources.GetString("btDefPath.AccessibleDescription")
        Me.btDefPath.AccessibleName = resources.GetString("btDefPath.AccessibleName")
        Me.btDefPath.Anchor = CType(resources.GetObject("btDefPath.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btDefPath.BackgroundImage = CType(resources.GetObject("btDefPath.BackgroundImage"), System.Drawing.Image)
        Me.btDefPath.Dock = CType(resources.GetObject("btDefPath.Dock"), System.Windows.Forms.DockStyle)
        Me.btDefPath.Enabled = CType(resources.GetObject("btDefPath.Enabled"), Boolean)
        Me.btDefPath.FlatStyle = CType(resources.GetObject("btDefPath.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btDefPath.Font = CType(resources.GetObject("btDefPath.Font"), System.Drawing.Font)
        Me.btDefPath.Image = CType(resources.GetObject("btDefPath.Image"), System.Drawing.Image)
        Me.btDefPath.ImageAlign = CType(resources.GetObject("btDefPath.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btDefPath.ImageIndex = CType(resources.GetObject("btDefPath.ImageIndex"), Integer)
        Me.btDefPath.ImeMode = CType(resources.GetObject("btDefPath.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btDefPath.Location = CType(resources.GetObject("btDefPath.Location"), System.Drawing.Point)
        Me.btDefPath.Name = "btDefPath"
        Me.btDefPath.RightToLeft = CType(resources.GetObject("btDefPath.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btDefPath.Size = CType(resources.GetObject("btDefPath.Size"), System.Drawing.Size)
        Me.btDefPath.TabIndex = CType(resources.GetObject("btDefPath.TabIndex"), Integer)
        Me.btDefPath.Text = resources.GetString("btDefPath.Text")
        Me.btDefPath.TextAlign = CType(resources.GetObject("btDefPath.TextAlign"), System.Drawing.ContentAlignment)
        Me.btDefPath.Visible = CType(resources.GetObject("btDefPath.Visible"), Boolean)
        '
        'chbEnt
        '
        Me.chbEnt.AccessibleDescription = resources.GetString("chbEnt.AccessibleDescription")
        Me.chbEnt.AccessibleName = resources.GetString("chbEnt.AccessibleName")
        Me.chbEnt.Anchor = CType(resources.GetObject("chbEnt.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.chbEnt.Appearance = CType(resources.GetObject("chbEnt.Appearance"), System.Windows.Forms.Appearance)
        Me.chbEnt.BackgroundImage = CType(resources.GetObject("chbEnt.BackgroundImage"), System.Drawing.Image)
        Me.chbEnt.CheckAlign = CType(resources.GetObject("chbEnt.CheckAlign"), System.Drawing.ContentAlignment)
        Me.chbEnt.Dock = CType(resources.GetObject("chbEnt.Dock"), System.Windows.Forms.DockStyle)
        Me.chbEnt.Enabled = CType(resources.GetObject("chbEnt.Enabled"), Boolean)
        Me.chbEnt.FlatStyle = CType(resources.GetObject("chbEnt.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.chbEnt.Font = CType(resources.GetObject("chbEnt.Font"), System.Drawing.Font)
        Me.chbEnt.Image = CType(resources.GetObject("chbEnt.Image"), System.Drawing.Image)
        Me.chbEnt.ImageAlign = CType(resources.GetObject("chbEnt.ImageAlign"), System.Drawing.ContentAlignment)
        Me.chbEnt.ImageIndex = CType(resources.GetObject("chbEnt.ImageIndex"), Integer)
        Me.chbEnt.ImeMode = CType(resources.GetObject("chbEnt.ImeMode"), System.Windows.Forms.ImeMode)
        Me.chbEnt.Location = CType(resources.GetObject("chbEnt.Location"), System.Drawing.Point)
        Me.chbEnt.Name = "chbEnt"
        Me.chbEnt.RightToLeft = CType(resources.GetObject("chbEnt.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.chbEnt.Size = CType(resources.GetObject("chbEnt.Size"), System.Drawing.Size)
        Me.chbEnt.TabIndex = CType(resources.GetObject("chbEnt.TabIndex"), Integer)
        Me.chbEnt.Text = resources.GetString("chbEnt.Text")
        Me.chbEnt.TextAlign = CType(resources.GetObject("chbEnt.TextAlign"), System.Drawing.ContentAlignment)
        Me.chbEnt.Visible = CType(resources.GetObject("chbEnt.Visible"), Boolean)
        '
        'groupBox2
        '
        Me.groupBox2.AccessibleDescription = resources.GetString("groupBox2.AccessibleDescription")
        Me.groupBox2.AccessibleName = resources.GetString("groupBox2.AccessibleName")
        Me.groupBox2.Anchor = CType(resources.GetObject("groupBox2.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.groupBox2.BackgroundImage = CType(resources.GetObject("groupBox2.BackgroundImage"), System.Drawing.Image)
        Me.groupBox2.Controls.Add(Me.rdColorDraw)
        Me.groupBox2.Controls.Add(Me.rdDrawBlack)
        Me.groupBox2.Dock = CType(resources.GetObject("groupBox2.Dock"), System.Windows.Forms.DockStyle)
        Me.groupBox2.Enabled = CType(resources.GetObject("groupBox2.Enabled"), Boolean)
        Me.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.groupBox2.Font = CType(resources.GetObject("groupBox2.Font"), System.Drawing.Font)
        Me.groupBox2.ImeMode = CType(resources.GetObject("groupBox2.ImeMode"), System.Windows.Forms.ImeMode)
        Me.groupBox2.Location = CType(resources.GetObject("groupBox2.Location"), System.Drawing.Point)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.RightToLeft = CType(resources.GetObject("groupBox2.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.groupBox2.Size = CType(resources.GetObject("groupBox2.Size"), System.Drawing.Size)
        Me.groupBox2.TabIndex = CType(resources.GetObject("groupBox2.TabIndex"), Integer)
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = resources.GetString("groupBox2.Text")
        Me.groupBox2.Visible = CType(resources.GetObject("groupBox2.Visible"), Boolean)
        '
        'rdColorDraw
        '
        Me.rdColorDraw.AccessibleDescription = resources.GetString("rdColorDraw.AccessibleDescription")
        Me.rdColorDraw.AccessibleName = resources.GetString("rdColorDraw.AccessibleName")
        Me.rdColorDraw.Anchor = CType(resources.GetObject("rdColorDraw.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.rdColorDraw.Appearance = CType(resources.GetObject("rdColorDraw.Appearance"), System.Windows.Forms.Appearance)
        Me.rdColorDraw.BackgroundImage = CType(resources.GetObject("rdColorDraw.BackgroundImage"), System.Drawing.Image)
        Me.rdColorDraw.CheckAlign = CType(resources.GetObject("rdColorDraw.CheckAlign"), System.Drawing.ContentAlignment)
        Me.rdColorDraw.Dock = CType(resources.GetObject("rdColorDraw.Dock"), System.Windows.Forms.DockStyle)
        Me.rdColorDraw.Enabled = CType(resources.GetObject("rdColorDraw.Enabled"), Boolean)
        Me.rdColorDraw.FlatStyle = CType(resources.GetObject("rdColorDraw.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.rdColorDraw.Font = CType(resources.GetObject("rdColorDraw.Font"), System.Drawing.Font)
        Me.rdColorDraw.Image = CType(resources.GetObject("rdColorDraw.Image"), System.Drawing.Image)
        Me.rdColorDraw.ImageAlign = CType(resources.GetObject("rdColorDraw.ImageAlign"), System.Drawing.ContentAlignment)
        Me.rdColorDraw.ImageIndex = CType(resources.GetObject("rdColorDraw.ImageIndex"), Integer)
        Me.rdColorDraw.ImeMode = CType(resources.GetObject("rdColorDraw.ImeMode"), System.Windows.Forms.ImeMode)
        Me.rdColorDraw.Location = CType(resources.GetObject("rdColorDraw.Location"), System.Drawing.Point)
        Me.rdColorDraw.Name = "rdColorDraw"
        Me.rdColorDraw.RightToLeft = CType(resources.GetObject("rdColorDraw.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.rdColorDraw.Size = CType(resources.GetObject("rdColorDraw.Size"), System.Drawing.Size)
        Me.rdColorDraw.TabIndex = CType(resources.GetObject("rdColorDraw.TabIndex"), Integer)
        Me.rdColorDraw.Text = resources.GetString("rdColorDraw.Text")
        Me.rdColorDraw.TextAlign = CType(resources.GetObject("rdColorDraw.TextAlign"), System.Drawing.ContentAlignment)
        Me.rdColorDraw.Visible = CType(resources.GetObject("rdColorDraw.Visible"), Boolean)
        '
        'rdDrawBlack
        '
        Me.rdDrawBlack.AccessibleDescription = resources.GetString("rdDrawBlack.AccessibleDescription")
        Me.rdDrawBlack.AccessibleName = resources.GetString("rdDrawBlack.AccessibleName")
        Me.rdDrawBlack.Anchor = CType(resources.GetObject("rdDrawBlack.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.rdDrawBlack.Appearance = CType(resources.GetObject("rdDrawBlack.Appearance"), System.Windows.Forms.Appearance)
        Me.rdDrawBlack.BackgroundImage = CType(resources.GetObject("rdDrawBlack.BackgroundImage"), System.Drawing.Image)
        Me.rdDrawBlack.CheckAlign = CType(resources.GetObject("rdDrawBlack.CheckAlign"), System.Drawing.ContentAlignment)
        Me.rdDrawBlack.Dock = CType(resources.GetObject("rdDrawBlack.Dock"), System.Windows.Forms.DockStyle)
        Me.rdDrawBlack.Enabled = CType(resources.GetObject("rdDrawBlack.Enabled"), Boolean)
        Me.rdDrawBlack.FlatStyle = CType(resources.GetObject("rdDrawBlack.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.rdDrawBlack.Font = CType(resources.GetObject("rdDrawBlack.Font"), System.Drawing.Font)
        Me.rdDrawBlack.Image = CType(resources.GetObject("rdDrawBlack.Image"), System.Drawing.Image)
        Me.rdDrawBlack.ImageAlign = CType(resources.GetObject("rdDrawBlack.ImageAlign"), System.Drawing.ContentAlignment)
        Me.rdDrawBlack.ImageIndex = CType(resources.GetObject("rdDrawBlack.ImageIndex"), Integer)
        Me.rdDrawBlack.ImeMode = CType(resources.GetObject("rdDrawBlack.ImeMode"), System.Windows.Forms.ImeMode)
        Me.rdDrawBlack.Location = CType(resources.GetObject("rdDrawBlack.Location"), System.Drawing.Point)
        Me.rdDrawBlack.Name = "rdDrawBlack"
        Me.rdDrawBlack.RightToLeft = CType(resources.GetObject("rdDrawBlack.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.rdDrawBlack.Size = CType(resources.GetObject("rdDrawBlack.Size"), System.Drawing.Size)
        Me.rdDrawBlack.TabIndex = CType(resources.GetObject("rdDrawBlack.TabIndex"), Integer)
        Me.rdDrawBlack.Text = resources.GetString("rdDrawBlack.Text")
        Me.rdDrawBlack.TextAlign = CType(resources.GetObject("rdDrawBlack.TextAlign"), System.Drawing.ContentAlignment)
        Me.rdDrawBlack.Visible = CType(resources.GetObject("rdDrawBlack.Visible"), Boolean)
        '
        'button2
        '
        Me.button2.AccessibleDescription = resources.GetString("button2.AccessibleDescription")
        Me.button2.AccessibleName = resources.GetString("button2.AccessibleName")
        Me.button2.Anchor = CType(resources.GetObject("button2.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.button2.BackgroundImage = CType(resources.GetObject("button2.BackgroundImage"), System.Drawing.Image)
        Me.button2.Dock = CType(resources.GetObject("button2.Dock"), System.Windows.Forms.DockStyle)
        Me.button2.Enabled = CType(resources.GetObject("button2.Enabled"), Boolean)
        Me.button2.FlatStyle = CType(resources.GetObject("button2.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.button2.Font = CType(resources.GetObject("button2.Font"), System.Drawing.Font)
        Me.button2.Image = CType(resources.GetObject("button2.Image"), System.Drawing.Image)
        Me.button2.ImageAlign = CType(resources.GetObject("button2.ImageAlign"), System.Drawing.ContentAlignment)
        Me.button2.ImageIndex = CType(resources.GetObject("button2.ImageIndex"), Integer)
        Me.button2.ImeMode = CType(resources.GetObject("button2.ImeMode"), System.Windows.Forms.ImeMode)
        Me.button2.Location = CType(resources.GetObject("button2.Location"), System.Drawing.Point)
        Me.button2.Name = "button2"
        Me.button2.RightToLeft = CType(resources.GetObject("button2.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.button2.Size = CType(resources.GetObject("button2.Size"), System.Drawing.Size)
        Me.button2.TabIndex = CType(resources.GetObject("button2.TabIndex"), Integer)
        Me.button2.Text = resources.GetString("button2.Text")
        Me.button2.TextAlign = CType(resources.GetObject("button2.TextAlign"), System.Drawing.ContentAlignment)
        Me.button2.Visible = CType(resources.GetObject("button2.Visible"), Boolean)
        '
        'groupBox1
        '
        Me.groupBox1.AccessibleDescription = resources.GetString("groupBox1.AccessibleDescription")
        Me.groupBox1.AccessibleName = resources.GetString("groupBox1.AccessibleName")
        Me.groupBox1.Anchor = CType(resources.GetObject("groupBox1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.groupBox1.BackgroundImage = CType(resources.GetObject("groupBox1.BackgroundImage"), System.Drawing.Image)
        Me.groupBox1.Controls.Add(Me.rdbBlack)
        Me.groupBox1.Controls.Add(Me.rdbWhite)
        Me.groupBox1.Dock = CType(resources.GetObject("groupBox1.Dock"), System.Windows.Forms.DockStyle)
        Me.groupBox1.Enabled = CType(resources.GetObject("groupBox1.Enabled"), Boolean)
        Me.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.groupBox1.Font = CType(resources.GetObject("groupBox1.Font"), System.Drawing.Font)
        Me.groupBox1.ImeMode = CType(resources.GetObject("groupBox1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.groupBox1.Location = CType(resources.GetObject("groupBox1.Location"), System.Drawing.Point)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.RightToLeft = CType(resources.GetObject("groupBox1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.groupBox1.Size = CType(resources.GetObject("groupBox1.Size"), System.Drawing.Size)
        Me.groupBox1.TabIndex = CType(resources.GetObject("groupBox1.TabIndex"), Integer)
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = resources.GetString("groupBox1.Text")
        Me.groupBox1.Visible = CType(resources.GetObject("groupBox1.Visible"), Boolean)
        '
        'rdbBlack
        '
        Me.rdbBlack.AccessibleDescription = resources.GetString("rdbBlack.AccessibleDescription")
        Me.rdbBlack.AccessibleName = resources.GetString("rdbBlack.AccessibleName")
        Me.rdbBlack.Anchor = CType(resources.GetObject("rdbBlack.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.rdbBlack.Appearance = CType(resources.GetObject("rdbBlack.Appearance"), System.Windows.Forms.Appearance)
        Me.rdbBlack.BackgroundImage = CType(resources.GetObject("rdbBlack.BackgroundImage"), System.Drawing.Image)
        Me.rdbBlack.CheckAlign = CType(resources.GetObject("rdbBlack.CheckAlign"), System.Drawing.ContentAlignment)
        Me.rdbBlack.Dock = CType(resources.GetObject("rdbBlack.Dock"), System.Windows.Forms.DockStyle)
        Me.rdbBlack.Enabled = CType(resources.GetObject("rdbBlack.Enabled"), Boolean)
        Me.rdbBlack.FlatStyle = CType(resources.GetObject("rdbBlack.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.rdbBlack.Font = CType(resources.GetObject("rdbBlack.Font"), System.Drawing.Font)
        Me.rdbBlack.Image = CType(resources.GetObject("rdbBlack.Image"), System.Drawing.Image)
        Me.rdbBlack.ImageAlign = CType(resources.GetObject("rdbBlack.ImageAlign"), System.Drawing.ContentAlignment)
        Me.rdbBlack.ImageIndex = CType(resources.GetObject("rdbBlack.ImageIndex"), Integer)
        Me.rdbBlack.ImeMode = CType(resources.GetObject("rdbBlack.ImeMode"), System.Windows.Forms.ImeMode)
        Me.rdbBlack.Location = CType(resources.GetObject("rdbBlack.Location"), System.Drawing.Point)
        Me.rdbBlack.Name = "rdbBlack"
        Me.rdbBlack.RightToLeft = CType(resources.GetObject("rdbBlack.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.rdbBlack.Size = CType(resources.GetObject("rdbBlack.Size"), System.Drawing.Size)
        Me.rdbBlack.TabIndex = CType(resources.GetObject("rdbBlack.TabIndex"), Integer)
        Me.rdbBlack.Text = resources.GetString("rdbBlack.Text")
        Me.rdbBlack.TextAlign = CType(resources.GetObject("rdbBlack.TextAlign"), System.Drawing.ContentAlignment)
        Me.rdbBlack.Visible = CType(resources.GetObject("rdbBlack.Visible"), Boolean)
        '
        'rdbWhite
        '
        Me.rdbWhite.AccessibleDescription = resources.GetString("rdbWhite.AccessibleDescription")
        Me.rdbWhite.AccessibleName = resources.GetString("rdbWhite.AccessibleName")
        Me.rdbWhite.Anchor = CType(resources.GetObject("rdbWhite.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.rdbWhite.Appearance = CType(resources.GetObject("rdbWhite.Appearance"), System.Windows.Forms.Appearance)
        Me.rdbWhite.BackgroundImage = CType(resources.GetObject("rdbWhite.BackgroundImage"), System.Drawing.Image)
        Me.rdbWhite.CheckAlign = CType(resources.GetObject("rdbWhite.CheckAlign"), System.Drawing.ContentAlignment)
        Me.rdbWhite.Dock = CType(resources.GetObject("rdbWhite.Dock"), System.Windows.Forms.DockStyle)
        Me.rdbWhite.Enabled = CType(resources.GetObject("rdbWhite.Enabled"), Boolean)
        Me.rdbWhite.FlatStyle = CType(resources.GetObject("rdbWhite.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.rdbWhite.Font = CType(resources.GetObject("rdbWhite.Font"), System.Drawing.Font)
        Me.rdbWhite.Image = CType(resources.GetObject("rdbWhite.Image"), System.Drawing.Image)
        Me.rdbWhite.ImageAlign = CType(resources.GetObject("rdbWhite.ImageAlign"), System.Drawing.ContentAlignment)
        Me.rdbWhite.ImageIndex = CType(resources.GetObject("rdbWhite.ImageIndex"), Integer)
        Me.rdbWhite.ImeMode = CType(resources.GetObject("rdbWhite.ImeMode"), System.Windows.Forms.ImeMode)
        Me.rdbWhite.Location = CType(resources.GetObject("rdbWhite.Location"), System.Drawing.Point)
        Me.rdbWhite.Name = "rdbWhite"
        Me.rdbWhite.RightToLeft = CType(resources.GetObject("rdbWhite.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.rdbWhite.Size = CType(resources.GetObject("rdbWhite.Size"), System.Drawing.Size)
        Me.rdbWhite.TabIndex = CType(resources.GetObject("rdbWhite.TabIndex"), Integer)
        Me.rdbWhite.Text = resources.GetString("rdbWhite.Text")
        Me.rdbWhite.TextAlign = CType(resources.GetObject("rdbWhite.TextAlign"), System.Drawing.ContentAlignment)
        Me.rdbWhite.Visible = CType(resources.GetObject("rdbWhite.Visible"), Boolean)
        '
        'label2
        '
        Me.label2.AccessibleDescription = resources.GetString("label2.AccessibleDescription")
        Me.label2.AccessibleName = resources.GetString("label2.AccessibleName")
        Me.label2.Anchor = CType(resources.GetObject("label2.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.label2.AutoSize = CType(resources.GetObject("label2.AutoSize"), Boolean)
        Me.label2.Dock = CType(resources.GetObject("label2.Dock"), System.Windows.Forms.DockStyle)
        Me.label2.Enabled = CType(resources.GetObject("label2.Enabled"), Boolean)
        Me.label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.label2.Font = CType(resources.GetObject("label2.Font"), System.Drawing.Font)
        Me.label2.Image = CType(resources.GetObject("label2.Image"), System.Drawing.Image)
        Me.label2.ImageAlign = CType(resources.GetObject("label2.ImageAlign"), System.Drawing.ContentAlignment)
        Me.label2.ImageIndex = CType(resources.GetObject("label2.ImageIndex"), Integer)
        Me.label2.ImeMode = CType(resources.GetObject("label2.ImeMode"), System.Windows.Forms.ImeMode)
        Me.label2.Location = CType(resources.GetObject("label2.Location"), System.Drawing.Point)
        Me.label2.Name = "label2"
        Me.label2.RightToLeft = CType(resources.GetObject("label2.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.label2.Size = CType(resources.GetObject("label2.Size"), System.Drawing.Size)
        Me.label2.TabIndex = CType(resources.GetObject("label2.TabIndex"), Integer)
        Me.label2.Text = resources.GetString("label2.Text")
        Me.label2.TextAlign = CType(resources.GetObject("label2.TextAlign"), System.Drawing.ContentAlignment)
        Me.label2.Visible = CType(resources.GetObject("label2.Visible"), Boolean)
        '
        'cbLang
        '
        Me.cbLang.AccessibleDescription = resources.GetString("cbLang.AccessibleDescription")
        Me.cbLang.AccessibleName = resources.GetString("cbLang.AccessibleName")
        Me.cbLang.Anchor = CType(resources.GetObject("cbLang.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.cbLang.BackgroundImage = CType(resources.GetObject("cbLang.BackgroundImage"), System.Drawing.Image)
        Me.cbLang.Dock = CType(resources.GetObject("cbLang.Dock"), System.Windows.Forms.DockStyle)
        Me.cbLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbLang.Enabled = CType(resources.GetObject("cbLang.Enabled"), Boolean)
        Me.cbLang.Font = CType(resources.GetObject("cbLang.Font"), System.Drawing.Font)
        Me.cbLang.ImeMode = CType(resources.GetObject("cbLang.ImeMode"), System.Windows.Forms.ImeMode)
        Me.cbLang.IntegralHeight = CType(resources.GetObject("cbLang.IntegralHeight"), Boolean)
        Me.cbLang.ItemHeight = CType(resources.GetObject("cbLang.ItemHeight"), Integer)
        Me.cbLang.Location = CType(resources.GetObject("cbLang.Location"), System.Drawing.Point)
        Me.cbLang.MaxDropDownItems = CType(resources.GetObject("cbLang.MaxDropDownItems"), Integer)
        Me.cbLang.MaxLength = CType(resources.GetObject("cbLang.MaxLength"), Integer)
        Me.cbLang.Name = "cbLang"
        Me.cbLang.RightToLeft = CType(resources.GetObject("cbLang.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.cbLang.Size = CType(resources.GetObject("cbLang.Size"), System.Drawing.Size)
        Me.cbLang.TabIndex = CType(resources.GetObject("cbLang.TabIndex"), Integer)
        Me.cbLang.Tag = "-1"
        Me.cbLang.Text = resources.GetString("cbLang.Text")
        Me.cbLang.Visible = CType(resources.GetObject("cbLang.Visible"), Boolean)
        '
        'btClose
        '
        Me.btClose.AccessibleDescription = resources.GetString("btClose.AccessibleDescription")
        Me.btClose.AccessibleName = resources.GetString("btClose.AccessibleName")
        Me.btClose.Anchor = CType(resources.GetObject("btClose.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btClose.BackgroundImage = CType(resources.GetObject("btClose.BackgroundImage"), System.Drawing.Image)
        Me.btClose.Dock = CType(resources.GetObject("btClose.Dock"), System.Windows.Forms.DockStyle)
        Me.btClose.Enabled = CType(resources.GetObject("btClose.Enabled"), Boolean)
        Me.btClose.FlatStyle = CType(resources.GetObject("btClose.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btClose.Font = CType(resources.GetObject("btClose.Font"), System.Drawing.Font)
        Me.btClose.Image = CType(resources.GetObject("btClose.Image"), System.Drawing.Image)
        Me.btClose.ImageAlign = CType(resources.GetObject("btClose.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btClose.ImageIndex = CType(resources.GetObject("btClose.ImageIndex"), Integer)
        Me.btClose.ImeMode = CType(resources.GetObject("btClose.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btClose.Location = CType(resources.GetObject("btClose.Location"), System.Drawing.Point)
        Me.btClose.Name = "btClose"
        Me.btClose.RightToLeft = CType(resources.GetObject("btClose.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btClose.Size = CType(resources.GetObject("btClose.Size"), System.Drawing.Size)
        Me.btClose.TabIndex = CType(resources.GetObject("btClose.TabIndex"), Integer)
        Me.btClose.Text = resources.GetString("btClose.Text")
        Me.btClose.TextAlign = CType(resources.GetObject("btClose.TextAlign"), System.Drawing.ContentAlignment)
        Me.btClose.Visible = CType(resources.GetObject("btClose.Visible"), Boolean)
        '
        'button1
        '
        Me.button1.AccessibleDescription = resources.GetString("button1.AccessibleDescription")
        Me.button1.AccessibleName = resources.GetString("button1.AccessibleName")
        Me.button1.Anchor = CType(resources.GetObject("button1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.button1.BackgroundImage = CType(resources.GetObject("button1.BackgroundImage"), System.Drawing.Image)
        Me.button1.Dock = CType(resources.GetObject("button1.Dock"), System.Windows.Forms.DockStyle)
        Me.button1.Enabled = CType(resources.GetObject("button1.Enabled"), Boolean)
        Me.button1.FlatStyle = CType(resources.GetObject("button1.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.button1.Font = CType(resources.GetObject("button1.Font"), System.Drawing.Font)
        Me.button1.Image = CType(resources.GetObject("button1.Image"), System.Drawing.Image)
        Me.button1.ImageAlign = CType(resources.GetObject("button1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.button1.ImageIndex = CType(resources.GetObject("button1.ImageIndex"), Integer)
        Me.button1.ImeMode = CType(resources.GetObject("button1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.button1.Location = CType(resources.GetObject("button1.Location"), System.Drawing.Point)
        Me.button1.Name = "button1"
        Me.button1.RightToLeft = CType(resources.GetObject("button1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.button1.Size = CType(resources.GetObject("button1.Size"), System.Drawing.Size)
        Me.button1.TabIndex = CType(resources.GetObject("button1.TabIndex"), Integer)
        Me.button1.Text = resources.GetString("button1.Text")
        Me.button1.TextAlign = CType(resources.GetObject("button1.TextAlign"), System.Drawing.ContentAlignment)
        Me.button1.Visible = CType(resources.GetObject("button1.Visible"), Boolean)
        '
        'label1
        '
        Me.label1.AccessibleDescription = resources.GetString("label1.AccessibleDescription")
        Me.label1.AccessibleName = resources.GetString("label1.AccessibleName")
        Me.label1.Anchor = CType(resources.GetObject("label1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.label1.AutoSize = CType(resources.GetObject("label1.AutoSize"), Boolean)
        Me.label1.Dock = CType(resources.GetObject("label1.Dock"), System.Windows.Forms.DockStyle)
        Me.label1.Enabled = CType(resources.GetObject("label1.Enabled"), Boolean)
        Me.label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.label1.Font = CType(resources.GetObject("label1.Font"), System.Drawing.Font)
        Me.label1.Image = CType(resources.GetObject("label1.Image"), System.Drawing.Image)
        Me.label1.ImageAlign = CType(resources.GetObject("label1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.label1.ImageIndex = CType(resources.GetObject("label1.ImageIndex"), Integer)
        Me.label1.ImeMode = CType(resources.GetObject("label1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.label1.Location = CType(resources.GetObject("label1.Location"), System.Drawing.Point)
        Me.label1.Name = "label1"
        Me.label1.RightToLeft = CType(resources.GetObject("label1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.label1.Size = CType(resources.GetObject("label1.Size"), System.Drawing.Size)
        Me.label1.TabIndex = CType(resources.GetObject("label1.TabIndex"), Integer)
        Me.label1.Text = resources.GetString("label1.Text")
        Me.label1.TextAlign = CType(resources.GetObject("label1.TextAlign"), System.Drawing.ContentAlignment)
        Me.label1.Visible = CType(resources.GetObject("label1.Visible"), Boolean)
        '
        'tbLnPath
        '
        Me.tbLnPath.AccessibleDescription = resources.GetString("tbLnPath.AccessibleDescription")
        Me.tbLnPath.AccessibleName = resources.GetString("tbLnPath.AccessibleName")
        Me.tbLnPath.Anchor = CType(resources.GetObject("tbLnPath.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tbLnPath.AutoSize = CType(resources.GetObject("tbLnPath.AutoSize"), Boolean)
        Me.tbLnPath.BackgroundImage = CType(resources.GetObject("tbLnPath.BackgroundImage"), System.Drawing.Image)
        Me.tbLnPath.Dock = CType(resources.GetObject("tbLnPath.Dock"), System.Windows.Forms.DockStyle)
        Me.tbLnPath.Enabled = CType(resources.GetObject("tbLnPath.Enabled"), Boolean)
        Me.tbLnPath.Font = CType(resources.GetObject("tbLnPath.Font"), System.Drawing.Font)
        Me.tbLnPath.ImeMode = CType(resources.GetObject("tbLnPath.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tbLnPath.Location = CType(resources.GetObject("tbLnPath.Location"), System.Drawing.Point)
        Me.tbLnPath.MaxLength = CType(resources.GetObject("tbLnPath.MaxLength"), Integer)
        Me.tbLnPath.Multiline = CType(resources.GetObject("tbLnPath.Multiline"), Boolean)
        Me.tbLnPath.Name = "tbLnPath"
        Me.tbLnPath.PasswordChar = CType(resources.GetObject("tbLnPath.PasswordChar"), Char)
        Me.tbLnPath.RightToLeft = CType(resources.GetObject("tbLnPath.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tbLnPath.ScrollBars = CType(resources.GetObject("tbLnPath.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.tbLnPath.Size = CType(resources.GetObject("tbLnPath.Size"), System.Drawing.Size)
        Me.tbLnPath.TabIndex = CType(resources.GetObject("tbLnPath.TabIndex"), Integer)
        Me.tbLnPath.Tag = "-1"
        Me.tbLnPath.Text = resources.GetString("tbLnPath.Text")
        Me.tbLnPath.TextAlign = CType(resources.GetObject("tbLnPath.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.tbLnPath.Visible = CType(resources.GetObject("tbLnPath.Visible"), Boolean)
        Me.tbLnPath.WordWrap = CType(resources.GetObject("tbLnPath.WordWrap"), Boolean)
        '
        'fldBrow
        '
        Me.fldBrow.Description = resources.GetString("fldBrow.Description")
        Me.fldBrow.SelectedPath = resources.GetString("fldBrow.SelectedPath")
        '
        'OptionsForm
        '
        Me.AccessibleDescription = resources.GetString("$this.AccessibleDescription")
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.btDefPath)
        Me.Controls.Add(Me.chbEnt)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.cbLang)
        Me.Controls.Add(Me.btClose)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.tbLnPath)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximizeBox = False
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "OptionsForm"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SelectPath_Click(ByVal sender As Object, ByVal e As EventArgs) Handles button1.Click
        Me.fldBrow.ShowDialog()
        If Directory.Exists(Me.fldBrow.SelectedPath) Then
            Me.tbLnPath.Text = Me.fldBrow.SelectedPath
            MultipleLanguage.path = Me.fldBrow.SelectedPath
        End If
    End Sub

    Private Sub btDefPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btDefPath.Click
        MultipleLanguage.path = MainForm.cnstLngPath
        tbLnPath.Text = MultipleLanguage.path
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Dim tmp As String = Application.StartupPath
        MultipleLanguage.path = tmp
        tbLnPath.Text = tmp
    End Sub

    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        MultipleLanguage.lngList.Clear()
        'MainForm.ReloadLNG()   'sm
        Me.cbLang.Items.Clear()
        Dim num1 As Integer = 0
        Do While (num1 < MultipleLanguage.languagesList.Length)
            Dim text1 As String = MultipleLanguage.languagesList(num1)
            Me.cbLang.Items.Add(text1)
            If (MultipleLanguage.language.ToUpper Is text1.ToUpper) Then
                Me.cbLang.SelectedIndex = num1
            End If
            num1 += 1
        Loop
    End Sub

    Private Sub btClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btClose.Click
        MultipleLanguage.path = Me.old_path
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub OptionsForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim text1 As String
        Me.mlng.RestoreLanguage(MyBase.Controls, Nothing)
        Me.Text = "Options"
        Me.Text = Me.mlng.SetLanguage(MyBase.Controls, Nothing, Me.Text)
        Me.old_path = MultipleLanguage.path
        Me.tbLnPath.Text = MultipleLanguage.path
        Me.cbLang.Items.Clear()
        Dim num1 As Integer = 0
        Do While (num1 < MultipleLanguage.languagesList.Length)
            text1 = MultipleLanguage.languagesList(num1)
            Me.cbLang.Items.Add(text1)
            If (MultipleLanguage.language.ToUpper.Equals(text1.ToUpper)) Then
                Me.cbLang.SelectedIndex = num1
            End If
            num1 += 1
        Loop
        If Not (MainForm.settingsLst Is Nothing) Then
            Dim text2 As String = "BackgroundColor"
            text1 = "BLACK"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = CType(MainForm.settingsLst.Item(text2), String)
            End If
            If (text1.ToUpper.Equals("BLACK")) Then
                Me.rdbBlack.Checked = True
            Else
                Me.rdbWhite.Checked = True
            End If
            text2 = "ShowEntity"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.chbEnt.Checked = True
            Else
                Me.chbEnt.Checked = False
            End If
            text2 = "ColorDraw"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.rdColorDraw.Checked = True
            Else
                Me.rdDrawBlack.Checked = True
            End If
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Me.DialogResult = DialogResult.OK
        Dim text1 As String = "BackgroundColor"
        If MainForm.settingsLst.ContainsKey(text1) Then
            If Me.rdbBlack.Checked Then
                MainForm.settingsLst.Item(text1) = "Black"
            Else
                MainForm.settingsLst.Item(text1) = "White"
            End If
        End If
        text1 = "ShowEntity"
        If MainForm.settingsLst.ContainsKey(text1) Then
            MainForm.settingsLst.Item(text1) = Me.chbEnt.Checked
        End If
        text1 = "ColorDraw"
        If MainForm.settingsLst.ContainsKey(text1) Then
            MainForm.settingsLst.Item(text1) = Me.rdColorDraw.Checked
        End If
        Dim text2 As String = Me.tbLnPath.Text.Trim
        text1 = "LanguagePath"
        If Directory.Exists(text2) Then
            MainForm.settingsLst.Item(text1) = text2
        End If
        text1 = "Language"
        Dim num1 As Integer = Me.cbLang.SelectedIndex
        If (MainForm.settingsLst.ContainsKey(text1) AndAlso (num1 > -1)) Then
            MainForm.settingsLst.Item(text1) = (Me.cbLang.Items.Item(num1) & ".lng")
        End If
        text1 = "LanguageID"
        If (Me.cbLang.SelectedIndex >= 0) Then
            MainForm.settingsLst.Item(text1) = Me.cbLang.SelectedIndex
        End If
        MyBase.Close()
    End Sub
End Class
