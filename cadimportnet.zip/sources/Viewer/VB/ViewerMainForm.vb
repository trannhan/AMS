Imports CADImport
Imports CADImportForm
Imports System.IO
Imports System.Drawing.Imaging
Imports DWG
Imports RasterImage
Imports CADImportFaceModule
Imports HPGL2

Public Class MainForm
    Inherits System.Windows.Forms.Form

    Public Shared ReadOnly cnstLngPath As String = "..\..\..\Languages"
    Private Const OnMouseScroll As Integer = 522
    Private lForm As LayerForm = New LayerForm
    Private pos As PointF = New PointF
    Private curClRect As Rectangle
    Private wh As Single
    Private cX, cY As Integer
    Private det1 As Boolean
    Private Orb3D As Orbit3D = New Orbit3D
    Public Shared FCADImage As CADImage
    Private scl As Single = 1
    Private sclRect As DPoint
    Private layouts As ArrayList = New ArrayList
    Private aboutFrm As AboutForm = New AboutForm
    Private shxFrm As SHXForm = New SHXForm
    Private old_Pos As PointF
    Private prev_scale As Single
    Private deactiv As Boolean
    Private dl1 As ItemCheckEventHandler
#Region "protect"
#If protect Then
    Private regFrm As RegForm
#End If
#If (protect And floatprotect) Then
    Private floatLicFrm As FloatLicForm
#End If
#End Region
    Friend Shared lngFile As String = "Default"
    Friend mlng As MultipleLanguage = New MultipleLanguage(Me.GetType())
    Friend Shared settingsLst As SortedList
    Private svSet As SaveSettings
    Private ReadOnly fileSettingsName As String = Application.StartupPath + "\Settings.txt"
    Private curLngInd As Byte = 0
    Private colorDraw As Boolean = True
    Private optForm As OptionsForm = New OptionsForm
    Private prtForm As PrintingForm = New PrintingForm
    Private clipRectangle As ClipRect
    Private selectEntityMouseUp As MouseEventHandler
    Private Shared ReadOnly HPGLExt As ArrayList


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
#If (protect And floatprotect) Then
		floatLicFrm = new FloatLicForm()
        AddHandler Me.floatLicFrm.Change, New System.EventHandler(AddressOf Me.InvalidateImage)
#End If
#If protect Then
        regFrm = New RegForm
#End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call
        Initial3DOrbit()
#If ((Not floatprotect) And protect) Then
        Me.miFloatLic.Enabled = False
#End If
    End Sub



    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents openFileDlg As System.Windows.Forms.OpenFileDialog
    Friend WithEvents orbitViewMenu As System.Windows.Forms.ContextMenu
    Friend WithEvents InitialViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents TopViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents BottomViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents LeftViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents RightViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FrontViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents BackViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents SWViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents SEViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents NEViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents NWViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents setColorDlg As System.Windows.Forms.ColorDialog
    Friend WithEvents saveImgDlg As System.Windows.Forms.SaveFileDialog
    Friend WithEvents stBar As System.Windows.Forms.StatusBar
    Public WithEvents sbOpen As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbScale As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbCoord As System.Windows.Forms.StatusBarPanel
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents mainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents mFile As System.Windows.Forms.MenuItem
    Friend WithEvents mOpenFile As System.Windows.Forms.MenuItem
    Friend WithEvents mSaveFile As System.Windows.Forms.MenuItem
    Friend WithEvents printMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents closeMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mExit As System.Windows.Forms.MenuItem
    Friend WithEvents editMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents copyMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mView As System.Windows.Forms.MenuItem
    Friend WithEvents entitiesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents zoomInMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoomOutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mScale As System.Windows.Forms.MenuItem
    Friend WithEvents zoom10MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom25MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom50MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom100MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom200MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom400MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom800MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem29 As System.Windows.Forms.MenuItem
    Friend WithEvents shxMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents cADFilesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents colorMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents blackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents whiteBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents blackBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents changeBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem38 As System.Windows.Forms.MenuItem
    Friend WithEvents showLineWeightMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents arcsSplitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents dimShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents textsShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem43 As System.Windows.Forms.MenuItem
    Friend WithEvents layersShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents InitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents topMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents bottomMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents leftMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents rightMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents frontMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents backMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents swMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents seMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents neMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents nwMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents orbitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents helpMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItemReg As System.Windows.Forms.MenuItem
    Friend WithEvents aboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents printPrevItem As System.Windows.Forms.MenuItem
    Friend WithEvents printPrevDlg As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents print2Item As System.Windows.Forms.MenuItem
    Friend WithEvents pnlLayouts As System.Windows.Forms.Panel
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents cbLayouts As System.Windows.Forms.ComboBox
    Friend WithEvents tlbTool As System.Windows.Forms.ToolBar
    Friend WithEvents tlbOpen As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbZoomIn As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbZoomOut As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbWhite As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbBlack As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbColor As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlb3d As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbLay As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbArcPoly As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbBlackMode As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbColorMode As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbDefSize As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbTextShow As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbDimShow As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbSaveImageClip As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbPrint As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbSHX As System.Windows.Forms.ToolBarButton
    Friend WithEvents toolBtnImageList As System.Windows.Forms.ImageList
    Friend WithEvents cadPictBox As System.Windows.Forms.PictureBox
    Friend WithEvents trvPanel As System.Windows.Forms.Panel
    Friend WithEvents trvEntity As System.Windows.Forms.TreeView
    Friend WithEvents tlbRect As System.Windows.Forms.ToolBarButton
    Friend WithEvents mSaveAsDXF As System.Windows.Forms.MenuItem
    Friend WithEvents saveDXFDlg As System.Windows.Forms.SaveFileDialog
    Friend WithEvents propGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents miFloatLic As System.Windows.Forms.MenuItem
    Friend WithEvents tlbSelObject As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.openFileDlg = New System.Windows.Forms.OpenFileDialog
        Me.orbitViewMenu = New System.Windows.Forms.ContextMenu
        Me.InitialViewMenuItem = New System.Windows.Forms.MenuItem
        Me.TopViewMenuItem = New System.Windows.Forms.MenuItem
        Me.BottomViewMenuItem = New System.Windows.Forms.MenuItem
        Me.LeftViewMenuItem = New System.Windows.Forms.MenuItem
        Me.RightViewMenuItem = New System.Windows.Forms.MenuItem
        Me.FrontViewMenuItem = New System.Windows.Forms.MenuItem
        Me.BackViewMenuItem = New System.Windows.Forms.MenuItem
        Me.SWViewMenuItem = New System.Windows.Forms.MenuItem
        Me.SEViewMenuItem = New System.Windows.Forms.MenuItem
        Me.NEViewMenuItem = New System.Windows.Forms.MenuItem
        Me.NWViewMenuItem = New System.Windows.Forms.MenuItem
        Me.setColorDlg = New System.Windows.Forms.ColorDialog
        Me.saveImgDlg = New System.Windows.Forms.SaveFileDialog
        Me.stBar = New System.Windows.Forms.StatusBar
        Me.sbOpen = New System.Windows.Forms.StatusBarPanel
        Me.sbScale = New System.Windows.Forms.StatusBarPanel
        Me.sbCoord = New System.Windows.Forms.StatusBarPanel
        Me.splitter1 = New System.Windows.Forms.Splitter
        Me.mainMenu = New System.Windows.Forms.MainMenu
        Me.mFile = New System.Windows.Forms.MenuItem
        Me.mOpenFile = New System.Windows.Forms.MenuItem
        Me.mSaveFile = New System.Windows.Forms.MenuItem
        Me.mSaveAsDXF = New System.Windows.Forms.MenuItem
        Me.printMenuItem = New System.Windows.Forms.MenuItem
        Me.print2Item = New System.Windows.Forms.MenuItem
        Me.printPrevItem = New System.Windows.Forms.MenuItem
        Me.closeMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.mExit = New System.Windows.Forms.MenuItem
        Me.editMenuItem = New System.Windows.Forms.MenuItem
        Me.copyMenuItem = New System.Windows.Forms.MenuItem
        Me.mView = New System.Windows.Forms.MenuItem
        Me.entitiesMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem24 = New System.Windows.Forms.MenuItem
        Me.zoomInMenuItem = New System.Windows.Forms.MenuItem
        Me.zoomOutMenuItem = New System.Windows.Forms.MenuItem
        Me.mScale = New System.Windows.Forms.MenuItem
        Me.zoom10MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom25MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom50MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom100MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom200MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom400MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom800MenuItem = New System.Windows.Forms.MenuItem
        Me.fitMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem29 = New System.Windows.Forms.MenuItem
        Me.shxMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.cADFilesMenuItem = New System.Windows.Forms.MenuItem
        Me.colorMenuItem = New System.Windows.Forms.MenuItem
        Me.blackMenuItem = New System.Windows.Forms.MenuItem
        Me.whiteBackMenuItem = New System.Windows.Forms.MenuItem
        Me.blackBackMenuItem = New System.Windows.Forms.MenuItem
        Me.changeBackMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem38 = New System.Windows.Forms.MenuItem
        Me.showLineWeightMenuItem = New System.Windows.Forms.MenuItem
        Me.arcsSplitMenuItem = New System.Windows.Forms.MenuItem
        Me.dimShowMenuItem = New System.Windows.Forms.MenuItem
        Me.textsShowMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem43 = New System.Windows.Forms.MenuItem
        Me.layersShowMenuItem = New System.Windows.Forms.MenuItem
        Me.ViewMenuItem = New System.Windows.Forms.MenuItem
        Me.InitMenuItem = New System.Windows.Forms.MenuItem
        Me.topMenuItem = New System.Windows.Forms.MenuItem
        Me.bottomMenuItem = New System.Windows.Forms.MenuItem
        Me.leftMenuItem = New System.Windows.Forms.MenuItem
        Me.rightMenuItem = New System.Windows.Forms.MenuItem
        Me.frontMenuItem = New System.Windows.Forms.MenuItem
        Me.backMenuItem = New System.Windows.Forms.MenuItem
        Me.swMenuItem = New System.Windows.Forms.MenuItem
        Me.seMenuItem = New System.Windows.Forms.MenuItem
        Me.neMenuItem = New System.Windows.Forms.MenuItem
        Me.nwMenuItem = New System.Windows.Forms.MenuItem
        Me.orbitMenuItem = New System.Windows.Forms.MenuItem
        Me.helpMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.menuItemReg = New System.Windows.Forms.MenuItem
        Me.miFloatLic = New System.Windows.Forms.MenuItem
        Me.aboutMenuItem = New System.Windows.Forms.MenuItem
        Me.printPrevDlg = New System.Windows.Forms.PrintPreviewDialog
        Me.pnlLayouts = New System.Windows.Forms.Panel
        Me.label1 = New System.Windows.Forms.Label
        Me.cbLayouts = New System.Windows.Forms.ComboBox
        Me.tlbTool = New System.Windows.Forms.ToolBar
        Me.tlbOpen = New System.Windows.Forms.ToolBarButton
        Me.tlbZoomIn = New System.Windows.Forms.ToolBarButton
        Me.tlbZoomOut = New System.Windows.Forms.ToolBarButton
        Me.tlbSave = New System.Windows.Forms.ToolBarButton
        Me.tlbWhite = New System.Windows.Forms.ToolBarButton
        Me.tlbBlack = New System.Windows.Forms.ToolBarButton
        Me.tlbColor = New System.Windows.Forms.ToolBarButton
        Me.tlb3d = New System.Windows.Forms.ToolBarButton
        Me.tlbLay = New System.Windows.Forms.ToolBarButton
        Me.tlbArcPoly = New System.Windows.Forms.ToolBarButton
        Me.tlbBlackMode = New System.Windows.Forms.ToolBarButton
        Me.tlbColorMode = New System.Windows.Forms.ToolBarButton
        Me.tlbDefSize = New System.Windows.Forms.ToolBarButton
        Me.tlbTextShow = New System.Windows.Forms.ToolBarButton
        Me.tlbDimShow = New System.Windows.Forms.ToolBarButton
        Me.tlbSaveImageClip = New System.Windows.Forms.ToolBarButton
        Me.tlbPrint = New System.Windows.Forms.ToolBarButton
        Me.tlbSHX = New System.Windows.Forms.ToolBarButton
        Me.tlbRect = New System.Windows.Forms.ToolBarButton
        Me.tlbSelObject = New System.Windows.Forms.ToolBarButton
        Me.toolBtnImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.cadPictBox = New System.Windows.Forms.PictureBox
        Me.trvPanel = New System.Windows.Forms.Panel
        Me.trvEntity = New System.Windows.Forms.TreeView
        Me.propGrid = New System.Windows.Forms.PropertyGrid
        Me.saveDXFDlg = New System.Windows.Forms.SaveFileDialog
        CType(Me.sbOpen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbScale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbCoord, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLayouts.SuspendLayout()
        Me.trvPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'openFileDlg
        '
        Me.openFileDlg.DefaultExt = "*.dxf;*.dwg"
        Me.openFileDlg.Filter = resources.GetString("openFileDlg.Filter")
        Me.openFileDlg.ShowHelp = True
        Me.openFileDlg.Title = resources.GetString("openFileDlg.Title")
        '
        'orbitViewMenu
        '
        Me.orbitViewMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.InitialViewMenuItem, Me.TopViewMenuItem, Me.BottomViewMenuItem, Me.LeftViewMenuItem, Me.RightViewMenuItem, Me.FrontViewMenuItem, Me.BackViewMenuItem, Me.SWViewMenuItem, Me.SEViewMenuItem, Me.NEViewMenuItem, Me.NWViewMenuItem})
        Me.orbitViewMenu.RightToLeft = CType(resources.GetObject("orbitViewMenu.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'InitialViewMenuItem
        '
        Me.InitialViewMenuItem.Enabled = CType(resources.GetObject("InitialViewMenuItem.Enabled"), Boolean)
        Me.InitialViewMenuItem.Index = 0
        Me.InitialViewMenuItem.Shortcut = CType(resources.GetObject("InitialViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.InitialViewMenuItem.ShowShortcut = CType(resources.GetObject("InitialViewMenuItem.ShowShortcut"), Boolean)
        Me.InitialViewMenuItem.Text = resources.GetString("InitialViewMenuItem.Text")
        Me.InitialViewMenuItem.Visible = CType(resources.GetObject("InitialViewMenuItem.Visible"), Boolean)
        '
        'TopViewMenuItem
        '
        Me.TopViewMenuItem.Enabled = CType(resources.GetObject("TopViewMenuItem.Enabled"), Boolean)
        Me.TopViewMenuItem.Index = 1
        Me.TopViewMenuItem.Shortcut = CType(resources.GetObject("TopViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.TopViewMenuItem.ShowShortcut = CType(resources.GetObject("TopViewMenuItem.ShowShortcut"), Boolean)
        Me.TopViewMenuItem.Text = resources.GetString("TopViewMenuItem.Text")
        Me.TopViewMenuItem.Visible = CType(resources.GetObject("TopViewMenuItem.Visible"), Boolean)
        '
        'BottomViewMenuItem
        '
        Me.BottomViewMenuItem.Enabled = CType(resources.GetObject("BottomViewMenuItem.Enabled"), Boolean)
        Me.BottomViewMenuItem.Index = 2
        Me.BottomViewMenuItem.Shortcut = CType(resources.GetObject("BottomViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.BottomViewMenuItem.ShowShortcut = CType(resources.GetObject("BottomViewMenuItem.ShowShortcut"), Boolean)
        Me.BottomViewMenuItem.Text = resources.GetString("BottomViewMenuItem.Text")
        Me.BottomViewMenuItem.Visible = CType(resources.GetObject("BottomViewMenuItem.Visible"), Boolean)
        '
        'LeftViewMenuItem
        '
        Me.LeftViewMenuItem.Enabled = CType(resources.GetObject("LeftViewMenuItem.Enabled"), Boolean)
        Me.LeftViewMenuItem.Index = 3
        Me.LeftViewMenuItem.Shortcut = CType(resources.GetObject("LeftViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.LeftViewMenuItem.ShowShortcut = CType(resources.GetObject("LeftViewMenuItem.ShowShortcut"), Boolean)
        Me.LeftViewMenuItem.Text = resources.GetString("LeftViewMenuItem.Text")
        Me.LeftViewMenuItem.Visible = CType(resources.GetObject("LeftViewMenuItem.Visible"), Boolean)
        '
        'RightViewMenuItem
        '
        Me.RightViewMenuItem.Enabled = CType(resources.GetObject("RightViewMenuItem.Enabled"), Boolean)
        Me.RightViewMenuItem.Index = 4
        Me.RightViewMenuItem.Shortcut = CType(resources.GetObject("RightViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.RightViewMenuItem.ShowShortcut = CType(resources.GetObject("RightViewMenuItem.ShowShortcut"), Boolean)
        Me.RightViewMenuItem.Text = resources.GetString("RightViewMenuItem.Text")
        Me.RightViewMenuItem.Visible = CType(resources.GetObject("RightViewMenuItem.Visible"), Boolean)
        '
        'FrontViewMenuItem
        '
        Me.FrontViewMenuItem.Enabled = CType(resources.GetObject("FrontViewMenuItem.Enabled"), Boolean)
        Me.FrontViewMenuItem.Index = 5
        Me.FrontViewMenuItem.Shortcut = CType(resources.GetObject("FrontViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.FrontViewMenuItem.ShowShortcut = CType(resources.GetObject("FrontViewMenuItem.ShowShortcut"), Boolean)
        Me.FrontViewMenuItem.Text = resources.GetString("FrontViewMenuItem.Text")
        Me.FrontViewMenuItem.Visible = CType(resources.GetObject("FrontViewMenuItem.Visible"), Boolean)
        '
        'BackViewMenuItem
        '
        Me.BackViewMenuItem.Enabled = CType(resources.GetObject("BackViewMenuItem.Enabled"), Boolean)
        Me.BackViewMenuItem.Index = 6
        Me.BackViewMenuItem.Shortcut = CType(resources.GetObject("BackViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.BackViewMenuItem.ShowShortcut = CType(resources.GetObject("BackViewMenuItem.ShowShortcut"), Boolean)
        Me.BackViewMenuItem.Text = resources.GetString("BackViewMenuItem.Text")
        Me.BackViewMenuItem.Visible = CType(resources.GetObject("BackViewMenuItem.Visible"), Boolean)
        '
        'SWViewMenuItem
        '
        Me.SWViewMenuItem.Enabled = CType(resources.GetObject("SWViewMenuItem.Enabled"), Boolean)
        Me.SWViewMenuItem.Index = 7
        Me.SWViewMenuItem.Shortcut = CType(resources.GetObject("SWViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.SWViewMenuItem.ShowShortcut = CType(resources.GetObject("SWViewMenuItem.ShowShortcut"), Boolean)
        Me.SWViewMenuItem.Text = resources.GetString("SWViewMenuItem.Text")
        Me.SWViewMenuItem.Visible = CType(resources.GetObject("SWViewMenuItem.Visible"), Boolean)
        '
        'SEViewMenuItem
        '
        Me.SEViewMenuItem.Enabled = CType(resources.GetObject("SEViewMenuItem.Enabled"), Boolean)
        Me.SEViewMenuItem.Index = 8
        Me.SEViewMenuItem.Shortcut = CType(resources.GetObject("SEViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.SEViewMenuItem.ShowShortcut = CType(resources.GetObject("SEViewMenuItem.ShowShortcut"), Boolean)
        Me.SEViewMenuItem.Text = resources.GetString("SEViewMenuItem.Text")
        Me.SEViewMenuItem.Visible = CType(resources.GetObject("SEViewMenuItem.Visible"), Boolean)
        '
        'NEViewMenuItem
        '
        Me.NEViewMenuItem.Enabled = CType(resources.GetObject("NEViewMenuItem.Enabled"), Boolean)
        Me.NEViewMenuItem.Index = 9
        Me.NEViewMenuItem.Shortcut = CType(resources.GetObject("NEViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.NEViewMenuItem.ShowShortcut = CType(resources.GetObject("NEViewMenuItem.ShowShortcut"), Boolean)
        Me.NEViewMenuItem.Text = resources.GetString("NEViewMenuItem.Text")
        Me.NEViewMenuItem.Visible = CType(resources.GetObject("NEViewMenuItem.Visible"), Boolean)
        '
        'NWViewMenuItem
        '
        Me.NWViewMenuItem.Enabled = CType(resources.GetObject("NWViewMenuItem.Enabled"), Boolean)
        Me.NWViewMenuItem.Index = 10
        Me.NWViewMenuItem.Shortcut = CType(resources.GetObject("NWViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.NWViewMenuItem.ShowShortcut = CType(resources.GetObject("NWViewMenuItem.ShowShortcut"), Boolean)
        Me.NWViewMenuItem.Text = resources.GetString("NWViewMenuItem.Text")
        Me.NWViewMenuItem.Visible = CType(resources.GetObject("NWViewMenuItem.Visible"), Boolean)
        '
        'saveImgDlg
        '
        Me.saveImgDlg.Filter = resources.GetString("saveImgDlg.Filter")
        Me.saveImgDlg.RestoreDirectory = True
        Me.saveImgDlg.Title = resources.GetString("saveImgDlg.Title")
        '
        'stBar
        '
        Me.stBar.AccessibleDescription = resources.GetString("stBar.AccessibleDescription")
        Me.stBar.AccessibleName = resources.GetString("stBar.AccessibleName")
        Me.stBar.Anchor = CType(resources.GetObject("stBar.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.stBar.BackgroundImage = CType(resources.GetObject("stBar.BackgroundImage"), System.Drawing.Image)
        Me.stBar.Dock = CType(resources.GetObject("stBar.Dock"), System.Windows.Forms.DockStyle)
        Me.stBar.Enabled = CType(resources.GetObject("stBar.Enabled"), Boolean)
        Me.stBar.Font = CType(resources.GetObject("stBar.Font"), System.Drawing.Font)
        Me.stBar.ImeMode = CType(resources.GetObject("stBar.ImeMode"), System.Windows.Forms.ImeMode)
        Me.stBar.Location = CType(resources.GetObject("stBar.Location"), System.Drawing.Point)
        Me.stBar.Name = "stBar"
        Me.stBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbOpen, Me.sbScale, Me.sbCoord})
        Me.stBar.RightToLeft = CType(resources.GetObject("stBar.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.stBar.ShowPanels = True
        Me.stBar.Size = CType(resources.GetObject("stBar.Size"), System.Drawing.Size)
        Me.stBar.TabIndex = CType(resources.GetObject("stBar.TabIndex"), Integer)
        Me.stBar.Text = resources.GetString("stBar.Text")
        Me.stBar.Visible = CType(resources.GetObject("stBar.Visible"), Boolean)
        '
        'sbOpen
        '
        Me.sbOpen.Alignment = CType(resources.GetObject("sbOpen.Alignment"), System.Windows.Forms.HorizontalAlignment)
        Me.sbOpen.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents
        Me.sbOpen.Icon = CType(resources.GetObject("sbOpen.Icon"), System.Drawing.Icon)
        Me.sbOpen.MinWidth = CType(resources.GetObject("sbOpen.MinWidth"), Integer)
        Me.sbOpen.Text = resources.GetString("sbOpen.Text")
        Me.sbOpen.ToolTipText = resources.GetString("sbOpen.ToolTipText")
        Me.sbOpen.Width = CType(resources.GetObject("sbOpen.Width"), Integer)
        '
        'sbScale
        '
        Me.sbScale.Alignment = CType(resources.GetObject("sbScale.Alignment"), System.Windows.Forms.HorizontalAlignment)
        Me.sbScale.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbScale.Icon = CType(resources.GetObject("sbScale.Icon"), System.Drawing.Icon)
        Me.sbScale.MinWidth = CType(resources.GetObject("sbScale.MinWidth"), Integer)
        Me.sbScale.Text = resources.GetString("sbScale.Text")
        Me.sbScale.ToolTipText = resources.GetString("sbScale.ToolTipText")
        Me.sbScale.Width = CType(resources.GetObject("sbScale.Width"), Integer)
        '
        'sbCoord
        '
        Me.sbCoord.Alignment = CType(resources.GetObject("sbCoord.Alignment"), System.Windows.Forms.HorizontalAlignment)
        Me.sbCoord.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents
        Me.sbCoord.Icon = CType(resources.GetObject("sbCoord.Icon"), System.Drawing.Icon)
        Me.sbCoord.MinWidth = CType(resources.GetObject("sbCoord.MinWidth"), Integer)
        Me.sbCoord.Text = resources.GetString("sbCoord.Text")
        Me.sbCoord.ToolTipText = resources.GetString("sbCoord.ToolTipText")
        Me.sbCoord.Width = CType(resources.GetObject("sbCoord.Width"), Integer)
        '
        'splitter1
        '
        Me.splitter1.AccessibleDescription = resources.GetString("splitter1.AccessibleDescription")
        Me.splitter1.AccessibleName = resources.GetString("splitter1.AccessibleName")
        Me.splitter1.Anchor = CType(resources.GetObject("splitter1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.splitter1.BackgroundImage = CType(resources.GetObject("splitter1.BackgroundImage"), System.Drawing.Image)
        Me.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.splitter1.Dock = CType(resources.GetObject("splitter1.Dock"), System.Windows.Forms.DockStyle)
        Me.splitter1.Enabled = CType(resources.GetObject("splitter1.Enabled"), Boolean)
        Me.splitter1.Font = CType(resources.GetObject("splitter1.Font"), System.Drawing.Font)
        Me.splitter1.ImeMode = CType(resources.GetObject("splitter1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.splitter1.Location = CType(resources.GetObject("splitter1.Location"), System.Drawing.Point)
        Me.splitter1.MinExtra = CType(resources.GetObject("splitter1.MinExtra"), Integer)
        Me.splitter1.MinSize = CType(resources.GetObject("splitter1.MinSize"), Integer)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.RightToLeft = CType(resources.GetObject("splitter1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.splitter1.Size = CType(resources.GetObject("splitter1.Size"), System.Drawing.Size)
        Me.splitter1.TabIndex = CType(resources.GetObject("splitter1.TabIndex"), Integer)
        Me.splitter1.TabStop = False
        Me.splitter1.Visible = CType(resources.GetObject("splitter1.Visible"), Boolean)
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFile, Me.editMenuItem, Me.mView, Me.cADFilesMenuItem, Me.helpMenuItem})
        Me.mainMenu.RightToLeft = CType(resources.GetObject("mainMenu.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'mFile
        '
        Me.mFile.Enabled = CType(resources.GetObject("mFile.Enabled"), Boolean)
        Me.mFile.Index = 0
        Me.mFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mOpenFile, Me.mSaveFile, Me.mSaveAsDXF, Me.printMenuItem, Me.print2Item, Me.printPrevItem, Me.closeMenuItem, Me.menuItem2, Me.mExit})
        Me.mFile.Shortcut = CType(resources.GetObject("mFile.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mFile.ShowShortcut = CType(resources.GetObject("mFile.ShowShortcut"), Boolean)
        Me.mFile.Text = resources.GetString("mFile.Text")
        Me.mFile.Visible = CType(resources.GetObject("mFile.Visible"), Boolean)
        '
        'mOpenFile
        '
        Me.mOpenFile.Enabled = CType(resources.GetObject("mOpenFile.Enabled"), Boolean)
        Me.mOpenFile.Index = 0
        Me.mOpenFile.Shortcut = CType(resources.GetObject("mOpenFile.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mOpenFile.ShowShortcut = CType(resources.GetObject("mOpenFile.ShowShortcut"), Boolean)
        Me.mOpenFile.Text = resources.GetString("mOpenFile.Text")
        Me.mOpenFile.Visible = CType(resources.GetObject("mOpenFile.Visible"), Boolean)
        '
        'mSaveFile
        '
        Me.mSaveFile.Enabled = CType(resources.GetObject("mSaveFile.Enabled"), Boolean)
        Me.mSaveFile.Index = 1
        Me.mSaveFile.Shortcut = CType(resources.GetObject("mSaveFile.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mSaveFile.ShowShortcut = CType(resources.GetObject("mSaveFile.ShowShortcut"), Boolean)
        Me.mSaveFile.Text = resources.GetString("mSaveFile.Text")
        Me.mSaveFile.Visible = CType(resources.GetObject("mSaveFile.Visible"), Boolean)
        '
        'mSaveAsDXF
        '
        Me.mSaveAsDXF.Enabled = CType(resources.GetObject("mSaveAsDXF.Enabled"), Boolean)
        Me.mSaveAsDXF.Index = 2
        Me.mSaveAsDXF.Shortcut = CType(resources.GetObject("mSaveAsDXF.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mSaveAsDXF.ShowShortcut = CType(resources.GetObject("mSaveAsDXF.ShowShortcut"), Boolean)
        Me.mSaveAsDXF.Text = resources.GetString("mSaveAsDXF.Text")
        Me.mSaveAsDXF.Visible = CType(resources.GetObject("mSaveAsDXF.Visible"), Boolean)
        '
        'printMenuItem
        '
        Me.printMenuItem.Enabled = CType(resources.GetObject("printMenuItem.Enabled"), Boolean)
        Me.printMenuItem.Index = 3
        Me.printMenuItem.Shortcut = CType(resources.GetObject("printMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.printMenuItem.ShowShortcut = CType(resources.GetObject("printMenuItem.ShowShortcut"), Boolean)
        Me.printMenuItem.Text = resources.GetString("printMenuItem.Text")
        Me.printMenuItem.Visible = CType(resources.GetObject("printMenuItem.Visible"), Boolean)
        '
        'print2Item
        '
        Me.print2Item.Enabled = CType(resources.GetObject("print2Item.Enabled"), Boolean)
        Me.print2Item.Index = 4
        Me.print2Item.Shortcut = CType(resources.GetObject("print2Item.Shortcut"), System.Windows.Forms.Shortcut)
        Me.print2Item.ShowShortcut = CType(resources.GetObject("print2Item.ShowShortcut"), Boolean)
        Me.print2Item.Text = resources.GetString("print2Item.Text")
        Me.print2Item.Visible = CType(resources.GetObject("print2Item.Visible"), Boolean)
        '
        'printPrevItem
        '
        Me.printPrevItem.Enabled = CType(resources.GetObject("printPrevItem.Enabled"), Boolean)
        Me.printPrevItem.Index = 5
        Me.printPrevItem.Shortcut = CType(resources.GetObject("printPrevItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.printPrevItem.ShowShortcut = CType(resources.GetObject("printPrevItem.ShowShortcut"), Boolean)
        Me.printPrevItem.Text = resources.GetString("printPrevItem.Text")
        Me.printPrevItem.Visible = CType(resources.GetObject("printPrevItem.Visible"), Boolean)
        '
        'closeMenuItem
        '
        Me.closeMenuItem.Enabled = CType(resources.GetObject("closeMenuItem.Enabled"), Boolean)
        Me.closeMenuItem.Index = 6
        Me.closeMenuItem.Shortcut = CType(resources.GetObject("closeMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.closeMenuItem.ShowShortcut = CType(resources.GetObject("closeMenuItem.ShowShortcut"), Boolean)
        Me.closeMenuItem.Text = resources.GetString("closeMenuItem.Text")
        Me.closeMenuItem.Visible = CType(resources.GetObject("closeMenuItem.Visible"), Boolean)
        '
        'menuItem2
        '
        Me.menuItem2.Enabled = CType(resources.GetObject("menuItem2.Enabled"), Boolean)
        Me.menuItem2.Index = 7
        Me.menuItem2.Shortcut = CType(resources.GetObject("menuItem2.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem2.ShowShortcut = CType(resources.GetObject("menuItem2.ShowShortcut"), Boolean)
        Me.menuItem2.Text = resources.GetString("menuItem2.Text")
        Me.menuItem2.Visible = CType(resources.GetObject("menuItem2.Visible"), Boolean)
        '
        'mExit
        '
        Me.mExit.Enabled = CType(resources.GetObject("mExit.Enabled"), Boolean)
        Me.mExit.Index = 8
        Me.mExit.Shortcut = CType(resources.GetObject("mExit.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mExit.ShowShortcut = CType(resources.GetObject("mExit.ShowShortcut"), Boolean)
        Me.mExit.Text = resources.GetString("mExit.Text")
        Me.mExit.Visible = CType(resources.GetObject("mExit.Visible"), Boolean)
        '
        'editMenuItem
        '
        Me.editMenuItem.Enabled = CType(resources.GetObject("editMenuItem.Enabled"), Boolean)
        Me.editMenuItem.Index = 1
        Me.editMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.copyMenuItem})
        Me.editMenuItem.Shortcut = CType(resources.GetObject("editMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.editMenuItem.ShowShortcut = CType(resources.GetObject("editMenuItem.ShowShortcut"), Boolean)
        Me.editMenuItem.Text = resources.GetString("editMenuItem.Text")
        Me.editMenuItem.Visible = CType(resources.GetObject("editMenuItem.Visible"), Boolean)
        '
        'copyMenuItem
        '
        Me.copyMenuItem.Enabled = CType(resources.GetObject("copyMenuItem.Enabled"), Boolean)
        Me.copyMenuItem.Index = 0
        Me.copyMenuItem.Shortcut = CType(resources.GetObject("copyMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.copyMenuItem.ShowShortcut = CType(resources.GetObject("copyMenuItem.ShowShortcut"), Boolean)
        Me.copyMenuItem.Text = resources.GetString("copyMenuItem.Text")
        Me.copyMenuItem.Visible = CType(resources.GetObject("copyMenuItem.Visible"), Boolean)
        '
        'mView
        '
        Me.mView.Enabled = CType(resources.GetObject("mView.Enabled"), Boolean)
        Me.mView.Index = 2
        Me.mView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.entitiesMenuItem, Me.menuItem24, Me.zoomInMenuItem, Me.zoomOutMenuItem, Me.mScale, Me.fitMenuItem, Me.menuItem29, Me.shxMenuItem, Me.menuItem3})
        Me.mView.Shortcut = CType(resources.GetObject("mView.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mView.ShowShortcut = CType(resources.GetObject("mView.ShowShortcut"), Boolean)
        Me.mView.Text = resources.GetString("mView.Text")
        Me.mView.Visible = CType(resources.GetObject("mView.Visible"), Boolean)
        '
        'entitiesMenuItem
        '
        Me.entitiesMenuItem.Checked = True
        Me.entitiesMenuItem.Enabled = CType(resources.GetObject("entitiesMenuItem.Enabled"), Boolean)
        Me.entitiesMenuItem.Index = 0
        Me.entitiesMenuItem.Shortcut = CType(resources.GetObject("entitiesMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.entitiesMenuItem.ShowShortcut = CType(resources.GetObject("entitiesMenuItem.ShowShortcut"), Boolean)
        Me.entitiesMenuItem.Text = resources.GetString("entitiesMenuItem.Text")
        Me.entitiesMenuItem.Visible = CType(resources.GetObject("entitiesMenuItem.Visible"), Boolean)
        '
        'menuItem24
        '
        Me.menuItem24.Enabled = CType(resources.GetObject("menuItem24.Enabled"), Boolean)
        Me.menuItem24.Index = 1
        Me.menuItem24.Shortcut = CType(resources.GetObject("menuItem24.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem24.ShowShortcut = CType(resources.GetObject("menuItem24.ShowShortcut"), Boolean)
        Me.menuItem24.Text = resources.GetString("menuItem24.Text")
        Me.menuItem24.Visible = CType(resources.GetObject("menuItem24.Visible"), Boolean)
        '
        'zoomInMenuItem
        '
        Me.zoomInMenuItem.Enabled = CType(resources.GetObject("zoomInMenuItem.Enabled"), Boolean)
        Me.zoomInMenuItem.Index = 2
        Me.zoomInMenuItem.Shortcut = CType(resources.GetObject("zoomInMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoomInMenuItem.ShowShortcut = CType(resources.GetObject("zoomInMenuItem.ShowShortcut"), Boolean)
        Me.zoomInMenuItem.Text = resources.GetString("zoomInMenuItem.Text")
        Me.zoomInMenuItem.Visible = CType(resources.GetObject("zoomInMenuItem.Visible"), Boolean)
        '
        'zoomOutMenuItem
        '
        Me.zoomOutMenuItem.Enabled = CType(resources.GetObject("zoomOutMenuItem.Enabled"), Boolean)
        Me.zoomOutMenuItem.Index = 3
        Me.zoomOutMenuItem.Shortcut = CType(resources.GetObject("zoomOutMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoomOutMenuItem.ShowShortcut = CType(resources.GetObject("zoomOutMenuItem.ShowShortcut"), Boolean)
        Me.zoomOutMenuItem.Text = resources.GetString("zoomOutMenuItem.Text")
        Me.zoomOutMenuItem.Visible = CType(resources.GetObject("zoomOutMenuItem.Visible"), Boolean)
        '
        'mScale
        '
        Me.mScale.Enabled = CType(resources.GetObject("mScale.Enabled"), Boolean)
        Me.mScale.Index = 4
        Me.mScale.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.zoom10MenuItem, Me.zoom25MenuItem, Me.zoom50MenuItem, Me.zoom100MenuItem, Me.zoom200MenuItem, Me.zoom400MenuItem, Me.zoom800MenuItem})
        Me.mScale.Shortcut = CType(resources.GetObject("mScale.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mScale.ShowShortcut = CType(resources.GetObject("mScale.ShowShortcut"), Boolean)
        Me.mScale.Text = resources.GetString("mScale.Text")
        Me.mScale.Visible = CType(resources.GetObject("mScale.Visible"), Boolean)
        '
        'zoom10MenuItem
        '
        Me.zoom10MenuItem.Enabled = CType(resources.GetObject("zoom10MenuItem.Enabled"), Boolean)
        Me.zoom10MenuItem.Index = 0
        Me.zoom10MenuItem.Shortcut = CType(resources.GetObject("zoom10MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom10MenuItem.ShowShortcut = CType(resources.GetObject("zoom10MenuItem.ShowShortcut"), Boolean)
        Me.zoom10MenuItem.Text = resources.GetString("zoom10MenuItem.Text")
        Me.zoom10MenuItem.Visible = CType(resources.GetObject("zoom10MenuItem.Visible"), Boolean)
        '
        'zoom25MenuItem
        '
        Me.zoom25MenuItem.Enabled = CType(resources.GetObject("zoom25MenuItem.Enabled"), Boolean)
        Me.zoom25MenuItem.Index = 1
        Me.zoom25MenuItem.Shortcut = CType(resources.GetObject("zoom25MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom25MenuItem.ShowShortcut = CType(resources.GetObject("zoom25MenuItem.ShowShortcut"), Boolean)
        Me.zoom25MenuItem.Text = resources.GetString("zoom25MenuItem.Text")
        Me.zoom25MenuItem.Visible = CType(resources.GetObject("zoom25MenuItem.Visible"), Boolean)
        '
        'zoom50MenuItem
        '
        Me.zoom50MenuItem.Enabled = CType(resources.GetObject("zoom50MenuItem.Enabled"), Boolean)
        Me.zoom50MenuItem.Index = 2
        Me.zoom50MenuItem.Shortcut = CType(resources.GetObject("zoom50MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom50MenuItem.ShowShortcut = CType(resources.GetObject("zoom50MenuItem.ShowShortcut"), Boolean)
        Me.zoom50MenuItem.Text = resources.GetString("zoom50MenuItem.Text")
        Me.zoom50MenuItem.Visible = CType(resources.GetObject("zoom50MenuItem.Visible"), Boolean)
        '
        'zoom100MenuItem
        '
        Me.zoom100MenuItem.Enabled = CType(resources.GetObject("zoom100MenuItem.Enabled"), Boolean)
        Me.zoom100MenuItem.Index = 3
        Me.zoom100MenuItem.Shortcut = CType(resources.GetObject("zoom100MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom100MenuItem.ShowShortcut = CType(resources.GetObject("zoom100MenuItem.ShowShortcut"), Boolean)
        Me.zoom100MenuItem.Text = resources.GetString("zoom100MenuItem.Text")
        Me.zoom100MenuItem.Visible = CType(resources.GetObject("zoom100MenuItem.Visible"), Boolean)
        '
        'zoom200MenuItem
        '
        Me.zoom200MenuItem.Enabled = CType(resources.GetObject("zoom200MenuItem.Enabled"), Boolean)
        Me.zoom200MenuItem.Index = 4
        Me.zoom200MenuItem.Shortcut = CType(resources.GetObject("zoom200MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom200MenuItem.ShowShortcut = CType(resources.GetObject("zoom200MenuItem.ShowShortcut"), Boolean)
        Me.zoom200MenuItem.Text = resources.GetString("zoom200MenuItem.Text")
        Me.zoom200MenuItem.Visible = CType(resources.GetObject("zoom200MenuItem.Visible"), Boolean)
        '
        'zoom400MenuItem
        '
        Me.zoom400MenuItem.Enabled = CType(resources.GetObject("zoom400MenuItem.Enabled"), Boolean)
        Me.zoom400MenuItem.Index = 5
        Me.zoom400MenuItem.Shortcut = CType(resources.GetObject("zoom400MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom400MenuItem.ShowShortcut = CType(resources.GetObject("zoom400MenuItem.ShowShortcut"), Boolean)
        Me.zoom400MenuItem.Text = resources.GetString("zoom400MenuItem.Text")
        Me.zoom400MenuItem.Visible = CType(resources.GetObject("zoom400MenuItem.Visible"), Boolean)
        '
        'zoom800MenuItem
        '
        Me.zoom800MenuItem.Enabled = CType(resources.GetObject("zoom800MenuItem.Enabled"), Boolean)
        Me.zoom800MenuItem.Index = 6
        Me.zoom800MenuItem.Shortcut = CType(resources.GetObject("zoom800MenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.zoom800MenuItem.ShowShortcut = CType(resources.GetObject("zoom800MenuItem.ShowShortcut"), Boolean)
        Me.zoom800MenuItem.Text = resources.GetString("zoom800MenuItem.Text")
        Me.zoom800MenuItem.Visible = CType(resources.GetObject("zoom800MenuItem.Visible"), Boolean)
        '
        'fitMenuItem
        '
        Me.fitMenuItem.Enabled = CType(resources.GetObject("fitMenuItem.Enabled"), Boolean)
        Me.fitMenuItem.Index = 5
        Me.fitMenuItem.Shortcut = CType(resources.GetObject("fitMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.fitMenuItem.ShowShortcut = CType(resources.GetObject("fitMenuItem.ShowShortcut"), Boolean)
        Me.fitMenuItem.Text = resources.GetString("fitMenuItem.Text")
        Me.fitMenuItem.Visible = CType(resources.GetObject("fitMenuItem.Visible"), Boolean)
        '
        'menuItem29
        '
        Me.menuItem29.Enabled = CType(resources.GetObject("menuItem29.Enabled"), Boolean)
        Me.menuItem29.Index = 6
        Me.menuItem29.Shortcut = CType(resources.GetObject("menuItem29.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem29.ShowShortcut = CType(resources.GetObject("menuItem29.ShowShortcut"), Boolean)
        Me.menuItem29.Text = resources.GetString("menuItem29.Text")
        Me.menuItem29.Visible = CType(resources.GetObject("menuItem29.Visible"), Boolean)
        '
        'shxMenuItem
        '
        Me.shxMenuItem.Enabled = CType(resources.GetObject("shxMenuItem.Enabled"), Boolean)
        Me.shxMenuItem.Index = 7
        Me.shxMenuItem.Shortcut = CType(resources.GetObject("shxMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.shxMenuItem.ShowShortcut = CType(resources.GetObject("shxMenuItem.ShowShortcut"), Boolean)
        Me.shxMenuItem.Text = resources.GetString("shxMenuItem.Text")
        Me.shxMenuItem.Visible = CType(resources.GetObject("shxMenuItem.Visible"), Boolean)
        '
        'menuItem3
        '
        Me.menuItem3.Enabled = CType(resources.GetObject("menuItem3.Enabled"), Boolean)
        Me.menuItem3.Index = 8
        Me.menuItem3.Shortcut = CType(resources.GetObject("menuItem3.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem3.ShowShortcut = CType(resources.GetObject("menuItem3.ShowShortcut"), Boolean)
        Me.menuItem3.Text = resources.GetString("menuItem3.Text")
        Me.menuItem3.Visible = CType(resources.GetObject("menuItem3.Visible"), Boolean)
        '
        'cADFilesMenuItem
        '
        Me.cADFilesMenuItem.Enabled = CType(resources.GetObject("cADFilesMenuItem.Enabled"), Boolean)
        Me.cADFilesMenuItem.Index = 3
        Me.cADFilesMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.colorMenuItem, Me.blackMenuItem, Me.whiteBackMenuItem, Me.blackBackMenuItem, Me.changeBackMenuItem, Me.menuItem38, Me.showLineWeightMenuItem, Me.arcsSplitMenuItem, Me.dimShowMenuItem, Me.textsShowMenuItem, Me.menuItem43, Me.layersShowMenuItem, Me.ViewMenuItem, Me.orbitMenuItem})
        Me.cADFilesMenuItem.Shortcut = CType(resources.GetObject("cADFilesMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.cADFilesMenuItem.ShowShortcut = CType(resources.GetObject("cADFilesMenuItem.ShowShortcut"), Boolean)
        Me.cADFilesMenuItem.Text = resources.GetString("cADFilesMenuItem.Text")
        Me.cADFilesMenuItem.Visible = CType(resources.GetObject("cADFilesMenuItem.Visible"), Boolean)
        '
        'colorMenuItem
        '
        Me.colorMenuItem.Checked = True
        Me.colorMenuItem.Enabled = CType(resources.GetObject("colorMenuItem.Enabled"), Boolean)
        Me.colorMenuItem.Index = 0
        Me.colorMenuItem.RadioCheck = True
        Me.colorMenuItem.Shortcut = CType(resources.GetObject("colorMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.colorMenuItem.ShowShortcut = CType(resources.GetObject("colorMenuItem.ShowShortcut"), Boolean)
        Me.colorMenuItem.Text = resources.GetString("colorMenuItem.Text")
        Me.colorMenuItem.Visible = CType(resources.GetObject("colorMenuItem.Visible"), Boolean)
        '
        'blackMenuItem
        '
        Me.blackMenuItem.Enabled = CType(resources.GetObject("blackMenuItem.Enabled"), Boolean)
        Me.blackMenuItem.Index = 1
        Me.blackMenuItem.RadioCheck = True
        Me.blackMenuItem.Shortcut = CType(resources.GetObject("blackMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.blackMenuItem.ShowShortcut = CType(resources.GetObject("blackMenuItem.ShowShortcut"), Boolean)
        Me.blackMenuItem.Text = resources.GetString("blackMenuItem.Text")
        Me.blackMenuItem.Visible = CType(resources.GetObject("blackMenuItem.Visible"), Boolean)
        '
        'whiteBackMenuItem
        '
        Me.whiteBackMenuItem.Enabled = CType(resources.GetObject("whiteBackMenuItem.Enabled"), Boolean)
        Me.whiteBackMenuItem.Index = 2
        Me.whiteBackMenuItem.RadioCheck = True
        Me.whiteBackMenuItem.Shortcut = CType(resources.GetObject("whiteBackMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.whiteBackMenuItem.ShowShortcut = CType(resources.GetObject("whiteBackMenuItem.ShowShortcut"), Boolean)
        Me.whiteBackMenuItem.Text = resources.GetString("whiteBackMenuItem.Text")
        Me.whiteBackMenuItem.Visible = CType(resources.GetObject("whiteBackMenuItem.Visible"), Boolean)
        '
        'blackBackMenuItem
        '
        Me.blackBackMenuItem.Enabled = CType(resources.GetObject("blackBackMenuItem.Enabled"), Boolean)
        Me.blackBackMenuItem.Index = 3
        Me.blackBackMenuItem.RadioCheck = True
        Me.blackBackMenuItem.Shortcut = CType(resources.GetObject("blackBackMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.blackBackMenuItem.ShowShortcut = CType(resources.GetObject("blackBackMenuItem.ShowShortcut"), Boolean)
        Me.blackBackMenuItem.Text = resources.GetString("blackBackMenuItem.Text")
        Me.blackBackMenuItem.Visible = CType(resources.GetObject("blackBackMenuItem.Visible"), Boolean)
        '
        'changeBackMenuItem
        '
        Me.changeBackMenuItem.Enabled = CType(resources.GetObject("changeBackMenuItem.Enabled"), Boolean)
        Me.changeBackMenuItem.Index = 4
        Me.changeBackMenuItem.Shortcut = CType(resources.GetObject("changeBackMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.changeBackMenuItem.ShowShortcut = CType(resources.GetObject("changeBackMenuItem.ShowShortcut"), Boolean)
        Me.changeBackMenuItem.Text = resources.GetString("changeBackMenuItem.Text")
        Me.changeBackMenuItem.Visible = CType(resources.GetObject("changeBackMenuItem.Visible"), Boolean)
        '
        'menuItem38
        '
        Me.menuItem38.Enabled = CType(resources.GetObject("menuItem38.Enabled"), Boolean)
        Me.menuItem38.Index = 5
        Me.menuItem38.Shortcut = CType(resources.GetObject("menuItem38.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem38.ShowShortcut = CType(resources.GetObject("menuItem38.ShowShortcut"), Boolean)
        Me.menuItem38.Text = resources.GetString("menuItem38.Text")
        Me.menuItem38.Visible = CType(resources.GetObject("menuItem38.Visible"), Boolean)
        '
        'showLineWeightMenuItem
        '
        Me.showLineWeightMenuItem.Checked = True
        Me.showLineWeightMenuItem.Enabled = CType(resources.GetObject("showLineWeightMenuItem.Enabled"), Boolean)
        Me.showLineWeightMenuItem.Index = 6
        Me.showLineWeightMenuItem.Shortcut = CType(resources.GetObject("showLineWeightMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.showLineWeightMenuItem.ShowShortcut = CType(resources.GetObject("showLineWeightMenuItem.ShowShortcut"), Boolean)
        Me.showLineWeightMenuItem.Text = resources.GetString("showLineWeightMenuItem.Text")
        Me.showLineWeightMenuItem.Visible = CType(resources.GetObject("showLineWeightMenuItem.Visible"), Boolean)
        '
        'arcsSplitMenuItem
        '
        Me.arcsSplitMenuItem.Checked = True
        Me.arcsSplitMenuItem.Enabled = CType(resources.GetObject("arcsSplitMenuItem.Enabled"), Boolean)
        Me.arcsSplitMenuItem.Index = 7
        Me.arcsSplitMenuItem.Shortcut = CType(resources.GetObject("arcsSplitMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.arcsSplitMenuItem.ShowShortcut = CType(resources.GetObject("arcsSplitMenuItem.ShowShortcut"), Boolean)
        Me.arcsSplitMenuItem.Text = resources.GetString("arcsSplitMenuItem.Text")
        Me.arcsSplitMenuItem.Visible = CType(resources.GetObject("arcsSplitMenuItem.Visible"), Boolean)
        '
        'dimShowMenuItem
        '
        Me.dimShowMenuItem.Checked = True
        Me.dimShowMenuItem.Enabled = CType(resources.GetObject("dimShowMenuItem.Enabled"), Boolean)
        Me.dimShowMenuItem.Index = 8
        Me.dimShowMenuItem.Shortcut = CType(resources.GetObject("dimShowMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.dimShowMenuItem.ShowShortcut = CType(resources.GetObject("dimShowMenuItem.ShowShortcut"), Boolean)
        Me.dimShowMenuItem.Text = resources.GetString("dimShowMenuItem.Text")
        Me.dimShowMenuItem.Visible = CType(resources.GetObject("dimShowMenuItem.Visible"), Boolean)
        '
        'textsShowMenuItem
        '
        Me.textsShowMenuItem.Checked = True
        Me.textsShowMenuItem.Enabled = CType(resources.GetObject("textsShowMenuItem.Enabled"), Boolean)
        Me.textsShowMenuItem.Index = 9
        Me.textsShowMenuItem.Shortcut = CType(resources.GetObject("textsShowMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.textsShowMenuItem.ShowShortcut = CType(resources.GetObject("textsShowMenuItem.ShowShortcut"), Boolean)
        Me.textsShowMenuItem.Text = resources.GetString("textsShowMenuItem.Text")
        Me.textsShowMenuItem.Visible = CType(resources.GetObject("textsShowMenuItem.Visible"), Boolean)
        '
        'menuItem43
        '
        Me.menuItem43.Enabled = CType(resources.GetObject("menuItem43.Enabled"), Boolean)
        Me.menuItem43.Index = 10
        Me.menuItem43.Shortcut = CType(resources.GetObject("menuItem43.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem43.ShowShortcut = CType(resources.GetObject("menuItem43.ShowShortcut"), Boolean)
        Me.menuItem43.Text = resources.GetString("menuItem43.Text")
        Me.menuItem43.Visible = CType(resources.GetObject("menuItem43.Visible"), Boolean)
        '
        'layersShowMenuItem
        '
        Me.layersShowMenuItem.Enabled = CType(resources.GetObject("layersShowMenuItem.Enabled"), Boolean)
        Me.layersShowMenuItem.Index = 11
        Me.layersShowMenuItem.Shortcut = CType(resources.GetObject("layersShowMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.layersShowMenuItem.ShowShortcut = CType(resources.GetObject("layersShowMenuItem.ShowShortcut"), Boolean)
        Me.layersShowMenuItem.Text = resources.GetString("layersShowMenuItem.Text")
        Me.layersShowMenuItem.Visible = CType(resources.GetObject("layersShowMenuItem.Visible"), Boolean)
        '
        'ViewMenuItem
        '
        Me.ViewMenuItem.Enabled = CType(resources.GetObject("ViewMenuItem.Enabled"), Boolean)
        Me.ViewMenuItem.Index = 12
        Me.ViewMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.InitMenuItem, Me.topMenuItem, Me.bottomMenuItem, Me.leftMenuItem, Me.rightMenuItem, Me.frontMenuItem, Me.backMenuItem, Me.swMenuItem, Me.seMenuItem, Me.neMenuItem, Me.nwMenuItem})
        Me.ViewMenuItem.Shortcut = CType(resources.GetObject("ViewMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.ViewMenuItem.ShowShortcut = CType(resources.GetObject("ViewMenuItem.ShowShortcut"), Boolean)
        Me.ViewMenuItem.Text = resources.GetString("ViewMenuItem.Text")
        Me.ViewMenuItem.Visible = CType(resources.GetObject("ViewMenuItem.Visible"), Boolean)
        '
        'InitMenuItem
        '
        Me.InitMenuItem.Enabled = CType(resources.GetObject("InitMenuItem.Enabled"), Boolean)
        Me.InitMenuItem.Index = 0
        Me.InitMenuItem.Shortcut = CType(resources.GetObject("InitMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.InitMenuItem.ShowShortcut = CType(resources.GetObject("InitMenuItem.ShowShortcut"), Boolean)
        Me.InitMenuItem.Text = resources.GetString("InitMenuItem.Text")
        Me.InitMenuItem.Visible = CType(resources.GetObject("InitMenuItem.Visible"), Boolean)
        '
        'topMenuItem
        '
        Me.topMenuItem.Enabled = CType(resources.GetObject("topMenuItem.Enabled"), Boolean)
        Me.topMenuItem.Index = 1
        Me.topMenuItem.Shortcut = CType(resources.GetObject("topMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.topMenuItem.ShowShortcut = CType(resources.GetObject("topMenuItem.ShowShortcut"), Boolean)
        Me.topMenuItem.Text = resources.GetString("topMenuItem.Text")
        Me.topMenuItem.Visible = CType(resources.GetObject("topMenuItem.Visible"), Boolean)
        '
        'bottomMenuItem
        '
        Me.bottomMenuItem.Enabled = CType(resources.GetObject("bottomMenuItem.Enabled"), Boolean)
        Me.bottomMenuItem.Index = 2
        Me.bottomMenuItem.Shortcut = CType(resources.GetObject("bottomMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.bottomMenuItem.ShowShortcut = CType(resources.GetObject("bottomMenuItem.ShowShortcut"), Boolean)
        Me.bottomMenuItem.Text = resources.GetString("bottomMenuItem.Text")
        Me.bottomMenuItem.Visible = CType(resources.GetObject("bottomMenuItem.Visible"), Boolean)
        '
        'leftMenuItem
        '
        Me.leftMenuItem.Enabled = CType(resources.GetObject("leftMenuItem.Enabled"), Boolean)
        Me.leftMenuItem.Index = 3
        Me.leftMenuItem.Shortcut = CType(resources.GetObject("leftMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.leftMenuItem.ShowShortcut = CType(resources.GetObject("leftMenuItem.ShowShortcut"), Boolean)
        Me.leftMenuItem.Text = resources.GetString("leftMenuItem.Text")
        Me.leftMenuItem.Visible = CType(resources.GetObject("leftMenuItem.Visible"), Boolean)
        '
        'rightMenuItem
        '
        Me.rightMenuItem.Enabled = CType(resources.GetObject("rightMenuItem.Enabled"), Boolean)
        Me.rightMenuItem.Index = 4
        Me.rightMenuItem.Shortcut = CType(resources.GetObject("rightMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.rightMenuItem.ShowShortcut = CType(resources.GetObject("rightMenuItem.ShowShortcut"), Boolean)
        Me.rightMenuItem.Text = resources.GetString("rightMenuItem.Text")
        Me.rightMenuItem.Visible = CType(resources.GetObject("rightMenuItem.Visible"), Boolean)
        '
        'frontMenuItem
        '
        Me.frontMenuItem.Enabled = CType(resources.GetObject("frontMenuItem.Enabled"), Boolean)
        Me.frontMenuItem.Index = 5
        Me.frontMenuItem.Shortcut = CType(resources.GetObject("frontMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.frontMenuItem.ShowShortcut = CType(resources.GetObject("frontMenuItem.ShowShortcut"), Boolean)
        Me.frontMenuItem.Text = resources.GetString("frontMenuItem.Text")
        Me.frontMenuItem.Visible = CType(resources.GetObject("frontMenuItem.Visible"), Boolean)
        '
        'backMenuItem
        '
        Me.backMenuItem.Enabled = CType(resources.GetObject("backMenuItem.Enabled"), Boolean)
        Me.backMenuItem.Index = 6
        Me.backMenuItem.Shortcut = CType(resources.GetObject("backMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.backMenuItem.ShowShortcut = CType(resources.GetObject("backMenuItem.ShowShortcut"), Boolean)
        Me.backMenuItem.Text = resources.GetString("backMenuItem.Text")
        Me.backMenuItem.Visible = CType(resources.GetObject("backMenuItem.Visible"), Boolean)
        '
        'swMenuItem
        '
        Me.swMenuItem.Enabled = CType(resources.GetObject("swMenuItem.Enabled"), Boolean)
        Me.swMenuItem.Index = 7
        Me.swMenuItem.Shortcut = CType(resources.GetObject("swMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.swMenuItem.ShowShortcut = CType(resources.GetObject("swMenuItem.ShowShortcut"), Boolean)
        Me.swMenuItem.Text = resources.GetString("swMenuItem.Text")
        Me.swMenuItem.Visible = CType(resources.GetObject("swMenuItem.Visible"), Boolean)
        '
        'seMenuItem
        '
        Me.seMenuItem.Enabled = CType(resources.GetObject("seMenuItem.Enabled"), Boolean)
        Me.seMenuItem.Index = 8
        Me.seMenuItem.Shortcut = CType(resources.GetObject("seMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.seMenuItem.ShowShortcut = CType(resources.GetObject("seMenuItem.ShowShortcut"), Boolean)
        Me.seMenuItem.Text = resources.GetString("seMenuItem.Text")
        Me.seMenuItem.Visible = CType(resources.GetObject("seMenuItem.Visible"), Boolean)
        '
        'neMenuItem
        '
        Me.neMenuItem.Enabled = CType(resources.GetObject("neMenuItem.Enabled"), Boolean)
        Me.neMenuItem.Index = 9
        Me.neMenuItem.Shortcut = CType(resources.GetObject("neMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.neMenuItem.ShowShortcut = CType(resources.GetObject("neMenuItem.ShowShortcut"), Boolean)
        Me.neMenuItem.Text = resources.GetString("neMenuItem.Text")
        Me.neMenuItem.Visible = CType(resources.GetObject("neMenuItem.Visible"), Boolean)
        '
        'nwMenuItem
        '
        Me.nwMenuItem.Enabled = CType(resources.GetObject("nwMenuItem.Enabled"), Boolean)
        Me.nwMenuItem.Index = 10
        Me.nwMenuItem.Shortcut = CType(resources.GetObject("nwMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.nwMenuItem.ShowShortcut = CType(resources.GetObject("nwMenuItem.ShowShortcut"), Boolean)
        Me.nwMenuItem.Text = resources.GetString("nwMenuItem.Text")
        Me.nwMenuItem.Visible = CType(resources.GetObject("nwMenuItem.Visible"), Boolean)
        '
        'orbitMenuItem
        '
        Me.orbitMenuItem.Enabled = CType(resources.GetObject("orbitMenuItem.Enabled"), Boolean)
        Me.orbitMenuItem.Index = 13
        Me.orbitMenuItem.Shortcut = CType(resources.GetObject("orbitMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.orbitMenuItem.ShowShortcut = CType(resources.GetObject("orbitMenuItem.ShowShortcut"), Boolean)
        Me.orbitMenuItem.Text = resources.GetString("orbitMenuItem.Text")
        Me.orbitMenuItem.Visible = CType(resources.GetObject("orbitMenuItem.Visible"), Boolean)
        '
        'helpMenuItem
        '
        Me.helpMenuItem.Enabled = CType(resources.GetObject("helpMenuItem.Enabled"), Boolean)
        Me.helpMenuItem.Index = 4
        Me.helpMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItemReg, Me.miFloatLic, Me.aboutMenuItem})
        Me.helpMenuItem.Shortcut = CType(resources.GetObject("helpMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.helpMenuItem.ShowShortcut = CType(resources.GetObject("helpMenuItem.ShowShortcut"), Boolean)
        Me.helpMenuItem.Text = resources.GetString("helpMenuItem.Text")
        Me.helpMenuItem.Visible = CType(resources.GetObject("helpMenuItem.Visible"), Boolean)
        '
        'menuItem1
        '
        Me.menuItem1.Enabled = CType(resources.GetObject("menuItem1.Enabled"), Boolean)
        Me.menuItem1.Index = 0
        Me.menuItem1.Shortcut = CType(resources.GetObject("menuItem1.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItem1.ShowShortcut = CType(resources.GetObject("menuItem1.ShowShortcut"), Boolean)
        Me.menuItem1.Text = resources.GetString("menuItem1.Text")
        Me.menuItem1.Visible = CType(resources.GetObject("menuItem1.Visible"), Boolean)
        '
        'menuItemReg
        '
        Me.menuItemReg.Enabled = CType(resources.GetObject("menuItemReg.Enabled"), Boolean)
        Me.menuItemReg.Index = 1
        Me.menuItemReg.Shortcut = CType(resources.GetObject("menuItemReg.Shortcut"), System.Windows.Forms.Shortcut)
        Me.menuItemReg.ShowShortcut = CType(resources.GetObject("menuItemReg.ShowShortcut"), Boolean)
        Me.menuItemReg.Text = resources.GetString("menuItemReg.Text")
        Me.menuItemReg.Visible = CType(resources.GetObject("menuItemReg.Visible"), Boolean)
        '
        'miFloatLic
        '
        Me.miFloatLic.Enabled = CType(resources.GetObject("miFloatLic.Enabled"), Boolean)
        Me.miFloatLic.Index = 2
        Me.miFloatLic.Shortcut = CType(resources.GetObject("miFloatLic.Shortcut"), System.Windows.Forms.Shortcut)
        Me.miFloatLic.ShowShortcut = CType(resources.GetObject("miFloatLic.ShowShortcut"), Boolean)
        Me.miFloatLic.Text = resources.GetString("miFloatLic.Text")
        Me.miFloatLic.Visible = CType(resources.GetObject("miFloatLic.Visible"), Boolean)
        '
        'aboutMenuItem
        '
        Me.aboutMenuItem.Enabled = CType(resources.GetObject("aboutMenuItem.Enabled"), Boolean)
        Me.aboutMenuItem.Index = 3
        Me.aboutMenuItem.Shortcut = CType(resources.GetObject("aboutMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.aboutMenuItem.ShowShortcut = CType(resources.GetObject("aboutMenuItem.ShowShortcut"), Boolean)
        Me.aboutMenuItem.Text = resources.GetString("aboutMenuItem.Text")
        Me.aboutMenuItem.Visible = CType(resources.GetObject("aboutMenuItem.Visible"), Boolean)
        '
        'printPrevDlg
        '
        Me.printPrevDlg.AccessibleDescription = resources.GetString("printPrevDlg.AccessibleDescription")
        Me.printPrevDlg.AccessibleName = resources.GetString("printPrevDlg.AccessibleName")
        Me.printPrevDlg.Anchor = CType(resources.GetObject("printPrevDlg.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.printPrevDlg.AutoScaleBaseSize = CType(resources.GetObject("printPrevDlg.AutoScaleBaseSize"), System.Drawing.Size)
        Me.printPrevDlg.AutoScroll = CType(resources.GetObject("printPrevDlg.AutoScroll"), Boolean)
        Me.printPrevDlg.AutoScrollMargin = CType(resources.GetObject("printPrevDlg.AutoScrollMargin"), System.Drawing.Size)
        Me.printPrevDlg.AutoScrollMinSize = CType(resources.GetObject("printPrevDlg.AutoScrollMinSize"), System.Drawing.Size)
        Me.printPrevDlg.BackgroundImage = CType(resources.GetObject("printPrevDlg.BackgroundImage"), System.Drawing.Image)
        Me.printPrevDlg.ClientSize = CType(resources.GetObject("printPrevDlg.ClientSize"), System.Drawing.Size)
        Me.printPrevDlg.Dock = CType(resources.GetObject("printPrevDlg.Dock"), System.Windows.Forms.DockStyle)
        Me.printPrevDlg.Enabled = CType(resources.GetObject("printPrevDlg.Enabled"), Boolean)
        Me.printPrevDlg.Font = CType(resources.GetObject("printPrevDlg.Font"), System.Drawing.Font)
        Me.printPrevDlg.Icon = CType(resources.GetObject("printPrevDlg.Icon"), System.Drawing.Icon)
        Me.printPrevDlg.ImeMode = CType(resources.GetObject("printPrevDlg.ImeMode"), System.Windows.Forms.ImeMode)
        Me.printPrevDlg.Location = CType(resources.GetObject("printPrevDlg.Location1"), System.Drawing.Point)
        Me.printPrevDlg.MaximumSize = CType(resources.GetObject("printPrevDlg.MaximumSize"), System.Drawing.Size)
        Me.printPrevDlg.MinimumSize = CType(resources.GetObject("printPrevDlg.MinimumSize"), System.Drawing.Size)
        Me.printPrevDlg.Name = "printPrevDlg"
        Me.printPrevDlg.RightToLeft = CType(resources.GetObject("printPrevDlg.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.printPrevDlg.StartPosition = CType(resources.GetObject("printPrevDlg.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.printPrevDlg.Text = resources.GetString("printPrevDlg.Text")
        Me.printPrevDlg.TransparencyKey = System.Drawing.Color.Empty
        Me.printPrevDlg.Visible = CType(resources.GetObject("printPrevDlg.Visible"), Boolean)
        '
        'pnlLayouts
        '
        Me.pnlLayouts.AccessibleDescription = resources.GetString("pnlLayouts.AccessibleDescription")
        Me.pnlLayouts.AccessibleName = resources.GetString("pnlLayouts.AccessibleName")
        Me.pnlLayouts.Anchor = CType(resources.GetObject("pnlLayouts.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.pnlLayouts.AutoScroll = CType(resources.GetObject("pnlLayouts.AutoScroll"), Boolean)
        Me.pnlLayouts.AutoScrollMargin = CType(resources.GetObject("pnlLayouts.AutoScrollMargin"), System.Drawing.Size)
        Me.pnlLayouts.AutoScrollMinSize = CType(resources.GetObject("pnlLayouts.AutoScrollMinSize"), System.Drawing.Size)
        Me.pnlLayouts.BackgroundImage = CType(resources.GetObject("pnlLayouts.BackgroundImage"), System.Drawing.Image)
        Me.pnlLayouts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlLayouts.Controls.Add(Me.label1)
        Me.pnlLayouts.Controls.Add(Me.cbLayouts)
        Me.pnlLayouts.Dock = CType(resources.GetObject("pnlLayouts.Dock"), System.Windows.Forms.DockStyle)
        Me.pnlLayouts.Enabled = CType(resources.GetObject("pnlLayouts.Enabled"), Boolean)
        Me.pnlLayouts.Font = CType(resources.GetObject("pnlLayouts.Font"), System.Drawing.Font)
        Me.pnlLayouts.ImeMode = CType(resources.GetObject("pnlLayouts.ImeMode"), System.Windows.Forms.ImeMode)
        Me.pnlLayouts.Location = CType(resources.GetObject("pnlLayouts.Location"), System.Drawing.Point)
        Me.pnlLayouts.Name = "pnlLayouts"
        Me.pnlLayouts.RightToLeft = CType(resources.GetObject("pnlLayouts.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.pnlLayouts.Size = CType(resources.GetObject("pnlLayouts.Size"), System.Drawing.Size)
        Me.pnlLayouts.TabIndex = CType(resources.GetObject("pnlLayouts.TabIndex"), Integer)
        Me.pnlLayouts.Text = resources.GetString("pnlLayouts.Text")
        Me.pnlLayouts.Visible = CType(resources.GetObject("pnlLayouts.Visible"), Boolean)
        '
        'label1
        '
        Me.label1.AccessibleDescription = resources.GetString("label1.AccessibleDescription")
        Me.label1.AccessibleName = resources.GetString("label1.AccessibleName")
        Me.label1.Anchor = CType(resources.GetObject("label1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.label1.AutoSize = CType(resources.GetObject("label1.AutoSize"), Boolean)
        Me.label1.Dock = CType(resources.GetObject("label1.Dock"), System.Windows.Forms.DockStyle)
        Me.label1.Enabled = CType(resources.GetObject("label1.Enabled"), Boolean)
        Me.label1.Font = CType(resources.GetObject("label1.Font"), System.Drawing.Font)
        Me.label1.Image = CType(resources.GetObject("label1.Image"), System.Drawing.Image)
        Me.label1.ImageAlign = CType(resources.GetObject("label1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.label1.ImageIndex = CType(resources.GetObject("label1.ImageIndex"), Integer)
        Me.label1.ImeMode = CType(resources.GetObject("label1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.label1.Location = CType(resources.GetObject("label1.Location"), System.Drawing.Point)
        Me.label1.Name = "label1"
        Me.label1.RightToLeft = CType(resources.GetObject("label1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.label1.Size = CType(resources.GetObject("label1.Size"), System.Drawing.Size)
        Me.label1.TabIndex = CType(resources.GetObject("label1.TabIndex"), Integer)
        Me.label1.Text = resources.GetString("label1.Text")
        Me.label1.TextAlign = CType(resources.GetObject("label1.TextAlign"), System.Drawing.ContentAlignment)
        Me.label1.Visible = CType(resources.GetObject("label1.Visible"), Boolean)
        '
        'cbLayouts
        '
        Me.cbLayouts.AccessibleDescription = resources.GetString("cbLayouts.AccessibleDescription")
        Me.cbLayouts.AccessibleName = resources.GetString("cbLayouts.AccessibleName")
        Me.cbLayouts.Anchor = CType(resources.GetObject("cbLayouts.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.cbLayouts.BackgroundImage = CType(resources.GetObject("cbLayouts.BackgroundImage"), System.Drawing.Image)
        Me.cbLayouts.Dock = CType(resources.GetObject("cbLayouts.Dock"), System.Windows.Forms.DockStyle)
        Me.cbLayouts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbLayouts.Enabled = CType(resources.GetObject("cbLayouts.Enabled"), Boolean)
        Me.cbLayouts.Font = CType(resources.GetObject("cbLayouts.Font"), System.Drawing.Font)
        Me.cbLayouts.ImeMode = CType(resources.GetObject("cbLayouts.ImeMode"), System.Windows.Forms.ImeMode)
        Me.cbLayouts.IntegralHeight = CType(resources.GetObject("cbLayouts.IntegralHeight"), Boolean)
        Me.cbLayouts.ItemHeight = CType(resources.GetObject("cbLayouts.ItemHeight"), Integer)
        Me.cbLayouts.Location = CType(resources.GetObject("cbLayouts.Location"), System.Drawing.Point)
        Me.cbLayouts.MaxDropDownItems = CType(resources.GetObject("cbLayouts.MaxDropDownItems"), Integer)
        Me.cbLayouts.MaxLength = CType(resources.GetObject("cbLayouts.MaxLength"), Integer)
        Me.cbLayouts.Name = "cbLayouts"
        Me.cbLayouts.RightToLeft = CType(resources.GetObject("cbLayouts.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.cbLayouts.Size = CType(resources.GetObject("cbLayouts.Size"), System.Drawing.Size)
        Me.cbLayouts.TabIndex = CType(resources.GetObject("cbLayouts.TabIndex"), Integer)
        Me.cbLayouts.Tag = "-1"
        Me.cbLayouts.Text = resources.GetString("cbLayouts.Text")
        Me.cbLayouts.Visible = CType(resources.GetObject("cbLayouts.Visible"), Boolean)
        '
        'tlbTool
        '
        Me.tlbTool.AccessibleDescription = resources.GetString("tlbTool.AccessibleDescription")
        Me.tlbTool.AccessibleName = resources.GetString("tlbTool.AccessibleName")
        Me.tlbTool.Anchor = CType(resources.GetObject("tlbTool.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tlbTool.Appearance = CType(resources.GetObject("tlbTool.Appearance"), System.Windows.Forms.ToolBarAppearance)
        Me.tlbTool.AutoSize = CType(resources.GetObject("tlbTool.AutoSize"), Boolean)
        Me.tlbTool.BackgroundImage = CType(resources.GetObject("tlbTool.BackgroundImage"), System.Drawing.Image)
        Me.tlbTool.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tlbTool.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.tlbOpen, Me.tlbZoomIn, Me.tlbZoomOut, Me.tlbSave, Me.tlbWhite, Me.tlbBlack, Me.tlbColor, Me.tlb3d, Me.tlbLay, Me.tlbArcPoly, Me.tlbBlackMode, Me.tlbColorMode, Me.tlbDefSize, Me.tlbTextShow, Me.tlbDimShow, Me.tlbSaveImageClip, Me.tlbPrint, Me.tlbSHX, Me.tlbRect, Me.tlbSelObject})
        Me.tlbTool.ButtonSize = CType(resources.GetObject("tlbTool.ButtonSize"), System.Drawing.Size)
        Me.tlbTool.Dock = CType(resources.GetObject("tlbTool.Dock"), System.Windows.Forms.DockStyle)
        Me.tlbTool.DropDownArrows = CType(resources.GetObject("tlbTool.DropDownArrows"), Boolean)
        Me.tlbTool.Enabled = CType(resources.GetObject("tlbTool.Enabled"), Boolean)
        Me.tlbTool.Font = CType(resources.GetObject("tlbTool.Font"), System.Drawing.Font)
        Me.tlbTool.ImageList = Me.toolBtnImageList
        Me.tlbTool.ImeMode = CType(resources.GetObject("tlbTool.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tlbTool.Location = CType(resources.GetObject("tlbTool.Location"), System.Drawing.Point)
        Me.tlbTool.Name = "tlbTool"
        Me.tlbTool.RightToLeft = CType(resources.GetObject("tlbTool.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tlbTool.ShowToolTips = CType(resources.GetObject("tlbTool.ShowToolTips"), Boolean)
        Me.tlbTool.Size = CType(resources.GetObject("tlbTool.Size"), System.Drawing.Size)
        Me.tlbTool.TabIndex = CType(resources.GetObject("tlbTool.TabIndex"), Integer)
        Me.tlbTool.TextAlign = CType(resources.GetObject("tlbTool.TextAlign"), System.Windows.Forms.ToolBarTextAlign)
        Me.tlbTool.Visible = CType(resources.GetObject("tlbTool.Visible"), Boolean)
        Me.tlbTool.Wrappable = CType(resources.GetObject("tlbTool.Wrappable"), Boolean)
        '
        'tlbOpen
        '
        Me.tlbOpen.Enabled = CType(resources.GetObject("tlbOpen.Enabled"), Boolean)
        Me.tlbOpen.ImageIndex = CType(resources.GetObject("tlbOpen.ImageIndex"), Integer)
        Me.tlbOpen.Text = resources.GetString("tlbOpen.Text")
        Me.tlbOpen.ToolTipText = resources.GetString("tlbOpen.ToolTipText")
        Me.tlbOpen.Visible = CType(resources.GetObject("tlbOpen.Visible"), Boolean)
        '
        'tlbZoomIn
        '
        Me.tlbZoomIn.Enabled = CType(resources.GetObject("tlbZoomIn.Enabled"), Boolean)
        Me.tlbZoomIn.ImageIndex = CType(resources.GetObject("tlbZoomIn.ImageIndex"), Integer)
        Me.tlbZoomIn.Text = resources.GetString("tlbZoomIn.Text")
        Me.tlbZoomIn.ToolTipText = resources.GetString("tlbZoomIn.ToolTipText")
        Me.tlbZoomIn.Visible = CType(resources.GetObject("tlbZoomIn.Visible"), Boolean)
        '
        'tlbZoomOut
        '
        Me.tlbZoomOut.Enabled = CType(resources.GetObject("tlbZoomOut.Enabled"), Boolean)
        Me.tlbZoomOut.ImageIndex = CType(resources.GetObject("tlbZoomOut.ImageIndex"), Integer)
        Me.tlbZoomOut.Text = resources.GetString("tlbZoomOut.Text")
        Me.tlbZoomOut.ToolTipText = resources.GetString("tlbZoomOut.ToolTipText")
        Me.tlbZoomOut.Visible = CType(resources.GetObject("tlbZoomOut.Visible"), Boolean)
        '
        'tlbSave
        '
        Me.tlbSave.Enabled = CType(resources.GetObject("tlbSave.Enabled"), Boolean)
        Me.tlbSave.ImageIndex = CType(resources.GetObject("tlbSave.ImageIndex"), Integer)
        Me.tlbSave.Text = resources.GetString("tlbSave.Text")
        Me.tlbSave.ToolTipText = resources.GetString("tlbSave.ToolTipText")
        Me.tlbSave.Visible = CType(resources.GetObject("tlbSave.Visible"), Boolean)
        '
        'tlbWhite
        '
        Me.tlbWhite.Enabled = CType(resources.GetObject("tlbWhite.Enabled"), Boolean)
        Me.tlbWhite.ImageIndex = CType(resources.GetObject("tlbWhite.ImageIndex"), Integer)
        Me.tlbWhite.Text = resources.GetString("tlbWhite.Text")
        Me.tlbWhite.ToolTipText = resources.GetString("tlbWhite.ToolTipText")
        Me.tlbWhite.Visible = CType(resources.GetObject("tlbWhite.Visible"), Boolean)
        '
        'tlbBlack
        '
        Me.tlbBlack.Enabled = CType(resources.GetObject("tlbBlack.Enabled"), Boolean)
        Me.tlbBlack.ImageIndex = CType(resources.GetObject("tlbBlack.ImageIndex"), Integer)
        Me.tlbBlack.Text = resources.GetString("tlbBlack.Text")
        Me.tlbBlack.ToolTipText = resources.GetString("tlbBlack.ToolTipText")
        Me.tlbBlack.Visible = CType(resources.GetObject("tlbBlack.Visible"), Boolean)
        '
        'tlbColor
        '
        Me.tlbColor.Enabled = CType(resources.GetObject("tlbColor.Enabled"), Boolean)
        Me.tlbColor.ImageIndex = CType(resources.GetObject("tlbColor.ImageIndex"), Integer)
        Me.tlbColor.Text = resources.GetString("tlbColor.Text")
        Me.tlbColor.ToolTipText = resources.GetString("tlbColor.ToolTipText")
        Me.tlbColor.Visible = CType(resources.GetObject("tlbColor.Visible"), Boolean)
        '
        'tlb3d
        '
        Me.tlb3d.DropDownMenu = Me.orbitViewMenu
        Me.tlb3d.Enabled = CType(resources.GetObject("tlb3d.Enabled"), Boolean)
        Me.tlb3d.ImageIndex = CType(resources.GetObject("tlb3d.ImageIndex"), Integer)
        Me.tlb3d.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton
        Me.tlb3d.Text = resources.GetString("tlb3d.Text")
        Me.tlb3d.ToolTipText = resources.GetString("tlb3d.ToolTipText")
        Me.tlb3d.Visible = CType(resources.GetObject("tlb3d.Visible"), Boolean)
        '
        'tlbLay
        '
        Me.tlbLay.Enabled = CType(resources.GetObject("tlbLay.Enabled"), Boolean)
        Me.tlbLay.ImageIndex = CType(resources.GetObject("tlbLay.ImageIndex"), Integer)
        Me.tlbLay.Text = resources.GetString("tlbLay.Text")
        Me.tlbLay.ToolTipText = resources.GetString("tlbLay.ToolTipText")
        Me.tlbLay.Visible = CType(resources.GetObject("tlbLay.Visible"), Boolean)
        '
        'tlbArcPoly
        '
        Me.tlbArcPoly.Enabled = CType(resources.GetObject("tlbArcPoly.Enabled"), Boolean)
        Me.tlbArcPoly.ImageIndex = CType(resources.GetObject("tlbArcPoly.ImageIndex"), Integer)
        Me.tlbArcPoly.Pushed = True
        Me.tlbArcPoly.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.tlbArcPoly.Tag = ""
        Me.tlbArcPoly.Text = resources.GetString("tlbArcPoly.Text")
        Me.tlbArcPoly.ToolTipText = resources.GetString("tlbArcPoly.ToolTipText")
        Me.tlbArcPoly.Visible = CType(resources.GetObject("tlbArcPoly.Visible"), Boolean)
        '
        'tlbBlackMode
        '
        Me.tlbBlackMode.Enabled = CType(resources.GetObject("tlbBlackMode.Enabled"), Boolean)
        Me.tlbBlackMode.ImageIndex = CType(resources.GetObject("tlbBlackMode.ImageIndex"), Integer)
        Me.tlbBlackMode.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.tlbBlackMode.Text = resources.GetString("tlbBlackMode.Text")
        Me.tlbBlackMode.ToolTipText = resources.GetString("tlbBlackMode.ToolTipText")
        Me.tlbBlackMode.Visible = CType(resources.GetObject("tlbBlackMode.Visible"), Boolean)
        '
        'tlbColorMode
        '
        Me.tlbColorMode.Enabled = CType(resources.GetObject("tlbColorMode.Enabled"), Boolean)
        Me.tlbColorMode.ImageIndex = CType(resources.GetObject("tlbColorMode.ImageIndex"), Integer)
        Me.tlbColorMode.Pushed = True
        Me.tlbColorMode.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.tlbColorMode.Text = resources.GetString("tlbColorMode.Text")
        Me.tlbColorMode.ToolTipText = resources.GetString("tlbColorMode.ToolTipText")
        Me.tlbColorMode.Visible = CType(resources.GetObject("tlbColorMode.Visible"), Boolean)
        '
        'tlbDefSize
        '
        Me.tlbDefSize.Enabled = CType(resources.GetObject("tlbDefSize.Enabled"), Boolean)
        Me.tlbDefSize.ImageIndex = CType(resources.GetObject("tlbDefSize.ImageIndex"), Integer)
        Me.tlbDefSize.Text = resources.GetString("tlbDefSize.Text")
        Me.tlbDefSize.ToolTipText = resources.GetString("tlbDefSize.ToolTipText")
        Me.tlbDefSize.Visible = CType(resources.GetObject("tlbDefSize.Visible"), Boolean)
        '
        'tlbTextShow
        '
        Me.tlbTextShow.Enabled = CType(resources.GetObject("tlbTextShow.Enabled"), Boolean)
        Me.tlbTextShow.ImageIndex = CType(resources.GetObject("tlbTextShow.ImageIndex"), Integer)
        Me.tlbTextShow.Pushed = True
        Me.tlbTextShow.Text = resources.GetString("tlbTextShow.Text")
        Me.tlbTextShow.ToolTipText = resources.GetString("tlbTextShow.ToolTipText")
        Me.tlbTextShow.Visible = CType(resources.GetObject("tlbTextShow.Visible"), Boolean)
        '
        'tlbDimShow
        '
        Me.tlbDimShow.Enabled = CType(resources.GetObject("tlbDimShow.Enabled"), Boolean)
        Me.tlbDimShow.ImageIndex = CType(resources.GetObject("tlbDimShow.ImageIndex"), Integer)
        Me.tlbDimShow.Pushed = True
        Me.tlbDimShow.Text = resources.GetString("tlbDimShow.Text")
        Me.tlbDimShow.ToolTipText = resources.GetString("tlbDimShow.ToolTipText")
        Me.tlbDimShow.Visible = CType(resources.GetObject("tlbDimShow.Visible"), Boolean)
        '
        'tlbSaveImageClip
        '
        Me.tlbSaveImageClip.Enabled = CType(resources.GetObject("tlbSaveImageClip.Enabled"), Boolean)
        Me.tlbSaveImageClip.ImageIndex = CType(resources.GetObject("tlbSaveImageClip.ImageIndex"), Integer)
        Me.tlbSaveImageClip.Text = resources.GetString("tlbSaveImageClip.Text")
        Me.tlbSaveImageClip.ToolTipText = resources.GetString("tlbSaveImageClip.ToolTipText")
        Me.tlbSaveImageClip.Visible = CType(resources.GetObject("tlbSaveImageClip.Visible"), Boolean)
        '
        'tlbPrint
        '
        Me.tlbPrint.Enabled = CType(resources.GetObject("tlbPrint.Enabled"), Boolean)
        Me.tlbPrint.ImageIndex = CType(resources.GetObject("tlbPrint.ImageIndex"), Integer)
        Me.tlbPrint.Text = resources.GetString("tlbPrint.Text")
        Me.tlbPrint.ToolTipText = resources.GetString("tlbPrint.ToolTipText")
        Me.tlbPrint.Visible = CType(resources.GetObject("tlbPrint.Visible"), Boolean)
        '
        'tlbSHX
        '
        Me.tlbSHX.Enabled = CType(resources.GetObject("tlbSHX.Enabled"), Boolean)
        Me.tlbSHX.ImageIndex = CType(resources.GetObject("tlbSHX.ImageIndex"), Integer)
        Me.tlbSHX.Pushed = True
        Me.tlbSHX.Text = resources.GetString("tlbSHX.Text")
        Me.tlbSHX.ToolTipText = resources.GetString("tlbSHX.ToolTipText")
        Me.tlbSHX.Visible = CType(resources.GetObject("tlbSHX.Visible"), Boolean)
        '
        'tlbRect
        '
        Me.tlbRect.Enabled = CType(resources.GetObject("tlbRect.Enabled"), Boolean)
        Me.tlbRect.ImageIndex = CType(resources.GetObject("tlbRect.ImageIndex"), Integer)
        Me.tlbRect.Text = resources.GetString("tlbRect.Text")
        Me.tlbRect.ToolTipText = resources.GetString("tlbRect.ToolTipText")
        Me.tlbRect.Visible = CType(resources.GetObject("tlbRect.Visible"), Boolean)
        '
        'tlbSelObject
        '
        Me.tlbSelObject.Enabled = CType(resources.GetObject("tlbSelObject.Enabled"), Boolean)
        Me.tlbSelObject.ImageIndex = CType(resources.GetObject("tlbSelObject.ImageIndex"), Integer)
        Me.tlbSelObject.Text = resources.GetString("tlbSelObject.Text")
        Me.tlbSelObject.ToolTipText = resources.GetString("tlbSelObject.ToolTipText")
        Me.tlbSelObject.Visible = CType(resources.GetObject("tlbSelObject.Visible"), Boolean)
        '
        'toolBtnImageList
        '
        Me.toolBtnImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit
        Me.toolBtnImageList.ImageSize = CType(resources.GetObject("toolBtnImageList.ImageSize"), System.Drawing.Size)
        Me.toolBtnImageList.ImageStream = CType(resources.GetObject("toolBtnImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.toolBtnImageList.TransparentColor = System.Drawing.Color.Magenta
        '
        'cadPictBox
        '
        Me.cadPictBox.AccessibleDescription = resources.GetString("cadPictBox.AccessibleDescription")
        Me.cadPictBox.AccessibleName = resources.GetString("cadPictBox.AccessibleName")
        Me.cadPictBox.Anchor = CType(resources.GetObject("cadPictBox.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.cadPictBox.BackColor = System.Drawing.Color.Black
        Me.cadPictBox.BackgroundImage = CType(resources.GetObject("cadPictBox.BackgroundImage"), System.Drawing.Image)
        Me.cadPictBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.cadPictBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.cadPictBox.Dock = CType(resources.GetObject("cadPictBox.Dock"), System.Windows.Forms.DockStyle)
        Me.cadPictBox.Enabled = CType(resources.GetObject("cadPictBox.Enabled"), Boolean)
        Me.cadPictBox.Font = CType(resources.GetObject("cadPictBox.Font"), System.Drawing.Font)
        Me.cadPictBox.Image = CType(resources.GetObject("cadPictBox.Image"), System.Drawing.Image)
        Me.cadPictBox.ImeMode = CType(resources.GetObject("cadPictBox.ImeMode"), System.Windows.Forms.ImeMode)
        Me.cadPictBox.Location = CType(resources.GetObject("cadPictBox.Location"), System.Drawing.Point)
        Me.cadPictBox.Name = "cadPictBox"
        Me.cadPictBox.RightToLeft = CType(resources.GetObject("cadPictBox.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.cadPictBox.Size = CType(resources.GetObject("cadPictBox.Size"), System.Drawing.Size)
        Me.cadPictBox.SizeMode = CType(resources.GetObject("cadPictBox.SizeMode"), System.Windows.Forms.PictureBoxSizeMode)
        Me.cadPictBox.TabIndex = CType(resources.GetObject("cadPictBox.TabIndex"), Integer)
        Me.cadPictBox.TabStop = False
        Me.cadPictBox.Text = resources.GetString("cadPictBox.Text")
        Me.cadPictBox.Visible = CType(resources.GetObject("cadPictBox.Visible"), Boolean)
        '
        'trvPanel
        '
        Me.trvPanel.AccessibleDescription = resources.GetString("trvPanel.AccessibleDescription")
        Me.trvPanel.AccessibleName = resources.GetString("trvPanel.AccessibleName")
        Me.trvPanel.Anchor = CType(resources.GetObject("trvPanel.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.trvPanel.AutoScroll = CType(resources.GetObject("trvPanel.AutoScroll"), Boolean)
        Me.trvPanel.AutoScrollMargin = CType(resources.GetObject("trvPanel.AutoScrollMargin"), System.Drawing.Size)
        Me.trvPanel.AutoScrollMinSize = CType(resources.GetObject("trvPanel.AutoScrollMinSize"), System.Drawing.Size)
        Me.trvPanel.BackgroundImage = CType(resources.GetObject("trvPanel.BackgroundImage"), System.Drawing.Image)
        Me.trvPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.trvPanel.Controls.Add(Me.trvEntity)
        Me.trvPanel.Controls.Add(Me.propGrid)
        Me.trvPanel.Dock = CType(resources.GetObject("trvPanel.Dock"), System.Windows.Forms.DockStyle)
        Me.trvPanel.Enabled = CType(resources.GetObject("trvPanel.Enabled"), Boolean)
        Me.trvPanel.Font = CType(resources.GetObject("trvPanel.Font"), System.Drawing.Font)
        Me.trvPanel.ImeMode = CType(resources.GetObject("trvPanel.ImeMode"), System.Windows.Forms.ImeMode)
        Me.trvPanel.Location = CType(resources.GetObject("trvPanel.Location"), System.Drawing.Point)
        Me.trvPanel.Name = "trvPanel"
        Me.trvPanel.RightToLeft = CType(resources.GetObject("trvPanel.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.trvPanel.Size = CType(resources.GetObject("trvPanel.Size"), System.Drawing.Size)
        Me.trvPanel.TabIndex = CType(resources.GetObject("trvPanel.TabIndex"), Integer)
        Me.trvPanel.Text = resources.GetString("trvPanel.Text")
        Me.trvPanel.Visible = CType(resources.GetObject("trvPanel.Visible"), Boolean)
        '
        'trvEntity
        '
        Me.trvEntity.AccessibleDescription = resources.GetString("trvEntity.AccessibleDescription")
        Me.trvEntity.AccessibleName = resources.GetString("trvEntity.AccessibleName")
        Me.trvEntity.Anchor = CType(resources.GetObject("trvEntity.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.trvEntity.BackColor = System.Drawing.Color.Black
        Me.trvEntity.BackgroundImage = CType(resources.GetObject("trvEntity.BackgroundImage"), System.Drawing.Image)
        Me.trvEntity.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.trvEntity.CheckBoxes = True
        Me.trvEntity.Dock = CType(resources.GetObject("trvEntity.Dock"), System.Windows.Forms.DockStyle)
        Me.trvEntity.Enabled = CType(resources.GetObject("trvEntity.Enabled"), Boolean)
        Me.trvEntity.Font = CType(resources.GetObject("trvEntity.Font"), System.Drawing.Font)
        Me.trvEntity.ForeColor = System.Drawing.Color.White
        Me.trvEntity.ImageIndex = CType(resources.GetObject("trvEntity.ImageIndex"), Integer)
        Me.trvEntity.ImeMode = CType(resources.GetObject("trvEntity.ImeMode"), System.Windows.Forms.ImeMode)
        Me.trvEntity.Indent = CType(resources.GetObject("trvEntity.Indent"), Integer)
        Me.trvEntity.ItemHeight = CType(resources.GetObject("trvEntity.ItemHeight"), Integer)
        Me.trvEntity.Location = CType(resources.GetObject("trvEntity.Location"), System.Drawing.Point)
        Me.trvEntity.Name = "trvEntity"
        Me.trvEntity.RightToLeft = CType(resources.GetObject("trvEntity.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.trvEntity.SelectedImageIndex = CType(resources.GetObject("trvEntity.SelectedImageIndex"), Integer)
        Me.trvEntity.Size = CType(resources.GetObject("trvEntity.Size"), System.Drawing.Size)
        Me.trvEntity.TabIndex = CType(resources.GetObject("trvEntity.TabIndex"), Integer)
        Me.trvEntity.Text = resources.GetString("trvEntity.Text")
        Me.trvEntity.Visible = CType(resources.GetObject("trvEntity.Visible"), Boolean)
        '
        'propGrid
        '
        Me.propGrid.AccessibleDescription = resources.GetString("propGrid.AccessibleDescription")
        Me.propGrid.AccessibleName = resources.GetString("propGrid.AccessibleName")
        Me.propGrid.Anchor = CType(resources.GetObject("propGrid.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.propGrid.BackColor = System.Drawing.SystemColors.Control
        Me.propGrid.BackgroundImage = CType(resources.GetObject("propGrid.BackgroundImage"), System.Drawing.Image)
        Me.propGrid.CommandsBackColor = System.Drawing.Color.White
        Me.propGrid.CommandsVisibleIfAvailable = True
        Me.propGrid.Dock = CType(resources.GetObject("propGrid.Dock"), System.Windows.Forms.DockStyle)
        Me.propGrid.Enabled = CType(resources.GetObject("propGrid.Enabled"), Boolean)
        Me.propGrid.Font = CType(resources.GetObject("propGrid.Font"), System.Drawing.Font)
        Me.propGrid.HelpVisible = CType(resources.GetObject("propGrid.HelpVisible"), Boolean)
        Me.propGrid.ImeMode = CType(resources.GetObject("propGrid.ImeMode"), System.Windows.Forms.ImeMode)
        Me.propGrid.LargeButtons = False
        Me.propGrid.LineColor = System.Drawing.SystemColors.ScrollBar
        Me.propGrid.Location = CType(resources.GetObject("propGrid.Location"), System.Drawing.Point)
        Me.propGrid.Name = "propGrid"
        Me.propGrid.RightToLeft = CType(resources.GetObject("propGrid.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.propGrid.Size = CType(resources.GetObject("propGrid.Size"), System.Drawing.Size)
        Me.propGrid.TabIndex = CType(resources.GetObject("propGrid.TabIndex"), Integer)
        Me.propGrid.Text = resources.GetString("propGrid.Text")
        Me.propGrid.ViewBackColor = System.Drawing.SystemColors.Window
        Me.propGrid.ViewForeColor = System.Drawing.SystemColors.WindowText
        Me.propGrid.Visible = CType(resources.GetObject("propGrid.Visible"), Boolean)
        '
        'saveDXFDlg
        '
        Me.saveDXFDlg.DefaultExt = "*.dxf"
        Me.saveDXFDlg.Filter = resources.GetString("saveDXFDlg.Filter")
        Me.saveDXFDlg.Title = resources.GetString("saveDXFDlg.Title")
        '
        'MainForm
        '
        Me.AccessibleDescription = resources.GetString("$this.AccessibleDescription")
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.Controls.Add(Me.cadPictBox)
        Me.Controls.Add(Me.trvPanel)
        Me.Controls.Add(Me.pnlLayouts)
        Me.Controls.Add(Me.tlbTool)
        Me.Controls.Add(Me.splitter1)
        Me.Controls.Add(Me.stBar)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.Menu = Me.mainMenu
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "MainForm"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.sbOpen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbScale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbCoord, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLayouts.ResumeLayout(False)
        Me.trvPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Shared Sub New()
        HPGLExt = New ArrayList(New String() {".HPG", ".PLT", ".RTL", ".SPL", ".PRN", ".GL2", ".HPGL2", ".HPGL", _
              ".HP2", ".HP1", ".HP", ".PLO", ".HG", ".HGL"})
    End Sub

    <System.STAThread()> _
     Public Shared Sub Main()
        Application.EnableVisualStyles()
        Application.DoEvents()
        Application.Run(New MainForm)
    End Sub

    <System.Security.Permissions.PermissionSetAttribute(System.Security.Permissions.SecurityAction.Demand, Name:="FullTrust")> _
   Protected Overrides Sub WndProc(ByRef m As Message)
        If ((m.Msg = 274) AndAlso (m.WParam.ToInt32 = 61472)) Then
            Me.deactiv = True
        End If
        If (m.Msg = 522) Then
            If (m.WParam.ToInt32 < 0) Then
                Me.Zoom(0.7!)
            Else
                Me.Zoom(1.3!)
            End If
        End If
        MyBase.WndProc(m)
    End Sub

    Public Sub Zoom(ByVal i As Single)
        If (Not Me.FCADImage Is Nothing) Then
            Me.scl = (Me.scl * i)
            If (Me.scl < 0.005!) Then
                Me.scl = 0.005!
            End If
            Me.cadPictBox.Invalidate()
            Me.cadPictBox_MouseMove(Me.cadPictBox, New MouseEventArgs(MouseButtons.Left, 0, CType(Me.old_Pos.X, Integer), CType(Me.old_Pos.Y, Integer), 0))
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Public Sub LoadFile(ByVal dlg As Boolean)
        Me.cadPictBox.Visible = False
        Me.propGrid.SelectedObject = Nothing
        Me.lForm.lstViewLay.Items.Clear()
        RemoveHandler Me.lForm.lstViewLay.ItemCheck, Me.dl1
        If (dlg AndAlso (Me.openFileDlg.ShowDialog(Me) <> DialogResult.OK)) Then
            Me.cadPictBox.Visible = True
        Else
            If (Not Me.openFileDlg.FileName Is Nothing) Then
                If (Not Me.FCADImage Is Nothing) Then
                    Me.FCADImage.Dispose()
                    Me.FCADImage = Nothing
                End If
                Me.Cursor = Cursors.WaitCursor
                Me.stBar.Panels.Item(0).Text = "Load file..."
                Me.pnlLayouts.Visible = False
                Me.scl = 1.0!
                Me.prev_scale = 1.0!
                Me.pos = New PointF
                Dim ext As String = Path.GetExtension(Me.openFileDlg.FileName).ToUpper()
                If (ext = ".DWG") Then
#If DWGModule Then
                    FCADImage = New DWG.DWGImage
                    FCADImage.LoadFromFile(Me.openFileDlg.FileName)
#Else
						NotSupportedInCurrentVersion()
						return

#End If
                Else
                    If (ext = ".DXF") Then
                        FCADImage = New CADImage
                        FCADImage.LoadFromFile(Me.openFileDlg.FileName)
                    Else
                        If (ext = ".CGM") Then
#If UseCGM Then
					dim tmpshx as Boolean = CADConst.UseSHXFonts
					if(CADConst.UseSHXFonts) then
						CADConst.UseMultyTTFFonts = true
						CADConst.UseTTFFonts = false
					else 
						CADConst.UseMultyTTFFonts = true
						CADConst.UseTTFFonts = true
					end if
					FCADImage = new CGM.CGMImage()
                            FCADImage.LoadFromFile(Me.openFileDlg.FileName)
#Else
                            NotSupportedInCurrentVersion()
                            Return
#End If
                        Else
                            If (HPGLExt.IndexOf(ext) <> -1) Then
                                FCADImage = New HPGLImage
                                FCADImage.LoadFromFile(Me.openFileDlg.FileName)
                            Else
                                FCADImage = New CADRasterImage(Me.cadPictBox)
                                FCADImage.LoadFromFile(Me.openFileDlg.FileName)
                            End If
                        End If
                    End If
                End If
            End If
            Me.tlbTool.Buttons.Item(8).Pushed = Me.FCADImage.IsDraw3DAxes
            Me.tlbTool.Buttons.Item(10).Pushed = True
            Me.tlbTool.Buttons.Item(11).Pushed = False
            Me.tlbTool.Buttons.Item(12).Pushed = False
            Me.tlbTool.Buttons.Item(7).Pushed = False
            Me.tlbTool.Buttons.Item(13).Pushed = True
            Me.colorMenuItem.Checked = True
            Me.blackMenuItem.Checked = False
            Me.FCADImage.UseWinEllipse = False
            Me.Orb3D.CADImage = Me.FCADImage
            Me.Orb3D.Visible = False
            Me.Orb3D.Disable3dOrbit()
            Me.EnableButton(True)
            If (Me.cadPictBox.BackColor.Equals(Color.White)) Then
                Me.White_Click()
            Else
                Me.Black_Click()
            End If
            If Not (Me.colorDraw) Then
                Me.DoBlackColor()
            End If
            Me.ViewLayouts()
            Me.DoResize()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
            Me.Cursor = Cursors.Default
            If Me.trvPanel.Visible Then
                CADImportFace.LoadTreeNodes(Me.trvEntity.Nodes, Me.FCADImage)
            End If
        End If
        SetLayList()
        ObjEntity.cadImage = FCADImage 'for object inspector
        ObjEntity.propGrid = Me.propGrid
    End Sub

    Private Sub NotSupportedInCurrentVersion()
        Me.Cursor = Cursors.Default
        Me.cadPictBox.Visible = True
        Me.stBar.Panels(0).Text = "not supported"
        MessageBox.Show("Not supported in current version!", "CADImport .Net")
        Return
    End Sub

    Public Sub EnableButton(ByVal aVal As Boolean)
        Dim num1 As Integer = 1
        Do While (num1 < 20)
            Me.tlbTool.Buttons.Item(num1).Enabled = aVal
            num1 += 1
        Loop
        Me.cbLayouts.Enabled = aVal
        Me.mScale.Enabled = aVal
        Me.mSaveFile.Enabled = aVal
        Me.cadPictBox.Visible = aVal
        Me.copyMenuItem.Enabled = aVal
        Me.zoomInMenuItem.Enabled = aVal
        Me.zoomOutMenuItem.Enabled = aVal
        Me.fitMenuItem.Enabled = aVal
        Me.colorMenuItem.Enabled = aVal
        Me.blackMenuItem.Enabled = aVal
        Me.whiteBackMenuItem.Enabled = aVal
        Me.blackBackMenuItem.Enabled = aVal
        Me.changeBackMenuItem.Enabled = aVal
        Me.showLineWeightMenuItem.Enabled = aVal
        Me.arcsSplitMenuItem.Enabled = aVal
        Me.dimShowMenuItem.Enabled = aVal
        Me.textsShowMenuItem.Enabled = aVal
        Me.layersShowMenuItem.Enabled = aVal
        Me.ViewMenuItem.Enabled = aVal
        Me.orbitMenuItem.Enabled = aVal
        Me.closeMenuItem.Enabled = aVal
        Me.printMenuItem.Enabled = aVal
        Me.printPrevItem.Enabled = aVal
        Me.print2Item.Enabled = aVal
#If Export Then
        Me.mSaveAsDXF.Enabled = aVal
#End If
    End Sub

    Public Sub Black_Click()
        Me.whiteBackMenuItem.Checked = False
        Me.blackBackMenuItem.Checked = True
        Me.tlbTool.Buttons.Item(4).Pushed = False
        Me.tlbTool.Buttons.Item(5).Pushed = True
        Me.cadPictBox.BackColor = Color.Black
        Me.trvEntity.BackColor = Color.Black
        Me.trvEntity.ForeColor = Color.White
        If (Not Me.FCADImage Is Nothing) Then
            Me.FCADImage.DefaultColor = Color.White
        End If
        If (Not Me.clipRectangle Is Nothing) Then
            Me.clipRectangle.Color = Color.White
        End If
    End Sub

    Public Sub AddSHXPaths()
        Me.shxFrm.ShowDialog()
        CADConst.SHXSearchPaths = ""
        Dim num1 As Integer = 0
        Do While (num1 < Me.shxFrm.lstDir.Items.Count)
            Dim obj1 As Object = CADConst.SHXSearchPaths
            CADConst.SHXSearchPaths = String.Concat(New Object() {obj1, CADConst.SHXSearchPaths, Me.shxFrm.lstDir.Items.Item(num1), ";"})
            num1 += 1
        Loop
        If CADConst.SearchSHXPaths Then
            Me.ReOpen()
        End If
    End Sub

    Public Sub cadPictBox_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles cadPictBox.MouseUp
        Try
            FCADImage.Select(e.X, e.Y)
        Catch
            Return
        End Try
        Me.det1 = False
        Me.cadPictBox.Cursor = Cursors.Default
        If (Me.clipRectangle.Enabled) Then
            If (Me.clipRectangle.Type = RectangleType.Zooming) Then
                If ((Me.clipRectangle.ClientRectangle.Width <= 5) And _
                    (Me.clipRectangle.ClientRectangle.Height <= 5)) Then
                    If (CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Enabled) Then
                        Me.cadPictBox.Invalidate(Me.FCADImage.GetSelectEntityRegion(Me.cadPictBox.ClientRectangle))
                        Return
                    End If
                    cadPictBox.Invalidate(Me.clipRectangle.ClientRectangle)
                    Return
                End If
                If (Me.scl > 1000) Then
                    cadPictBox.Invalidate()
                    Return
                End If
                Dim tmp1 As Single = Me.curClRect.Width / Me.clipRectangle.ClientRectangle.Width
                Dim tmp2 As Single = Me.curClRect.Height / Me.clipRectangle.ClientRectangle.Height
                If (tmp1 > tmp2) Then tmp1 = tmp2
                pos.X += Me.clipRectangle.ClientRectangle.Width / 2
                pos.Y += Me.clipRectangle.ClientRectangle.Height / 2
                Me.Zoom(tmp1)
            End If
        End If
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub cadPictBox_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles cadPictBox.MouseDown
        If ((e.Button = MouseButtons.Right) Or (e.Button = MouseButtons.Middle)) Then
            Form.ActiveForm.Cursor = Cursors.Hand
            Me.cX = e.X
            Me.cY = e.Y
            Me.det1 = True
        Else
            If ((Not Me.clipRectangle.Enabled) And (Not (Me.FCADImage Is Nothing)) And (Not Me.Orb3D.Visible)) Then _
                Me.clipRectangle.EnableRect(RectangleType.Zooming, New Rectangle(e.X, e.Y, 0, 0))
        End If
    End Sub

    Public Sub cadPictBox_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles cadPictBox.MouseMove
        Me.cadPictBox.Focus()
        If (Not Me.FCADImage Is Nothing) Then
            If (Me.det1 AndAlso Not Me.Orb3D.Visible) Then
                Me.pos.X = (Me.pos.X - (Me.cX - e.X))
                Me.pos.Y = (Me.pos.Y - (Me.cY - e.Y))
                Me.cX = e.X
                Me.cY = e.Y
                Me.cadPictBox.Invalidate()
            End If
            Me.old_Pos = New PointF(CType(e.X, Single), CType(e.Y, Single))
            Dim point1 As DPoint = Me.GetRealPointUsingsgImagePoint(CType(e.X, Single), CType(e.Y, Single))
            Me.stBar.Panels.Item(2).Text = String.Concat(New Object() {"", point1.X, " : ", point1.Y, " : 0"})
        End If
    End Sub

    Public Function GetRealPointUsingsgImagePoint(ByVal X As Single, ByVal Y As Single) As DPoint
        Dim point3 As DPoint
        Dim point4 As DPoint
        Dim point5 As DPoint
        Dim rectangle1 As Rectangle = New Rectangle
        rectangle1 = Me.curClRect
        Dim rect1 As New DRect(CType(rectangle1.Left, Double), CType(rectangle1.Top, Double), CType(rectangle1.Right, Double), CType(rectangle1.Bottom, Double))
        Dim single1 As Single = CType((Me.FCADImage.AbsHeight / Me.FCADImage.AbsWidth), Single)
        rect1.left = ((rect1.left * Me.scl) + Me.pos.X)
        rect1.right = ((rect1.right * Me.scl) + Me.pos.X)
        rect1.top = ((rect1.top * Me.scl) + Me.pos.Y)
        rect1.bottom = (rect1.top + ((rect1.right - rect1.left) * single1))
        Me.sclRect.X = (Me.FCADImage.AbsWidth / (rect1.right - rect1.left))
        Me.sclRect.Y = (Me.FCADImage.AbsHeight / (rect1.bottom - rect1.top))
        Dim point1 As New DPoint(0, 0, 0)
        Dim point2 As New DPoint(0, 0, 0)
        Dim rect2 As DRect = Me.FCADImage.Extents
        point1.X = (rect2.left + ((X - Me.pos.X) * Me.sclRect.X))
        point1.Y = (rect2.top - ((Y - Me.pos.Y) * Me.sclRect.Y))
        point5.X = (0.5 * (rect2.right + rect2.left))
        point5.Y = (0.5 * (rect2.top + rect2.bottom))
        point5.Z = (0.5 * (rect2.z2 + rect2.z1))
        point3.X = 1
        point3.Y = 0
        point3.Z = 0
        point4.X = 0
        point4.Y = 1
        point4.Z = 0
        point3 = Me.FCADImage.GetRealImagePoint(point3)
        point4 = Me.FCADImage.GetRealImagePoint(point4)
        Me.MoveToPosition(point1, point5, -1)
        point2.X = ((point1.X * point3.X) + (point1.Y * point3.Y))
        point2.Y = ((point1.X * point4.X) + (point1.Y * point4.Y))
        Me.MoveToPosition(point2, point5, 1)
        Return point2
    End Function

    Private Sub MoveToPosition(ByRef point As DPoint, ByVal aPos As DPoint, ByVal direction As Integer)
        point.X = (point.X + (direction * aPos.X))
        point.Y = (point.Y + (direction * aPos.Y))
        point.Z = (point.Z + (direction * aPos.Z))
    End Sub

    Public Sub Change3DAxesVisiblity()
        Me.FCADImage.IsDraw3DAxes = Not Me.FCADImage.IsDraw3DAxes
        Me.tlbTool.Buttons.Item(8).Pushed = Me.FCADImage.IsDraw3DAxes
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ChangeCurrLayoutIndex()
        Me.FCADImage.SetCurrentLayout(Me.cbLayouts.SelectedIndex)
        Me.DoResize()
        Me.ResetScaling()
        If (Me.cbLayouts.SelectedIndex <> 0) Then
            Me.tlbTool.Buttons.Item(7).Pushed = False
            Me.tlbTool.Buttons.Item(7).Enabled = False
            Me.Orb3D.Visible = False
            Me.Orb3D.Disable3dOrbit()
        Else
            Me.tlbTool.Buttons.Item(7).Enabled = True
        End If
    End Sub

    Public Sub ChangeDimensionsVisiblity()
        Me.tlbTool.Buttons.Item(14).Pushed = Not Me.tlbTool.Buttons.Item(14).Pushed
        Me.dimShowMenuItem.Checked = Not Me.dimShowMenuItem.Checked
        Me.FCADImage.DimensionsVisible = Not Me.FCADImage.DimensionsVisible
        If (Me.FCADImage.DimensionsVisible) Then
            Me.tlbTool.Buttons.Item(14).ImageIndex() = 16
        Else : Me.tlbTool.Buttons.Item(14).ImageIndex() = 17
        End If
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ChangeShowLineWeight()
        Me.showLineWeightMenuItem.Checked = Not Me.showLineWeightMenuItem.Checked
        Me.FCADImage.IsShowLineWeight = Me.showLineWeightMenuItem.Checked
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ChangeTextsVisiblity()
        Me.tlbTool.Buttons.Item(13).Pushed = Not Me.tlbTool.Buttons.Item(13).Pushed
        Me.textsShowMenuItem.Checked = Not Me.textsShowMenuItem.Checked
        Me.FCADImage.TextVisible = Not Me.FCADImage.TextVisible
        If (Me.FCADImage.TextVisible) Then
            Me.tlbTool.Buttons.Item(13).ImageIndex() = 14
        Else : Me.tlbTool.Buttons.Item(13).ImageIndex() = 15
        End If
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ChangeTreeVisiblity()
        Dim flag1 As Boolean = Not Me.trvEntity.Visible
        If flag1 Then
            CADImportFace.LoadTreeNodes(Me.trvEntity.Nodes, Me.FCADImage)
        End If
        Me.trvPanel.Visible = flag1
        Me.entitiesMenuItem.Checked = flag1
        Me.DoResize()
    End Sub

    Public Sub chLay_ItemCheck(ByVal sender As Object, ByVal e As ItemCheckEventArgs)
        If (e.NewValue = CheckState.Checked) Then
            Me.FCADImage.SetLayerVisible(e.Index, True)
        Else
            If (e.NewValue = CheckState.Unchecked) Then
                Me.FCADImage.SetLayerVisible(e.Index, False)
            End If
        End If
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub CloseFile()
        Me.cbLayouts.Items.Clear()
        Me.FCADImage.Dispose()
        Me.FCADImage = Nothing
        Me.EnableButton(False)
        Me.trvEntity.Nodes.Clear()
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub Color_Click()
        If (Me.setColorDlg.ShowDialog = DialogResult.OK) Then
            Me.cadPictBox.BackColor = Me.setColorDlg.Color
        End If
    End Sub

    Public Sub DoBlackColor()
        Me.FCADImage.DrawMode = CADDrawMode.Black
        Me.tlbTool.Buttons.Item(10).Pushed = True
        Me.tlbTool.Buttons.Item(11).Pushed = False
        Me.colorMenuItem.Checked = False
        Me.blackMenuItem.Checked = True
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub DoNormalColor()
        Me.FCADImage.DrawMode = CADDrawMode.Normal
        Me.tlbTool.Buttons.Item(10).Pushed = False
        Me.tlbTool.Buttons.Item(11).Pushed = True
        Me.colorMenuItem.Checked = True
        Me.blackMenuItem.Checked = False
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub DoResize()
        If ((Not Me.FCADImage Is Nothing) AndAlso Not Me.deactiv) Then
            Me.wh = CType((Me.FCADImage.AbsWidth / Me.FCADImage.AbsHeight), Single)
            Dim single1 As Single = (CType(Me.cadPictBox.ClientRectangle.Width, Single) / CType(Me.cadPictBox.ClientRectangle.Height, Single))
            Me.curClRect = Me.cadPictBox.ClientRectangle
            If (single1 > Me.wh) Then
                Me.curClRect.Width = CType((Me.curClRect.Height * Me.wh), Integer)
            Else
                If (single1 < Me.wh) Then
                    Me.curClRect.Height = CType((CType(Me.curClRect.Width, Single) / Me.wh), Integer)
                Else
                    Me.curClRect = Me.cadPictBox.ClientRectangle
                End If
            End If
            Me.pos.X = ((Me.cadPictBox.ClientRectangle.Width - Me.curClRect.Width) / 2)
            Me.pos.Y = ((Me.cadPictBox.ClientRectangle.Height - Me.curClRect.Height) / 2)
            Me.cadPictBox.Invalidate()
        End If
    End Sub

    Public Sub DoZoomIn()
        If (Not Me.FCADImage Is Nothing) Then
            Me.old_Pos = New PointF(CType((Me.cadPictBox.ClientRectangle.Width / 2), Single), CType((Me.cadPictBox.ClientRectangle.Height / 2), Single))
            Me.scl = (Me.scl * 2.0!)
            Me.cadPictBox.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Public Sub DoZoomOut()
        If (Not Me.FCADImage Is Nothing) Then
            Me.old_Pos = New PointF(CType((Me.cadPictBox.ClientRectangle.Width / 2), Single), CType((Me.cadPictBox.ClientRectangle.Height / 2), Single))
            Me.scl = (Me.scl / 2.0!)
            Me.cadPictBox.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Public Sub DrawCADImage(ByVal gr As Graphics)
        If (Not Me.FCADImage Is Nothing) Then
            Try
                Me.deactiv = False
                Me.Shift()
                Dim ef1 As New RectangleF(Me.pos.X, Me.pos.Y, (Me.curClRect.Width * Me.scl), (Me.curClRect.Height * Me.scl))
                Me.FCADImage.Draw(gr, ef1)
            Catch obj1 As Exception
            End Try
        End If
    End Sub

    Public Sub Go3dOrbit(ByVal val As Boolean)
        Orb3D.Visible = val
        tlbTool.Buttons(7).Pushed = val
        orbitMenuItem.Checked = val
        det1 = False
        If (val) Then
            DoEnableRectangle(False)
            Orb3D.Enable3dOrbit()
        Else
            Orb3D.Disable3dOrbit()
        End If
        cadPictBox.Invalidate()
    End Sub

    Public Sub Initial3DOrbit()
        Me.Orb3D.Parent = Me.cadPictBox
    End Sub

    Public Sub ResetScaling()
        Me.scl = 1.0!
        Me.prev_scale = 1.0!
        Me.pos.X = ((Me.cadPictBox.ClientRectangle.Width - Me.curClRect.Width) / 2)
        Me.pos.Y = ((Me.cadPictBox.ClientRectangle.Height - Me.curClRect.Height) / 2)
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ReOpen()
        If ((Not Me.openFileDlg.FileName Is Nothing) AndAlso File.Exists(Me.openFileDlg.FileName)) Then
            Me.LoadFile(False)
        End If
    End Sub

    Public Sub SaveAsImage()
        If ((Not Me.FCADImage Is Nothing) AndAlso (Me.saveImgDlg.ShowDialog = DialogResult.OK)) Then
            If (Not Me.saveImgDlg.FileName Is Nothing) Then
                Dim tmpRect As DRect = New DRect(0, 0, curClRect.Width * scl, curClRect.Height * scl)
                Dim tmp As String = Me.saveImgDlg.FileName
                Dim imgFrm As ImageFormat = ImageFormat.Bmp
                If (tmp.ToUpper().IndexOf(".JPG") <> -1) Then _
                    imgFrm = ImageFormat.Jpeg
                If (tmp.ToUpper().IndexOf(".BMP") <> -1) Then _
                    imgFrm = ImageFormat.Bmp
                If (tmp.ToUpper().IndexOf(".TIFF") <> -1) Then _
                    imgFrm = ImageFormat.Tiff
                If (tmp.ToUpper().IndexOf(".GIF") <> -1) Then _
                 imgFrm = ImageFormat.Gif
                If (tmp.ToUpper().IndexOf(".EMF") <> -1) Then _
                 imgFrm = ImageFormat.Emf
                If (tmp.ToUpper().IndexOf(".DXF") <> -1) Then
                    SaveAsDXF(saveImgDlg.FileName)
                    Return
                End If
                If (Me.clipRectangle.Enabled) Then
                    tmpRect = New DRect(pos.X, pos.Y, curClRect.Width * scl, curClRect.Height * scl)
                    FCADImage.SaveToFile(saveImgDlg.FileName, imgFrm, tmpRect, Me.clipRectangle.ClientRectangle)
                Else
                    If (imgFrm.Equals(ImageFormat.Emf)) Then
                        FCADImage.ExportToMetafile(saveImgDlg.FileName, Me.ActiveForm, tmpRect)
                    Else
                        FCADImage.SaveToFile(saveImgDlg.FileName, imgFrm, tmpRect)
                    End If
                End If
                If (Not Me.clipRectangle.Enabled) Then
                    Me.DoResize()
                End If
            End If
        End If
    End Sub

    Private Sub SetLayList()
        If ((Me.lForm.lstViewLay.Items.Count = 0) AndAlso (Not Me.FCADImage Is Nothing)) Then
            ObjEntity.layersList = New String(Me.FCADImage.LayersCount - 1) {}
            Dim bitmap1 As New Bitmap(32, 16)
            Me.lForm.imgColor.Images.Clear()
            Me.lForm.listColor.Items.Clear()
            Dim num1 As Integer = 0
            Do While (num1 < Me.FCADImage.LayersCount)
                Dim text1 As String = Me.FCADImage.GetLayerName(num1)
                ObjEntity.layersList(num1) = text1
                Me.lForm.lstViewLay.Items.Add(New ListViewItem(New String() {text1}))
                Me.lForm.lstViewLay.Items.Item(num1).Checked = Me.FCADImage.GetLayerVisible(num1)
                Try
                    Dim color1 As Color = FCADImage.GetLayerColor(num1)
                    Dim graphics1 As Graphics = Graphics.FromImage(bitmap1)
                    graphics1.FillRectangle(New SolidBrush(color1), 0, 0, 16, 16)
                    graphics1.DrawRectangle(New Pen(Brushes.Black, 1.2!), 0, 0, 15, 15)
                    Me.lForm.imgColor.Images.Add(DirectCast(bitmap1.Clone, Bitmap))
                    Me.lForm.listColor.Items.Add(New ListViewItem(New String() {String.Empty}))
                    Me.lForm.listColor.Items.Item(num1).ImageIndex = num1
                Catch exception1 As Exception
                    MessageBox.Show((exception1.Message & " - " & exception1.StackTrace))
                End Try
                num1 += 1
            Loop
            Dim num2 As Integer = ((Me.lForm.imgColor.Images.Count * 18) + 18)
            Me.lForm.listColor.Height = num2
            Me.lForm.listColor.Top = 0
            Me.lForm.lstViewLay.Height = num2
            Me.lForm.lstViewLay.Top = 0
            AddHandler Me.lForm.lstViewLay.ItemCheck, Me.dl1
        End If
    End Sub

    Public Sub Shift()
        Me.pos.X = (Me.old_Pos.X - (((Me.old_Pos.X - Me.pos.X) * Me.scl) / Me.prev_scale))
        Me.pos.Y = (Me.old_Pos.Y - (((Me.old_Pos.Y - Me.pos.Y) * Me.scl) / Me.prev_scale))
        Me.prev_scale = Me.scl
    End Sub

    Public Sub UseWinEllipse()
        Me.FCADImage.UseWinEllipse = Not Me.FCADImage.UseWinEllipse
        Me.arcsSplitMenuItem.Checked = Not Me.FCADImage.UseWinEllipse
        Me.tlbTool.Buttons.Item(9).Pushed = Not Me.FCADImage.UseWinEllipse
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub ViewLayouts()
        If (Not Me.FCADImage Is Nothing) Then
            Me.cbLayouts.Items.Clear()
            Dim num1 As Integer = 0
            Do While (num1 < Me.FCADImage.LayoutsCount)
                Me.cbLayouts.Items.Add(Me.FCADImage.GetLayoutName(num1))
                num1 += 1
            Loop
            Me.cbLayouts.SelectedIndex = Me.FCADImage.DefaultLayoutIndex
            Me.FCADImage.SetCurrentLayout(Me.cbLayouts.SelectedIndex)
            Me.pnlLayouts.Visible = True
        End If
    End Sub

    Public Sub White_Click()
        Me.whiteBackMenuItem.Checked = True
        Me.blackBackMenuItem.Checked = False
        Me.tlbTool.Buttons.Item(4).Pushed = True
        Me.tlbTool.Buttons.Item(5).Pushed = False
        Me.cadPictBox.BackColor = Color.White
        Me.trvEntity.BackColor = Color.White
        Me.trvEntity.ForeColor = Color.Black
        If (Not Me.FCADImage Is Nothing) Then
            Me.FCADImage.DefaultColor = Color.Black
        End If
        If (Not Me.clipRectangle Is Nothing) Then
            Me.clipRectangle.Color = Color.Black
        End If
    End Sub

    Private Sub whiteBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles whiteBackMenuItem.Click
        Me.White_Click()
    End Sub

    Public Sub trvEntity_AfterCheck(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvEntity.AfterCheck
        CADImportFace.DoCheckTreeNode(Me.FCADImage, Me.trvEntity.Nodes, e.Node)
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub TopViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TopViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Top)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub toolMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles topMenuItem.Click
#If protect Then
        Me.regFrm.ShowDialog()
#End If
    End Sub

    Public Sub tlbTool_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbTool.ButtonClick
        If ((Not Me.FCADImage Is Nothing) OrElse (Me.tlbTool.Buttons.IndexOf(e.Button) <> 8)) Then
            Select Case Me.tlbTool.Buttons.IndexOf(e.Button)
                Case 0
                    Me.LoadFile(True)
                    Return
                Case 1
                    Me.DoZoomIn()
                    Return
                Case 2
                    Me.DoZoomOut()
                    Return
                Case 3
                    Me.SaveAsImage()
                    Return
                Case 4
                    Me.White_Click()
                    Return
                Case 5
                    Me.Black_Click()
                    Return
                Case 6
                    Me.Color_Click()
                    Return
                Case 7
                    Me.Go3dOrbit(Not Me.Orb3D.Visible)
                    Return
                Case 8
                    Me.SetLayList()
                    Me.lForm.ShowDialog()
                    Return
                Case 9
                    Me.UseWinEllipse()
                    Return
                Case 10
                    Me.DoBlackColor()
                    Return
                Case 11
                    Me.DoNormalColor()
                    Return
                Case 12
                    Me.ResetScaling()
                    Return
                Case 13
                    Me.ChangeTextsVisiblity()
                    Return
                Case 14
                    Me.ChangeDimensionsVisiblity()
                    Return
                Case 15
                    PutToClipboard()
                    Return
                Case 16
                    Me.FCADImage.Print(True, True)
                    Return
                Case 17
                    ChangeTypeFont()
                    Return
                Case 18
                    DoEnableRectangle(Not Me.clipRectangle.Enabled)
                    Return
                Case 19
                    tlbTool.Buttons(19).Pushed = Not tlbTool.Buttons(19).Pushed
                    Me.ChangeSelectionCond(tlbTool.Buttons(19).Pushed)
                    Return
            End Select
        End If
    End Sub

    Private Sub ChangeSelectionCond(ByVal val As Boolean)
        If val Then
            CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Enabled
        Else
            CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Disabled
        End If
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub PutToClipboard()
        If (Me.clipRectangle.Enabled) Then
            Dim tmpRect As DRect = New DRect(pos.X, pos.Y, curClRect.Width * scl, curClRect.Height * scl)
            FCADImage.SaveImageToClipboard(tmpRect, Me.clipRectangle.ClientRectangle)
        Else
            Dim tmp As DRect = New DRect(0, 0, curClRect.Width * scl, curClRect.Height * scl)
            FCADImage.SaveImageToClipboard(tmp)
        End If
    End Sub

    Public Sub ChangeTypeFont()
        tlbTool.Buttons(17).Pushed = Not tlbTool.Buttons(17).Pushed
        CADConst.UseSHXFonts = tlbTool.Buttons(17).Pushed
        If (CADConst.UseSHXFonts) Then
            DoSHXFonts()
        Else
            DoTTFFonts()
        End If
        ReOpen()
    End Sub

    Private Sub DoTTFFonts()
        CADConst.UseTTFFonts = True
        CADConst.UseMultyTTFFonts = True
    End Sub

    Private Sub DoSHXFonts()
        CADConst.UseTTFFonts = False
        CADConst.UseMultyTTFFonts = False
    End Sub

    Private Sub DoEnableRectangle(ByVal val As Boolean)
        If (val) Then
            Go3dOrbit(False)
            Me.clipRectangle.Color = FCADImage.DefaultColor
            Me.clipRectangle.EnableRect(RectangleType.Selecting)
        Else : Me.clipRectangle.DisableRect()
        End If
        tlbTool.Buttons(18).Pushed = val
    End Sub

    Private Sub textsShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textsShowMenuItem.Click
        Me.ChangeTextsVisiblity()
    End Sub

    Public Sub SWViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SWViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.SWIsometric)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub shxMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shxMenuItem.Click
        Me.AddSHXPaths()
    End Sub

    Private Sub showLineWeightMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles showLineWeightMenuItem.Click
        Me.ChangeShowLineWeight()
    End Sub

    Public Sub SEViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.SEIsometric)
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub RightViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Right)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub printMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printMenuItem.Click
        Me.FCADImage.Print(True, True)
    End Sub

    Private Sub orbitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles orbitMenuItem.Click
        Me.Go3dOrbit(Not Me.Orb3D.Visible)
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mOpenFile.Click
        Me.LoadFile(True)
    End Sub

    Public Sub NWViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NWViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.NWIsometric)
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub NEViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NEViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.NEIsometric)
        Me.cadPictBox.Invalidate()
    End Sub

    Public Sub menuItemZoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoom10MenuItem.Click, _
        zoom25MenuItem.Click, zoom50MenuItem.Click, zoom100MenuItem.Click, zoom200MenuItem.Click, zoom400MenuItem.Click, zoom400MenuItem.Click
        If (Not Me.FCADImage Is Nothing) Then
            Dim single1 As Single = Me.scl
            Select Case CType(sender, MenuItem).Index
                Case 0
                    single1 = 0.1!
                Case 1
                    single1 = 0.25!
                Case 2
                    single1 = 0.5!
                Case 3
                    single1 = 1.0!
                Case 4
                    single1 = 2.0!
                Case 5
                    single1 = 4.0!
                Case 6
                    single1 = 8.0!
            End Select
            Me.ResetScaling()
            Me.old_Pos = New PointF(CType((Me.cadPictBox.ClientRectangle.Width / 2), Single), CType((Me.cadPictBox.ClientRectangle.Height / 2), Single))
            Me.scl = single1
            Me.cadPictBox.Invalidate()
            Me.stBar.Panels.Item(1).Text = ("" & Me.scl)
        End If
    End Sub

    Private Sub exitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mExit.Click
        MyBase.Close()
    End Sub

    Public Sub LeftViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LeftViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Left)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub layersShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles layersShowMenuItem.Click
        Me.SetLayList()
        Me.lForm.ShowDialog()
    End Sub

    Public Sub InitialViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InitialViewMenuItem.Click
        Me.FCADImage.RotDefault()
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub ImgSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mSaveFile.Click
        Me.SaveAsImage()
    End Sub

    Public Sub FrontViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrontViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Front)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub fitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fitMenuItem.Click
        Me.ResetScaling()
    End Sub

    Private Sub entitiesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles entitiesMenuItem.Click
        Me.ChangeTreeVisiblity()
    End Sub

    Private Sub dimShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dimShowMenuItem.Click
        Me.ChangeDimensionsVisiblity()
    End Sub

    Private Sub copyMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles copyMenuItem.Click
        Dim tmpRect As DRect = New DRect(0, 0, curClRect.Width * scl, curClRect.Height * scl)
        Me.FCADImage.SaveImageToClipboard(tmpRect)
    End Sub

    Private Sub colorMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles colorMenuItem.Click
        Me.DoNormalColor()
    End Sub

    Private Sub closeMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeMenuItem.Click
        Me.CloseFile()
    End Sub

    Private Sub changeBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles changeBackMenuItem.Click
        Me.Color_Click()
    End Sub

    Private Sub cbLayouts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbLayouts.SelectedIndexChanged
        Me.ChangeCurrLayoutIndex()
    End Sub

    Private Sub cadPictBox_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles cadPictBox.Paint
        Me.DrawCADImage(e.Graphics)
    End Sub

    Public Sub BottomViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BottomViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Bottom)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub blackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blackMenuItem.Click
        Me.DoBlackColor()
    End Sub

    Private Sub blackBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blackBackMenuItem.Click
        Me.Black_Click()
    End Sub

    Public Sub BackViewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackViewMenuItem.Click
        Me.FCADImage.RotToView(CADViewDirection.Back)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub arcsSplitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles arcsSplitMenuItem.Click
        Me.UseWinEllipse()
    End Sub

    Private Sub aboutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles aboutMenuItem.Click
        Me.aboutFrm.ShowDialog()
    End Sub

    Private Sub MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        CreateNewSettingsList()
        svSet.SaveOptions(settingsLst)
#If protect Then
#If floatprotect Then
        If (Protection.LicenseType = LicenseType.Floating) Then
            Me.floatLicFrm.DisableFloating()
        Else

            Protection.CloseApplication()
        End If
#Else
        Protection.CloseApplication()
#End If
#End If
    End Sub

    Private Sub MainForm_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Deactivate
        Me.det1 = False
    End Sub

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Save value of NoName elements
        If Not (Me.mainMenu Is Nothing) Then mlng.SaveNameMenuItem(Me.mainMenu.MenuItems)
        If Not (Me.ContextMenu Is Nothing) Then mlng.SaveNameMenuItem(Me.ContextMenu.MenuItems)
        mlng.SaveNameNoNameElement(Me.Controls)
        'Load settings
        svSet = New SaveSettings(Me.fileSettingsName)
        settingsLst = svSet.LoadOptions()

        If Not (settingsLst Is Nothing) Then
            Dim key As String = "LanguagePath"
            If (settingsLst.ContainsKey(key)) Then MultipleLanguage.path = Convert.ToString(settingsLst(key))
        Else
            MultipleLanguage.path = cnstLngPath
        End If
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), New System.EventHandler(AddressOf LanguageSelect_Click))

        If (settingsLst Is Nothing) Then
            CreateNewSettingsList()
        Else
            SetSettings()
        End If

        Me.wh = 1.0!
        Me.curClRect = Me.cadPictBox.ClientRectangle
        dl1 = New System.Windows.Forms.ItemCheckEventHandler(AddressOf chLay_ItemCheck)
#If protect Then
#If floatprotect Then
        If (Protection.LicenseType = LicenseType.Floating) Then
            Me.floatLicFrm.FloatingLicRegister()
        Else
            Protection.Register()
        End If
#Else
        Protection.Register()
#End If
#End If
        clipRectangle = New ClipRect(Me.cadPictBox)
        CADImportFace.EntityPropertyGrid = Me.propGrid
    End Sub

    Private Sub MainForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.DoResize()
    End Sub

    Private Sub ZoomIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoomInMenuItem.Click
        Me.DoZoomIn()
    End Sub

    Private Sub ZoomOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoomOutMenuItem.Click
        Me.DoZoomOut()
    End Sub

    Private Sub splitter1_SplitterMoved(ByVal sender As Object, ByVal e As System.Windows.Forms.SplitterEventArgs) Handles splitter1.SplitterMoved
        Me.DoResize()
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub SetLNG()
        mlng.LoadLNG(lngFile)
        mlng.RestoreLanguage(Me.Controls, Me.Menu)

        Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems.Clear()
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), New System.EventHandler(AddressOf LanguageSelect_Click))
        If (Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems.Count > Me.curLngInd) Then
            Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems(Me.curLngInd).Checked = True
        End If

        Me.Text = "CADImport.Net Demo"
        Me.Text = mlng.SetLanguage(Me.Controls, Me.Menu, Me.Text)
    End Sub

    'set loads settings
    Friend Sub SetSettings()
        If (Not MainForm.settingsLst Is Nothing) Then
            Dim num1 As Integer = 0
            Dim text2 As String = "LanguagePath"
            If MainForm.settingsLst.ContainsKey(text2) Then
                MultipleLanguage.path = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            text2 = "Language"
            If MainForm.settingsLst.ContainsKey(text2) Then
                MainForm.lngFile = CType(MainForm.settingsLst.Item(text2), String)
            End If
            Me.mlng.LoadLNG(MainForm.lngFile)
            Me.Text = Me.mlng.SetLanguage(MyBase.Controls, MyBase.Menu, Me.Text)
            text2 = "LanguageID"
            If MainForm.settingsLst.ContainsKey(text2) Then
                Me.curLngInd = Convert.ToByte(MainForm.settingsLst.Item(text2))
                If (Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Count > Me.curLngInd) Then
                    Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Item(Me.curLngInd).Checked = True
                End If
            End If
            text2 = "BackgroundColor"
            Dim text1 As String = "BLACK"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("BLACK")) Then
                Me.Black_Click()
            Else
                Me.White_Click()
            End If
            text2 = "ShowEntity"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.entitiesMenuItem.Checked = True
                Me.trvPanel.Visible = True
            Else
                Me.entitiesMenuItem.Checked = False
                Me.trvPanel.Visible = False
            End If
            text2 = "ColorDraw"
            If MainForm.settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(MainForm.settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.colorDraw = True
            Else
                Me.colorDraw = False
            End If
            text2 = "SHXPathCount"
            If MainForm.settingsLst.ContainsKey(text2) Then
                num1 = Convert.ToInt32(MainForm.settingsLst.Item(text2))
            End If
            Dim num2 As Integer = 0
            Do While (num2 < num1)
                text2 = ("SHXPath_" & (num2 + 1))
                If MainForm.settingsLst.ContainsKey(text2) Then
                    Me.shxFrm.AddPath(Convert.ToString(MainForm.settingsLst.Item(text2)))
                End If
                num2 += 1
            Loop
            'First start
            text2 = "Install"
            If (settingsLst.ContainsKey(text2)) Then
                If (CADConst.SearchSHXPaths) Then
                    Dim list1 As New ArrayList
                    CADConst.FindAutoCADSHXPaths(list1)
                    Dim num3 As Integer = 0
                    Do While (num3 < list1.Count)
                        text1 = CType(list1.Item(num3), String)
                        Me.shxFrm.lstDir.Items.Add(text1)
                        Me.shxFrm.lstPath.Add(text1, "")
                        CADConst.SHXSearchPaths = (CADConst.SHXSearchPaths & CADConst.SHXSearchPaths & text1 & ";")
                        num3 += 1
                    Loop
                End If
            End If
        End If

#If protect Then
        'License
        Dim key As String = "Type_license"
        Dim tmp As String
        If (settingsLst.ContainsKey(key)) Then
            tmp = settingsLst(key)
#If floatprotect Then
            If (tmp = "floating") Then
                Protection.LicenseType = LicenseType.Floating
                key = "Host"
                If (settingsLst.ContainsKey(key)) Then
                    Me.floatLicFrm.Host = settingsLst(key)
                End If
                key = "Port"
                If (settingsLst.ContainsKey(key)) Then
                    Me.floatLicFrm.Port = Convert.ToInt32(settingsLst(key))
                End If
                key = "Application"
                If (settingsLst.ContainsKey(key)) Then
                    Me.floatLicFrm.App = settingsLst(key)
                End If
            Else
                Protection.LicenseType = LicenseType.Register
            End If
#Else
            Protection.LicenseType = LicenseType.Register
#End If
        End If
#End If
    End Sub

    Private Sub InvalidateImage(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub CreateNewSettingsList()
        Dim text1 As String
        MainForm.settingsLst = New SortedList
        MainForm.settingsLst.Add("LanguagePath", MultipleLanguage.path)
        MainForm.settingsLst.Add("Language", MainForm.lngFile)
        MainForm.settingsLst.Add("LanguageID", Me.curLngInd)
        If (Me.cadPictBox.BackColor.Equals(Color.Black)) Then
            text1 = "Black"
        Else
            text1 = "White"
        End If
        MainForm.settingsLst.Add("BackgroundColor", text1)
        MainForm.settingsLst.Add("ShowEntity", Me.trvPanel.Visible)
        MainForm.settingsLst.Add("ColorDraw", Me.colorDraw)
        Dim num1 As Integer = Me.shxFrm.lstDir.Items.Count
        MainForm.settingsLst.Add("SHXPathCount", Me.shxFrm.lstDir.Items.Count)
        Dim num2 As Integer = 0
        Do While (num2 < num1)
            MainForm.settingsLst.Add(("SHXPath_" & (num2 + 1)), Me.shxFrm.lstDir.Items.Item(num2))
            num2 += 1
        Loop

#If protect Then
        'License
#If floatprotect Then
        If (Protection.LicenseType = LicenseType.Floating) Then
            settingsLst.Add("Type_license", "floating")
            settingsLst.Add("Host", Me.floatLicFrm.Host)
            settingsLst.Add("Port", Me.floatLicFrm.Port)
            settingsLst.Add("Application", Me.floatLicFrm.App)
        Else
            settingsLst.Add("Type license", "register")
        End If
#Else
        settingsLst.Add("Type license", "register")
#End If
#End If
    End Sub

    Private Sub LanguageSelect_Click(ByVal sender As Object, ByVal e As EventArgs)
        If TypeOf sender Is MenuItem Then
            Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Item(Me.curLngInd).Checked = False
            Dim item1 As MenuItem = CType(sender, MenuItem)
            Me.curLngInd = CType(item1.Index, Byte)
            MainForm.lngFile = (item1.Text & ".lng")
            item1.Checked = True
            Me.SetLNG()
        End If
    End Sub

    Private Sub Options_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim text1 As String = MultipleLanguage.path
        Me.CreateNewSettingsList()
        Me.optForm.ShowDialog()
        MultipleLanguage.lngList.Clear()
        Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Clear()
        Me.mlng.RestoreLanguage(MyBase.Controls, Me.mainMenu)
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), New System.EventHandler(AddressOf LanguageSelect_Click))
        Me.SetSettings()
        Me.ReOpen()
    End Sub

    Friend Sub ReloadLNG()
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), New System.EventHandler(AddressOf LanguageSelect_Click))
    End Sub

    Private Sub menuItemReg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItemReg.Click
#If protect Then
        regFrm.ShowDialog()
#End If
    End Sub

    Private Sub menuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItem3.Click
        'old lng files path
        Dim tmp As String = MultipleLanguage.path
        Dim blackcolor As Boolean = Me.colorDraw
        'create current options list
        CreateNewSettingsList()
        If (Me.optForm.ShowDialog() = DialogResult.Cancel) Then Return
        'clear current lists
        MultipleLanguage.lngList.Clear()
        Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems.Clear()
        'default language
        mlng.RestoreLanguage(Me.Controls, Me.mainMenu)
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), New System.EventHandler(AddressOf LanguageSelect_Click))
        'set new options
        SetSettings()
        'set colors draw
        If (Me.FCADImage Is Nothing) Then Return
        If (blackcolor <> Me.colorDraw) Then
            If (Me.colorDraw) Then
                DoNormalColor()
            Else
                Me.DoBlackColor()
            End If
        End If
    End Sub

    Private Sub printPrevItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPrevItem.Click
        printPrevDlg.Document = FCADImage.Print(False, False)
        printPrevDlg.ShowDialog()
        printPrevDlg.Document.Dispose()
    End Sub

    Private Sub print2Item_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles print2Item.Click
        prtForm.ShowDialog()
    End Sub

    Private Sub SaveAsDXF(ByVal fName As String)
        If ((Not Me.FCADImage Is Nothing) AndAlso Not TypeOf Me.FCADImage Is CADRasterImage) Then
            Dim odxf1 As New CADtoDXFModule.CADtoDXF(Me.FCADImage)
            odxf1.SaveToFile(fName)
        End If
    End Sub

    Private Sub mSaveAsDXF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mSaveAsDXF.Click
        If (Me.FCADImage Is Nothing) Then Return
        If (Me.saveDXFDlg.ShowDialog() <> DialogResult.OK) Then Return
        SaveAsDXF(Me.saveDXFDlg.FileName)
    End Sub

    Private Sub trvEntity_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvEntity.AfterSelect
        CADImportFace.DecodeEntity(e.Node, FCADImage, Me.cadPictBox, Me.scl)
    End Sub

    Private Sub propGrid_PropertyValueChanged(ByVal s As Object, ByVal e As System.Windows.Forms.PropertyValueChangedEventArgs) Handles propGrid.PropertyValueChanged
        Me.cadPictBox.Invalidate()
    End Sub

    Private Sub miFloatLic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miFloatLic.Click
#If floatprotect Then
        floatLicFrm.ShowDialog()
#End If
    End Sub
End Class
