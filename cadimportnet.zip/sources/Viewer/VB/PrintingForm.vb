Imports System.Drawing.Printing
Imports System.Drawing.Imaging
Imports CADImport
Imports CADImportFaceModule

Public Class PrintingForm
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tabCntrlPrint As System.Windows.Forms.TabControl
    Friend WithEvents tbPrintPage1 As System.Windows.Forms.TabPage
    Friend WithEvents printPrevCnt As System.Windows.Forms.PrintPreviewControl
    Friend WithEvents pnToolPrint As System.Windows.Forms.Panel
    Friend WithEvents lbScale As System.Windows.Forms.Label
    Friend WithEvents btnZoomOut As System.Windows.Forms.Button
    Friend WithEvents btnZoomIn As System.Windows.Forms.Button
    Friend WithEvents btnScale As System.Windows.Forms.Button
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents toolBtnImageList As System.Windows.Forms.ImageList
    Friend WithEvents printDlg As System.Windows.Forms.PrintDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(PrintingForm))
        Me.tabCntrlPrint = New System.Windows.Forms.TabControl
        Me.tbPrintPage1 = New System.Windows.Forms.TabPage
        Me.printPrevCnt = New System.Windows.Forms.PrintPreviewControl
        Me.pnToolPrint = New System.Windows.Forms.Panel
        Me.lbScale = New System.Windows.Forms.Label
        Me.btnZoomOut = New System.Windows.Forms.Button
        Me.toolBtnImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.btnZoomIn = New System.Windows.Forms.Button
        Me.btnScale = New System.Windows.Forms.Button
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.btnPrint = New System.Windows.Forms.Button
        Me.printDlg = New System.Windows.Forms.PrintDialog
        Me.tabCntrlPrint.SuspendLayout()
        Me.tbPrintPage1.SuspendLayout()
        Me.pnToolPrint.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabCntrlPrint
        '
        Me.tabCntrlPrint.AccessibleDescription = resources.GetString("tabCntrlPrint.AccessibleDescription")
        Me.tabCntrlPrint.AccessibleName = resources.GetString("tabCntrlPrint.AccessibleName")
        Me.tabCntrlPrint.Alignment = CType(resources.GetObject("tabCntrlPrint.Alignment"), System.Windows.Forms.TabAlignment)
        Me.tabCntrlPrint.Anchor = CType(resources.GetObject("tabCntrlPrint.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabCntrlPrint.Appearance = CType(resources.GetObject("tabCntrlPrint.Appearance"), System.Windows.Forms.TabAppearance)
        Me.tabCntrlPrint.BackgroundImage = CType(resources.GetObject("tabCntrlPrint.BackgroundImage"), System.Drawing.Image)
        Me.tabCntrlPrint.Controls.Add(Me.tbPrintPage1)
        Me.tabCntrlPrint.Dock = CType(resources.GetObject("tabCntrlPrint.Dock"), System.Windows.Forms.DockStyle)
        Me.tabCntrlPrint.Enabled = CType(resources.GetObject("tabCntrlPrint.Enabled"), Boolean)
        Me.tabCntrlPrint.Font = CType(resources.GetObject("tabCntrlPrint.Font"), System.Drawing.Font)
        Me.tabCntrlPrint.ImeMode = CType(resources.GetObject("tabCntrlPrint.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabCntrlPrint.ItemSize = CType(resources.GetObject("tabCntrlPrint.ItemSize"), System.Drawing.Size)
        Me.tabCntrlPrint.Location = CType(resources.GetObject("tabCntrlPrint.Location"), System.Drawing.Point)
        Me.tabCntrlPrint.Name = "tabCntrlPrint"
        Me.tabCntrlPrint.Padding = CType(resources.GetObject("tabCntrlPrint.Padding"), System.Drawing.Point)
        Me.tabCntrlPrint.RightToLeft = CType(resources.GetObject("tabCntrlPrint.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabCntrlPrint.SelectedIndex = 0
        Me.tabCntrlPrint.ShowToolTips = CType(resources.GetObject("tabCntrlPrint.ShowToolTips"), Boolean)
        Me.tabCntrlPrint.Size = CType(resources.GetObject("tabCntrlPrint.Size"), System.Drawing.Size)
        Me.tabCntrlPrint.TabIndex = CType(resources.GetObject("tabCntrlPrint.TabIndex"), Integer)
        Me.tabCntrlPrint.Text = resources.GetString("tabCntrlPrint.Text")
        Me.tabCntrlPrint.Visible = CType(resources.GetObject("tabCntrlPrint.Visible"), Boolean)
        '
        'tbPrintPage1
        '
        Me.tbPrintPage1.AccessibleDescription = resources.GetString("tbPrintPage1.AccessibleDescription")
        Me.tbPrintPage1.AccessibleName = resources.GetString("tbPrintPage1.AccessibleName")
        Me.tbPrintPage1.Anchor = CType(resources.GetObject("tbPrintPage1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tbPrintPage1.AutoScroll = CType(resources.GetObject("tbPrintPage1.AutoScroll"), Boolean)
        Me.tbPrintPage1.AutoScrollMargin = CType(resources.GetObject("tbPrintPage1.AutoScrollMargin"), System.Drawing.Size)
        Me.tbPrintPage1.AutoScrollMinSize = CType(resources.GetObject("tbPrintPage1.AutoScrollMinSize"), System.Drawing.Size)
        Me.tbPrintPage1.BackgroundImage = CType(resources.GetObject("tbPrintPage1.BackgroundImage"), System.Drawing.Image)
        Me.tbPrintPage1.Controls.Add(Me.printPrevCnt)
        Me.tbPrintPage1.Controls.Add(Me.pnToolPrint)
        Me.tbPrintPage1.Dock = CType(resources.GetObject("tbPrintPage1.Dock"), System.Windows.Forms.DockStyle)
        Me.tbPrintPage1.Enabled = CType(resources.GetObject("tbPrintPage1.Enabled"), Boolean)
        Me.tbPrintPage1.Font = CType(resources.GetObject("tbPrintPage1.Font"), System.Drawing.Font)
        Me.tbPrintPage1.ImageIndex = CType(resources.GetObject("tbPrintPage1.ImageIndex"), Integer)
        Me.tbPrintPage1.ImeMode = CType(resources.GetObject("tbPrintPage1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tbPrintPage1.Location = CType(resources.GetObject("tbPrintPage1.Location"), System.Drawing.Point)
        Me.tbPrintPage1.Name = "tbPrintPage1"
        Me.tbPrintPage1.RightToLeft = CType(resources.GetObject("tbPrintPage1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tbPrintPage1.Size = CType(resources.GetObject("tbPrintPage1.Size"), System.Drawing.Size)
        Me.tbPrintPage1.TabIndex = CType(resources.GetObject("tbPrintPage1.TabIndex"), Integer)
        Me.tbPrintPage1.Text = resources.GetString("tbPrintPage1.Text")
        Me.tbPrintPage1.ToolTipText = resources.GetString("tbPrintPage1.ToolTipText")
        Me.tbPrintPage1.Visible = CType(resources.GetObject("tbPrintPage1.Visible"), Boolean)
        '
        'printPrevCnt
        '
        Me.printPrevCnt.AccessibleDescription = resources.GetString("printPrevCnt.AccessibleDescription")
        Me.printPrevCnt.AccessibleName = resources.GetString("printPrevCnt.AccessibleName")
        Me.printPrevCnt.Anchor = CType(resources.GetObject("printPrevCnt.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.printPrevCnt.AutoZoom = False
        Me.printPrevCnt.BackgroundImage = CType(resources.GetObject("printPrevCnt.BackgroundImage"), System.Drawing.Image)
        Me.printPrevCnt.Dock = CType(resources.GetObject("printPrevCnt.Dock"), System.Windows.Forms.DockStyle)
        Me.printPrevCnt.Enabled = CType(resources.GetObject("printPrevCnt.Enabled"), Boolean)
        Me.printPrevCnt.Font = CType(resources.GetObject("printPrevCnt.Font"), System.Drawing.Font)
        Me.printPrevCnt.ImeMode = CType(resources.GetObject("printPrevCnt.ImeMode"), System.Windows.Forms.ImeMode)
        Me.printPrevCnt.Location = CType(resources.GetObject("printPrevCnt.Location"), System.Drawing.Point)
        Me.printPrevCnt.Name = "printPrevCnt"
        Me.printPrevCnt.RightToLeft = CType(resources.GetObject("printPrevCnt.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.printPrevCnt.Size = CType(resources.GetObject("printPrevCnt.Size"), System.Drawing.Size)
        Me.printPrevCnt.TabIndex = CType(resources.GetObject("printPrevCnt.TabIndex"), Integer)
        Me.printPrevCnt.Visible = CType(resources.GetObject("printPrevCnt.Visible"), Boolean)
        Me.printPrevCnt.Zoom = 0.3
        '
        'pnToolPrint
        '
        Me.pnToolPrint.AccessibleDescription = resources.GetString("pnToolPrint.AccessibleDescription")
        Me.pnToolPrint.AccessibleName = resources.GetString("pnToolPrint.AccessibleName")
        Me.pnToolPrint.Anchor = CType(resources.GetObject("pnToolPrint.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.pnToolPrint.AutoScroll = CType(resources.GetObject("pnToolPrint.AutoScroll"), Boolean)
        Me.pnToolPrint.AutoScrollMargin = CType(resources.GetObject("pnToolPrint.AutoScrollMargin"), System.Drawing.Size)
        Me.pnToolPrint.AutoScrollMinSize = CType(resources.GetObject("pnToolPrint.AutoScrollMinSize"), System.Drawing.Size)
        Me.pnToolPrint.BackgroundImage = CType(resources.GetObject("pnToolPrint.BackgroundImage"), System.Drawing.Image)
        Me.pnToolPrint.Controls.Add(Me.lbScale)
        Me.pnToolPrint.Controls.Add(Me.btnZoomOut)
        Me.pnToolPrint.Controls.Add(Me.btnZoomIn)
        Me.pnToolPrint.Controls.Add(Me.btnScale)
        Me.pnToolPrint.Controls.Add(Me.textBox1)
        Me.pnToolPrint.Controls.Add(Me.btnPrint)
        Me.pnToolPrint.Dock = CType(resources.GetObject("pnToolPrint.Dock"), System.Windows.Forms.DockStyle)
        Me.pnToolPrint.Enabled = CType(resources.GetObject("pnToolPrint.Enabled"), Boolean)
        Me.pnToolPrint.Font = CType(resources.GetObject("pnToolPrint.Font"), System.Drawing.Font)
        Me.pnToolPrint.ImeMode = CType(resources.GetObject("pnToolPrint.ImeMode"), System.Windows.Forms.ImeMode)
        Me.pnToolPrint.Location = CType(resources.GetObject("pnToolPrint.Location"), System.Drawing.Point)
        Me.pnToolPrint.Name = "pnToolPrint"
        Me.pnToolPrint.RightToLeft = CType(resources.GetObject("pnToolPrint.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.pnToolPrint.Size = CType(resources.GetObject("pnToolPrint.Size"), System.Drawing.Size)
        Me.pnToolPrint.TabIndex = CType(resources.GetObject("pnToolPrint.TabIndex"), Integer)
        Me.pnToolPrint.Text = resources.GetString("pnToolPrint.Text")
        Me.pnToolPrint.Visible = CType(resources.GetObject("pnToolPrint.Visible"), Boolean)
        '
        'lbScale
        '
        Me.lbScale.AccessibleDescription = resources.GetString("lbScale.AccessibleDescription")
        Me.lbScale.AccessibleName = resources.GetString("lbScale.AccessibleName")
        Me.lbScale.Anchor = CType(resources.GetObject("lbScale.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.lbScale.AutoSize = CType(resources.GetObject("lbScale.AutoSize"), Boolean)
        Me.lbScale.Dock = CType(resources.GetObject("lbScale.Dock"), System.Windows.Forms.DockStyle)
        Me.lbScale.Enabled = CType(resources.GetObject("lbScale.Enabled"), Boolean)
        Me.lbScale.Font = CType(resources.GetObject("lbScale.Font"), System.Drawing.Font)
        Me.lbScale.Image = CType(resources.GetObject("lbScale.Image"), System.Drawing.Image)
        Me.lbScale.ImageAlign = CType(resources.GetObject("lbScale.ImageAlign"), System.Drawing.ContentAlignment)
        Me.lbScale.ImageIndex = CType(resources.GetObject("lbScale.ImageIndex"), Integer)
        Me.lbScale.ImeMode = CType(resources.GetObject("lbScale.ImeMode"), System.Windows.Forms.ImeMode)
        Me.lbScale.Location = CType(resources.GetObject("lbScale.Location"), System.Drawing.Point)
        Me.lbScale.Name = "lbScale"
        Me.lbScale.RightToLeft = CType(resources.GetObject("lbScale.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.lbScale.Size = CType(resources.GetObject("lbScale.Size"), System.Drawing.Size)
        Me.lbScale.TabIndex = CType(resources.GetObject("lbScale.TabIndex"), Integer)
        Me.lbScale.Text = resources.GetString("lbScale.Text")
        Me.lbScale.TextAlign = CType(resources.GetObject("lbScale.TextAlign"), System.Drawing.ContentAlignment)
        Me.lbScale.Visible = CType(resources.GetObject("lbScale.Visible"), Boolean)
        '
        'btnZoomOut
        '
        Me.btnZoomOut.AccessibleDescription = resources.GetString("btnZoomOut.AccessibleDescription")
        Me.btnZoomOut.AccessibleName = resources.GetString("btnZoomOut.AccessibleName")
        Me.btnZoomOut.Anchor = CType(resources.GetObject("btnZoomOut.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btnZoomOut.BackgroundImage = CType(resources.GetObject("btnZoomOut.BackgroundImage"), System.Drawing.Image)
        Me.btnZoomOut.Dock = CType(resources.GetObject("btnZoomOut.Dock"), System.Windows.Forms.DockStyle)
        Me.btnZoomOut.Enabled = CType(resources.GetObject("btnZoomOut.Enabled"), Boolean)
        Me.btnZoomOut.FlatStyle = CType(resources.GetObject("btnZoomOut.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btnZoomOut.Font = CType(resources.GetObject("btnZoomOut.Font"), System.Drawing.Font)
        Me.btnZoomOut.Image = CType(resources.GetObject("btnZoomOut.Image"), System.Drawing.Image)
        Me.btnZoomOut.ImageAlign = CType(resources.GetObject("btnZoomOut.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btnZoomOut.ImageIndex = CType(resources.GetObject("btnZoomOut.ImageIndex"), Integer)
        Me.btnZoomOut.ImageList = Me.toolBtnImageList
        Me.btnZoomOut.ImeMode = CType(resources.GetObject("btnZoomOut.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btnZoomOut.Location = CType(resources.GetObject("btnZoomOut.Location"), System.Drawing.Point)
        Me.btnZoomOut.Name = "btnZoomOut"
        Me.btnZoomOut.RightToLeft = CType(resources.GetObject("btnZoomOut.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btnZoomOut.Size = CType(resources.GetObject("btnZoomOut.Size"), System.Drawing.Size)
        Me.btnZoomOut.TabIndex = CType(resources.GetObject("btnZoomOut.TabIndex"), Integer)
        Me.btnZoomOut.Text = resources.GetString("btnZoomOut.Text")
        Me.btnZoomOut.TextAlign = CType(resources.GetObject("btnZoomOut.TextAlign"), System.Drawing.ContentAlignment)
        Me.btnZoomOut.Visible = CType(resources.GetObject("btnZoomOut.Visible"), Boolean)
        '
        'toolBtnImageList
        '
        Me.toolBtnImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.toolBtnImageList.ImageSize = CType(resources.GetObject("toolBtnImageList.ImageSize"), System.Drawing.Size)
        Me.toolBtnImageList.ImageStream = CType(resources.GetObject("toolBtnImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.toolBtnImageList.TransparentColor = System.Drawing.Color.White
        '
        'btnZoomIn
        '
        Me.btnZoomIn.AccessibleDescription = resources.GetString("btnZoomIn.AccessibleDescription")
        Me.btnZoomIn.AccessibleName = resources.GetString("btnZoomIn.AccessibleName")
        Me.btnZoomIn.Anchor = CType(resources.GetObject("btnZoomIn.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btnZoomIn.BackgroundImage = CType(resources.GetObject("btnZoomIn.BackgroundImage"), System.Drawing.Image)
        Me.btnZoomIn.Dock = CType(resources.GetObject("btnZoomIn.Dock"), System.Windows.Forms.DockStyle)
        Me.btnZoomIn.Enabled = CType(resources.GetObject("btnZoomIn.Enabled"), Boolean)
        Me.btnZoomIn.FlatStyle = CType(resources.GetObject("btnZoomIn.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btnZoomIn.Font = CType(resources.GetObject("btnZoomIn.Font"), System.Drawing.Font)
        Me.btnZoomIn.Image = CType(resources.GetObject("btnZoomIn.Image"), System.Drawing.Image)
        Me.btnZoomIn.ImageAlign = CType(resources.GetObject("btnZoomIn.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btnZoomIn.ImageIndex = CType(resources.GetObject("btnZoomIn.ImageIndex"), Integer)
        Me.btnZoomIn.ImageList = Me.toolBtnImageList
        Me.btnZoomIn.ImeMode = CType(resources.GetObject("btnZoomIn.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btnZoomIn.Location = CType(resources.GetObject("btnZoomIn.Location"), System.Drawing.Point)
        Me.btnZoomIn.Name = "btnZoomIn"
        Me.btnZoomIn.RightToLeft = CType(resources.GetObject("btnZoomIn.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btnZoomIn.Size = CType(resources.GetObject("btnZoomIn.Size"), System.Drawing.Size)
        Me.btnZoomIn.TabIndex = CType(resources.GetObject("btnZoomIn.TabIndex"), Integer)
        Me.btnZoomIn.Text = resources.GetString("btnZoomIn.Text")
        Me.btnZoomIn.TextAlign = CType(resources.GetObject("btnZoomIn.TextAlign"), System.Drawing.ContentAlignment)
        Me.btnZoomIn.Visible = CType(resources.GetObject("btnZoomIn.Visible"), Boolean)
        '
        'btnScale
        '
        Me.btnScale.AccessibleDescription = resources.GetString("btnScale.AccessibleDescription")
        Me.btnScale.AccessibleName = resources.GetString("btnScale.AccessibleName")
        Me.btnScale.Anchor = CType(resources.GetObject("btnScale.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btnScale.BackgroundImage = CType(resources.GetObject("btnScale.BackgroundImage"), System.Drawing.Image)
        Me.btnScale.Dock = CType(resources.GetObject("btnScale.Dock"), System.Windows.Forms.DockStyle)
        Me.btnScale.Enabled = CType(resources.GetObject("btnScale.Enabled"), Boolean)
        Me.btnScale.FlatStyle = CType(resources.GetObject("btnScale.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btnScale.Font = CType(resources.GetObject("btnScale.Font"), System.Drawing.Font)
        Me.btnScale.Image = CType(resources.GetObject("btnScale.Image"), System.Drawing.Image)
        Me.btnScale.ImageAlign = CType(resources.GetObject("btnScale.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btnScale.ImageIndex = CType(resources.GetObject("btnScale.ImageIndex"), Integer)
        Me.btnScale.ImeMode = CType(resources.GetObject("btnScale.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btnScale.Location = CType(resources.GetObject("btnScale.Location"), System.Drawing.Point)
        Me.btnScale.Name = "btnScale"
        Me.btnScale.RightToLeft = CType(resources.GetObject("btnScale.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btnScale.Size = CType(resources.GetObject("btnScale.Size"), System.Drawing.Size)
        Me.btnScale.TabIndex = CType(resources.GetObject("btnScale.TabIndex"), Integer)
        Me.btnScale.Text = resources.GetString("btnScale.Text")
        Me.btnScale.TextAlign = CType(resources.GetObject("btnScale.TextAlign"), System.Drawing.ContentAlignment)
        Me.btnScale.Visible = CType(resources.GetObject("btnScale.Visible"), Boolean)
        '
        'textBox1
        '
        Me.textBox1.AccessibleDescription = resources.GetString("textBox1.AccessibleDescription")
        Me.textBox1.AccessibleName = resources.GetString("textBox1.AccessibleName")
        Me.textBox1.Anchor = CType(resources.GetObject("textBox1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.textBox1.AutoSize = CType(resources.GetObject("textBox1.AutoSize"), Boolean)
        Me.textBox1.BackgroundImage = CType(resources.GetObject("textBox1.BackgroundImage"), System.Drawing.Image)
        Me.textBox1.Dock = CType(resources.GetObject("textBox1.Dock"), System.Windows.Forms.DockStyle)
        Me.textBox1.Enabled = CType(resources.GetObject("textBox1.Enabled"), Boolean)
        Me.textBox1.Font = CType(resources.GetObject("textBox1.Font"), System.Drawing.Font)
        Me.textBox1.ImeMode = CType(resources.GetObject("textBox1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.textBox1.Location = CType(resources.GetObject("textBox1.Location"), System.Drawing.Point)
        Me.textBox1.MaxLength = CType(resources.GetObject("textBox1.MaxLength"), Integer)
        Me.textBox1.Multiline = CType(resources.GetObject("textBox1.Multiline"), Boolean)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.PasswordChar = CType(resources.GetObject("textBox1.PasswordChar"), Char)
        Me.textBox1.RightToLeft = CType(resources.GetObject("textBox1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.textBox1.ScrollBars = CType(resources.GetObject("textBox1.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.textBox1.Size = CType(resources.GetObject("textBox1.Size"), System.Drawing.Size)
        Me.textBox1.TabIndex = CType(resources.GetObject("textBox1.TabIndex"), Integer)
        Me.textBox1.Text = resources.GetString("textBox1.Text")
        Me.textBox1.TextAlign = CType(resources.GetObject("textBox1.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.textBox1.Visible = CType(resources.GetObject("textBox1.Visible"), Boolean)
        Me.textBox1.WordWrap = CType(resources.GetObject("textBox1.WordWrap"), Boolean)
        '
        'btnPrint
        '
        Me.btnPrint.AccessibleDescription = resources.GetString("btnPrint.AccessibleDescription")
        Me.btnPrint.AccessibleName = resources.GetString("btnPrint.AccessibleName")
        Me.btnPrint.Anchor = CType(resources.GetObject("btnPrint.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackgroundImage = CType(resources.GetObject("btnPrint.BackgroundImage"), System.Drawing.Image)
        Me.btnPrint.Dock = CType(resources.GetObject("btnPrint.Dock"), System.Windows.Forms.DockStyle)
        Me.btnPrint.Enabled = CType(resources.GetObject("btnPrint.Enabled"), Boolean)
        Me.btnPrint.FlatStyle = CType(resources.GetObject("btnPrint.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.btnPrint.Font = CType(resources.GetObject("btnPrint.Font"), System.Drawing.Font)
        Me.btnPrint.Image = CType(resources.GetObject("btnPrint.Image"), System.Drawing.Image)
        Me.btnPrint.ImageAlign = CType(resources.GetObject("btnPrint.ImageAlign"), System.Drawing.ContentAlignment)
        Me.btnPrint.ImageIndex = CType(resources.GetObject("btnPrint.ImageIndex"), Integer)
        Me.btnPrint.ImageList = Me.toolBtnImageList
        Me.btnPrint.ImeMode = CType(resources.GetObject("btnPrint.ImeMode"), System.Windows.Forms.ImeMode)
        Me.btnPrint.Location = CType(resources.GetObject("btnPrint.Location"), System.Drawing.Point)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.RightToLeft = CType(resources.GetObject("btnPrint.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.btnPrint.Size = CType(resources.GetObject("btnPrint.Size"), System.Drawing.Size)
        Me.btnPrint.TabIndex = CType(resources.GetObject("btnPrint.TabIndex"), Integer)
        Me.btnPrint.Text = resources.GetString("btnPrint.Text")
        Me.btnPrint.TextAlign = CType(resources.GetObject("btnPrint.TextAlign"), System.Drawing.ContentAlignment)
        Me.btnPrint.Visible = CType(resources.GetObject("btnPrint.Visible"), Boolean)
        '
        'PrintingForm
        '
        Me.AccessibleDescription = resources.GetString("$this.AccessibleDescription")
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.Controls.Add(Me.tabCntrlPrint)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "PrintingForm"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.tabCntrlPrint.ResumeLayout(False)
        Me.tbPrintPage1.ResumeLayout(False)
        Me.pnToolPrint.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private scl As Single = 1.0F
    Private mlng As MultipleLanguage = New MultipleLanguage(GetType(PrintingForm))

    Private Sub btnScale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnScale.Click
        Try
            Me.scl = Convert.ToSingle(Me.textBox1.Text)
        Catch
            Me.scl = 1
            Me.textBox1.Text = "1"
        End Try
        Me.printPrevCnt.Document = Me.Print(False, False)
    End Sub

    Public Function Print(ByVal showDialog As Boolean, ByVal printing As Boolean) As PrintDocument
        Dim pd As PrintDocument = New PrintDocument
        Try
            If (MainForm.FCADImage.AbsWidth > MainForm.FCADImage.AbsHeight) Then
                pd.DefaultPageSettings.Landscape = True
            End If
            AddHandler pd.PrintPage, New PrintPageEventHandler(AddressOf Me.pd_PrintPage)
            printDlg.Document = pd
            If (showDialog) Then
                If (printDlg.ShowDialog() = DialogResult.OK) Then
                    If (printing) Then pd.Print()
                End If
            Else
                If (printing) Then pd.Print()
            End If
            Return pd
        Catch
            Return Nothing
        End Try
    End Function

    Private Sub pd_PrintPage(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        Dim w_inch As Single = PrinterUnitConvert.Convert(ev.MarginBounds.Width, PrinterUnit.Display, PrinterUnit.ThousandthsOfAnInch)
        Dim h_inch As Single = PrinterUnitConvert.Convert(ev.MarginBounds.Height, PrinterUnit.Display, PrinterUnit.ThousandthsOfAnInch)
        Dim curRect As DRect = New DRect(0, 0, w_inch, h_inch)
        Dim wh As Double = MainForm.FCADImage.AbsWidth / MainForm.FCADImage.AbsHeight
        Dim new_wh As Double = curRect.Width / curRect.Height
        If (new_wh > wh) Then
            curRect.Width = curRect.Height * wh
        Else
            If (new_wh < wh) Then curRect.Height = curRect.Width / wh
        End If
        Dim g1 As Graphics = Me.CreateGraphics()
        Dim ipHdc As IntPtr = g1.GetHdc()
        Dim mf As Metafile = New Metafile(ipHdc, New Rectangle(0, 0, CInt(curRect.Width), CInt(curRect.Height)), MetafileFrameUnit.Pixel)
        g1.ReleaseHdc(ipHdc)
        g1.Dispose()
        Dim g2 As Graphics = Graphics.FromImage(mf)
        Dim tmpcol As Color = MainForm.FCADImage.DefaultColor
        MainForm.FCADImage.DefaultColor = Color.Black
        Dim tmp As Single = MainForm.FCADImage.NullWidth
        MainForm.FCADImage.NullWidth = 10.0F
        MainForm.FCADImage.Draw(g2, New RectangleF(0, 0, CInt(curRect.Width), CInt(curRect.Height)))
        MainForm.FCADImage.DefaultColor = tmpcol
        MainForm.FCADImage.NullWidth = tmp
        g2.Dispose()
        w_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Width, PrinterUnit.ThousandthsOfAnInch, PrinterUnit.Display) * 10
        h_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Height, PrinterUnit.ThousandthsOfAnInch, PrinterUnit.Display) * 10
        curRect = New DRect(0, 0, w_inch * 1.254F, h_inch * 1.254F)
        If (new_wh > wh) Then
            curRect.Width = curRect.Height * wh
        Else
            If (new_wh < wh) Then curRect.Height = curRect.Width / wh
        End If
        ev.Graphics.DrawImage(mf, 0, 0, CInt(curRect.Width * scl), CInt(curRect.Height * scl))
    End Sub

    Private Sub PrintingForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mlng.RestoreLanguage(Me.Controls, Nothing)
        Me.Text = "Custom Print Preview..."
        Me.Text = mlng.SetLanguage(Me.Controls, Nothing, Me.Text)
        If (MainForm.FCADImage Is Nothing) Then Return
        Me.printPrevCnt.Document = Me.Print(False, False)
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If Not (Me.printPrevCnt.Document Is Nothing) Then
            printDlg.Document = printPrevCnt.Document
            If (printDlg.ShowDialog() = DialogResult.OK) Then
                printPrevCnt.Document.Print()
            End If
        End If
    End Sub

    Private Sub PrintingForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If Not (Me.printPrevCnt.Document Is Nothing) Then
            Me.printPrevCnt.Document.Dispose()
        End If
    End Sub

    Private Sub btnZoomIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnZoomIn.Click
        Me.printPrevCnt.Zoom *= 2
    End Sub

    Private Sub btnZoomOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnZoomOut.Click
        Me.printPrevCnt.Zoom /= 2
    End Sub
End Class
