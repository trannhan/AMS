using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Drawing.Imaging;
using CADImportFaceModule;
using CADImport;

namespace CADImportForm
{
	#region Help
	/// <summary>
	/// Represents a form in which a user can preview a current CAD image, change its scale before printing, 
	/// and invoke a standard printing dialog form.
	/// </summary>
	#endregion Help
	public class PrintingForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabPage tbPrintPage1;
		private MultipleLanguage mlng;
		private System.Windows.Forms.PrintPreviewControl printPrevCnt;
		private System.Windows.Forms.PrintDialog printDlg;
		private System.Windows.Forms.TextBox textBox1;
		private float scale;
		private System.Windows.Forms.Label lbScale;
		private System.Windows.Forms.ImageList toolBtnImageList;
		private System.Windows.Forms.Button btnZoomOut;
		private System.Windows.Forms.Button btnZoomIn;
		private System.Windows.Forms.Button btnScale;
		private System.Windows.Forms.TabControl tabCntrlPrint;
		private System.Windows.Forms.Button btnPrint;
		private System.Windows.Forms.Panel pnToolPrint;
		private System.ComponentModel.IContainer components;
		private int def_lay;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="CADImportForm.PrintingForm">PrintingForm</see> class.
		/// </summary>
		#endregion Help
		public PrintingForm()
		{
			InitializeComponent();
			scale = 1;
			mlng = new MultipleLanguage(this.GetType());
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PrintingForm));
			this.tabCntrlPrint = new System.Windows.Forms.TabControl();
			this.tbPrintPage1 = new System.Windows.Forms.TabPage();
			this.printPrevCnt = new System.Windows.Forms.PrintPreviewControl();
			this.pnToolPrint = new System.Windows.Forms.Panel();
			this.lbScale = new System.Windows.Forms.Label();
			this.btnZoomOut = new System.Windows.Forms.Button();
			this.toolBtnImageList = new System.Windows.Forms.ImageList(this.components);
			this.btnZoomIn = new System.Windows.Forms.Button();
			this.btnScale = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btnPrint = new System.Windows.Forms.Button();
			this.printDlg = new System.Windows.Forms.PrintDialog();
			this.tabCntrlPrint.SuspendLayout();
			this.tbPrintPage1.SuspendLayout();
			this.pnToolPrint.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabCntrlPrint
			// 
			this.tabCntrlPrint.AccessibleDescription = resources.GetString("tabCntrlPrint.AccessibleDescription");
			this.tabCntrlPrint.AccessibleName = resources.GetString("tabCntrlPrint.AccessibleName");
			this.tabCntrlPrint.Alignment = ((System.Windows.Forms.TabAlignment)(resources.GetObject("tabCntrlPrint.Alignment")));
			this.tabCntrlPrint.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("tabCntrlPrint.Anchor")));
			this.tabCntrlPrint.Appearance = ((System.Windows.Forms.TabAppearance)(resources.GetObject("tabCntrlPrint.Appearance")));
			this.tabCntrlPrint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabCntrlPrint.BackgroundImage")));
			this.tabCntrlPrint.Controls.Add(this.tbPrintPage1);
			this.tabCntrlPrint.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("tabCntrlPrint.Dock")));
			this.tabCntrlPrint.Enabled = ((bool)(resources.GetObject("tabCntrlPrint.Enabled")));
			this.tabCntrlPrint.Font = ((System.Drawing.Font)(resources.GetObject("tabCntrlPrint.Font")));
			this.tabCntrlPrint.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("tabCntrlPrint.ImeMode")));
			this.tabCntrlPrint.ItemSize = ((System.Drawing.Size)(resources.GetObject("tabCntrlPrint.ItemSize")));
			this.tabCntrlPrint.Location = ((System.Drawing.Point)(resources.GetObject("tabCntrlPrint.Location")));
			this.tabCntrlPrint.Name = "tabCntrlPrint";
			this.tabCntrlPrint.Padding = ((System.Drawing.Point)(resources.GetObject("tabCntrlPrint.Padding")));
			this.tabCntrlPrint.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("tabCntrlPrint.RightToLeft")));
			this.tabCntrlPrint.SelectedIndex = 0;
			this.tabCntrlPrint.ShowToolTips = ((bool)(resources.GetObject("tabCntrlPrint.ShowToolTips")));
			this.tabCntrlPrint.Size = ((System.Drawing.Size)(resources.GetObject("tabCntrlPrint.Size")));
			this.tabCntrlPrint.TabIndex = ((int)(resources.GetObject("tabCntrlPrint.TabIndex")));
			this.tabCntrlPrint.Text = resources.GetString("tabCntrlPrint.Text");
			this.tabCntrlPrint.Visible = ((bool)(resources.GetObject("tabCntrlPrint.Visible")));
			// 
			// tbPrintPage1
			// 
			this.tbPrintPage1.AccessibleDescription = resources.GetString("tbPrintPage1.AccessibleDescription");
			this.tbPrintPage1.AccessibleName = resources.GetString("tbPrintPage1.AccessibleName");
			this.tbPrintPage1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("tbPrintPage1.Anchor")));
			this.tbPrintPage1.AutoScroll = ((bool)(resources.GetObject("tbPrintPage1.AutoScroll")));
			this.tbPrintPage1.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("tbPrintPage1.AutoScrollMargin")));
			this.tbPrintPage1.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("tbPrintPage1.AutoScrollMinSize")));
			this.tbPrintPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbPrintPage1.BackgroundImage")));
			this.tbPrintPage1.Controls.Add(this.printPrevCnt);
			this.tbPrintPage1.Controls.Add(this.pnToolPrint);
			this.tbPrintPage1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("tbPrintPage1.Dock")));
			this.tbPrintPage1.Enabled = ((bool)(resources.GetObject("tbPrintPage1.Enabled")));
			this.tbPrintPage1.Font = ((System.Drawing.Font)(resources.GetObject("tbPrintPage1.Font")));
			this.tbPrintPage1.ImageIndex = ((int)(resources.GetObject("tbPrintPage1.ImageIndex")));
			this.tbPrintPage1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("tbPrintPage1.ImeMode")));
			this.tbPrintPage1.Location = ((System.Drawing.Point)(resources.GetObject("tbPrintPage1.Location")));
			this.tbPrintPage1.Name = "tbPrintPage1";
			this.tbPrintPage1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("tbPrintPage1.RightToLeft")));
			this.tbPrintPage1.Size = ((System.Drawing.Size)(resources.GetObject("tbPrintPage1.Size")));
			this.tbPrintPage1.TabIndex = ((int)(resources.GetObject("tbPrintPage1.TabIndex")));
			this.tbPrintPage1.Text = resources.GetString("tbPrintPage1.Text");
			this.tbPrintPage1.ToolTipText = resources.GetString("tbPrintPage1.ToolTipText");
			this.tbPrintPage1.Visible = ((bool)(resources.GetObject("tbPrintPage1.Visible")));
			// 
			// printPrevCnt
			// 
			this.printPrevCnt.AccessibleDescription = resources.GetString("printPrevCnt.AccessibleDescription");
			this.printPrevCnt.AccessibleName = resources.GetString("printPrevCnt.AccessibleName");
			this.printPrevCnt.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("printPrevCnt.Anchor")));
			this.printPrevCnt.AutoZoom = false;
			this.printPrevCnt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("printPrevCnt.BackgroundImage")));
			this.printPrevCnt.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("printPrevCnt.Dock")));
			this.printPrevCnt.Enabled = ((bool)(resources.GetObject("printPrevCnt.Enabled")));
			this.printPrevCnt.Font = ((System.Drawing.Font)(resources.GetObject("printPrevCnt.Font")));
			this.printPrevCnt.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("printPrevCnt.ImeMode")));
			this.printPrevCnt.Location = ((System.Drawing.Point)(resources.GetObject("printPrevCnt.Location")));
			this.printPrevCnt.Name = "printPrevCnt";
			this.printPrevCnt.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("printPrevCnt.RightToLeft")));
			this.printPrevCnt.Size = ((System.Drawing.Size)(resources.GetObject("printPrevCnt.Size")));
			this.printPrevCnt.TabIndex = ((int)(resources.GetObject("printPrevCnt.TabIndex")));
			this.printPrevCnt.Visible = ((bool)(resources.GetObject("printPrevCnt.Visible")));
			this.printPrevCnt.Zoom = 0.3;
			// 
			// pnToolPrint
			// 
			this.pnToolPrint.AccessibleDescription = resources.GetString("pnToolPrint.AccessibleDescription");
			this.pnToolPrint.AccessibleName = resources.GetString("pnToolPrint.AccessibleName");
			this.pnToolPrint.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("pnToolPrint.Anchor")));
			this.pnToolPrint.AutoScroll = ((bool)(resources.GetObject("pnToolPrint.AutoScroll")));
			this.pnToolPrint.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("pnToolPrint.AutoScrollMargin")));
			this.pnToolPrint.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("pnToolPrint.AutoScrollMinSize")));
			this.pnToolPrint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnToolPrint.BackgroundImage")));
			this.pnToolPrint.Controls.Add(this.lbScale);
			this.pnToolPrint.Controls.Add(this.btnZoomOut);
			this.pnToolPrint.Controls.Add(this.btnZoomIn);
			this.pnToolPrint.Controls.Add(this.btnScale);
			this.pnToolPrint.Controls.Add(this.textBox1);
			this.pnToolPrint.Controls.Add(this.btnPrint);
			this.pnToolPrint.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("pnToolPrint.Dock")));
			this.pnToolPrint.Enabled = ((bool)(resources.GetObject("pnToolPrint.Enabled")));
			this.pnToolPrint.Font = ((System.Drawing.Font)(resources.GetObject("pnToolPrint.Font")));
			this.pnToolPrint.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("pnToolPrint.ImeMode")));
			this.pnToolPrint.Location = ((System.Drawing.Point)(resources.GetObject("pnToolPrint.Location")));
			this.pnToolPrint.Name = "pnToolPrint";
			this.pnToolPrint.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("pnToolPrint.RightToLeft")));
			this.pnToolPrint.Size = ((System.Drawing.Size)(resources.GetObject("pnToolPrint.Size")));
			this.pnToolPrint.TabIndex = ((int)(resources.GetObject("pnToolPrint.TabIndex")));
			this.pnToolPrint.Text = resources.GetString("pnToolPrint.Text");
			this.pnToolPrint.Visible = ((bool)(resources.GetObject("pnToolPrint.Visible")));
			// 
			// lbScale
			// 
			this.lbScale.AccessibleDescription = resources.GetString("lbScale.AccessibleDescription");
			this.lbScale.AccessibleName = resources.GetString("lbScale.AccessibleName");
			this.lbScale.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lbScale.Anchor")));
			this.lbScale.AutoSize = ((bool)(resources.GetObject("lbScale.AutoSize")));
			this.lbScale.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lbScale.Dock")));
			this.lbScale.Enabled = ((bool)(resources.GetObject("lbScale.Enabled")));
			this.lbScale.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lbScale.Font = ((System.Drawing.Font)(resources.GetObject("lbScale.Font")));
			this.lbScale.Image = ((System.Drawing.Image)(resources.GetObject("lbScale.Image")));
			this.lbScale.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbScale.ImageAlign")));
			this.lbScale.ImageIndex = ((int)(resources.GetObject("lbScale.ImageIndex")));
			this.lbScale.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lbScale.ImeMode")));
			this.lbScale.Location = ((System.Drawing.Point)(resources.GetObject("lbScale.Location")));
			this.lbScale.Name = "lbScale";
			this.lbScale.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lbScale.RightToLeft")));
			this.lbScale.Size = ((System.Drawing.Size)(resources.GetObject("lbScale.Size")));
			this.lbScale.TabIndex = ((int)(resources.GetObject("lbScale.TabIndex")));
			this.lbScale.Text = resources.GetString("lbScale.Text");
			this.lbScale.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbScale.TextAlign")));
			this.lbScale.Visible = ((bool)(resources.GetObject("lbScale.Visible")));
			// 
			// btnZoomOut
			// 
			this.btnZoomOut.AccessibleDescription = resources.GetString("btnZoomOut.AccessibleDescription");
			this.btnZoomOut.AccessibleName = resources.GetString("btnZoomOut.AccessibleName");
			this.btnZoomOut.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnZoomOut.Anchor")));
			this.btnZoomOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnZoomOut.BackgroundImage")));
			this.btnZoomOut.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnZoomOut.Dock")));
			this.btnZoomOut.Enabled = ((bool)(resources.GetObject("btnZoomOut.Enabled")));
			this.btnZoomOut.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnZoomOut.FlatStyle")));
			this.btnZoomOut.Font = ((System.Drawing.Font)(resources.GetObject("btnZoomOut.Font")));
			this.btnZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("btnZoomOut.Image")));
			this.btnZoomOut.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnZoomOut.ImageAlign")));
			this.btnZoomOut.ImageIndex = ((int)(resources.GetObject("btnZoomOut.ImageIndex")));
			this.btnZoomOut.ImageList = this.toolBtnImageList;
			this.btnZoomOut.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnZoomOut.ImeMode")));
			this.btnZoomOut.Location = ((System.Drawing.Point)(resources.GetObject("btnZoomOut.Location")));
			this.btnZoomOut.Name = "btnZoomOut";
			this.btnZoomOut.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnZoomOut.RightToLeft")));
			this.btnZoomOut.Size = ((System.Drawing.Size)(resources.GetObject("btnZoomOut.Size")));
			this.btnZoomOut.TabIndex = ((int)(resources.GetObject("btnZoomOut.TabIndex")));
			this.btnZoomOut.Text = resources.GetString("btnZoomOut.Text");
			this.btnZoomOut.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnZoomOut.TextAlign")));
			this.btnZoomOut.Visible = ((bool)(resources.GetObject("btnZoomOut.Visible")));
			this.btnZoomOut.Click += new System.EventHandler(this.btnZoomOut_Click);
			// 
			// toolBtnImageList
			// 
			this.toolBtnImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.toolBtnImageList.ImageSize = ((System.Drawing.Size)(resources.GetObject("toolBtnImageList.ImageSize")));
			this.toolBtnImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolBtnImageList.ImageStream")));
			this.toolBtnImageList.TransparentColor = System.Drawing.Color.White;
			// 
			// btnZoomIn
			// 
			this.btnZoomIn.AccessibleDescription = resources.GetString("btnZoomIn.AccessibleDescription");
			this.btnZoomIn.AccessibleName = resources.GetString("btnZoomIn.AccessibleName");
			this.btnZoomIn.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnZoomIn.Anchor")));
			this.btnZoomIn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnZoomIn.BackgroundImage")));
			this.btnZoomIn.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnZoomIn.Dock")));
			this.btnZoomIn.Enabled = ((bool)(resources.GetObject("btnZoomIn.Enabled")));
			this.btnZoomIn.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnZoomIn.FlatStyle")));
			this.btnZoomIn.Font = ((System.Drawing.Font)(resources.GetObject("btnZoomIn.Font")));
			this.btnZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("btnZoomIn.Image")));
			this.btnZoomIn.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnZoomIn.ImageAlign")));
			this.btnZoomIn.ImageIndex = ((int)(resources.GetObject("btnZoomIn.ImageIndex")));
			this.btnZoomIn.ImageList = this.toolBtnImageList;
			this.btnZoomIn.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnZoomIn.ImeMode")));
			this.btnZoomIn.Location = ((System.Drawing.Point)(resources.GetObject("btnZoomIn.Location")));
			this.btnZoomIn.Name = "btnZoomIn";
			this.btnZoomIn.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnZoomIn.RightToLeft")));
			this.btnZoomIn.Size = ((System.Drawing.Size)(resources.GetObject("btnZoomIn.Size")));
			this.btnZoomIn.TabIndex = ((int)(resources.GetObject("btnZoomIn.TabIndex")));
			this.btnZoomIn.Text = resources.GetString("btnZoomIn.Text");
			this.btnZoomIn.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnZoomIn.TextAlign")));
			this.btnZoomIn.Visible = ((bool)(resources.GetObject("btnZoomIn.Visible")));
			this.btnZoomIn.Click += new System.EventHandler(this.btnZoomIn_Click);
			// 
			// btnScale
			// 
			this.btnScale.AccessibleDescription = resources.GetString("btnScale.AccessibleDescription");
			this.btnScale.AccessibleName = resources.GetString("btnScale.AccessibleName");
			this.btnScale.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnScale.Anchor")));
			this.btnScale.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnScale.BackgroundImage")));
			this.btnScale.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnScale.Dock")));
			this.btnScale.Enabled = ((bool)(resources.GetObject("btnScale.Enabled")));
			this.btnScale.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnScale.FlatStyle")));
			this.btnScale.Font = ((System.Drawing.Font)(resources.GetObject("btnScale.Font")));
			this.btnScale.Image = ((System.Drawing.Image)(resources.GetObject("btnScale.Image")));
			this.btnScale.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnScale.ImageAlign")));
			this.btnScale.ImageIndex = ((int)(resources.GetObject("btnScale.ImageIndex")));
			this.btnScale.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnScale.ImeMode")));
			this.btnScale.Location = ((System.Drawing.Point)(resources.GetObject("btnScale.Location")));
			this.btnScale.Name = "btnScale";
			this.btnScale.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnScale.RightToLeft")));
			this.btnScale.Size = ((System.Drawing.Size)(resources.GetObject("btnScale.Size")));
			this.btnScale.TabIndex = ((int)(resources.GetObject("btnScale.TabIndex")));
			this.btnScale.Text = resources.GetString("btnScale.Text");
			this.btnScale.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnScale.TextAlign")));
			this.btnScale.Visible = ((bool)(resources.GetObject("btnScale.Visible")));
			this.btnScale.Click += new System.EventHandler(this.btnScale_Click);
			// 
			// textBox1
			// 
			this.textBox1.AccessibleDescription = resources.GetString("textBox1.AccessibleDescription");
			this.textBox1.AccessibleName = resources.GetString("textBox1.AccessibleName");
			this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("textBox1.Anchor")));
			this.textBox1.AutoSize = ((bool)(resources.GetObject("textBox1.AutoSize")));
			this.textBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBox1.BackgroundImage")));
			this.textBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("textBox1.Dock")));
			this.textBox1.Enabled = ((bool)(resources.GetObject("textBox1.Enabled")));
			this.textBox1.Font = ((System.Drawing.Font)(resources.GetObject("textBox1.Font")));
			this.textBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("textBox1.ImeMode")));
			this.textBox1.Location = ((System.Drawing.Point)(resources.GetObject("textBox1.Location")));
			this.textBox1.MaxLength = ((int)(resources.GetObject("textBox1.MaxLength")));
			this.textBox1.Multiline = ((bool)(resources.GetObject("textBox1.Multiline")));
			this.textBox1.Name = "textBox1";
			this.textBox1.PasswordChar = ((char)(resources.GetObject("textBox1.PasswordChar")));
			this.textBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("textBox1.RightToLeft")));
			this.textBox1.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("textBox1.ScrollBars")));
			this.textBox1.Size = ((System.Drawing.Size)(resources.GetObject("textBox1.Size")));
			this.textBox1.TabIndex = ((int)(resources.GetObject("textBox1.TabIndex")));
			this.textBox1.Text = resources.GetString("textBox1.Text");
			this.textBox1.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("textBox1.TextAlign")));
			this.textBox1.Visible = ((bool)(resources.GetObject("textBox1.Visible")));
			this.textBox1.WordWrap = ((bool)(resources.GetObject("textBox1.WordWrap")));
			// 
			// btnPrint
			// 
			this.btnPrint.AccessibleDescription = resources.GetString("btnPrint.AccessibleDescription");
			this.btnPrint.AccessibleName = resources.GetString("btnPrint.AccessibleName");
			this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnPrint.Anchor")));
			this.btnPrint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPrint.BackgroundImage")));
			this.btnPrint.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnPrint.Dock")));
			this.btnPrint.Enabled = ((bool)(resources.GetObject("btnPrint.Enabled")));
			this.btnPrint.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnPrint.FlatStyle")));
			this.btnPrint.Font = ((System.Drawing.Font)(resources.GetObject("btnPrint.Font")));
			this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
			this.btnPrint.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnPrint.ImageAlign")));
			this.btnPrint.ImageIndex = ((int)(resources.GetObject("btnPrint.ImageIndex")));
			this.btnPrint.ImageList = this.toolBtnImageList;
			this.btnPrint.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnPrint.ImeMode")));
			this.btnPrint.Location = ((System.Drawing.Point)(resources.GetObject("btnPrint.Location")));
			this.btnPrint.Name = "btnPrint";
			this.btnPrint.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnPrint.RightToLeft")));
			this.btnPrint.Size = ((System.Drawing.Size)(resources.GetObject("btnPrint.Size")));
			this.btnPrint.TabIndex = ((int)(resources.GetObject("btnPrint.TabIndex")));
			this.btnPrint.Text = resources.GetString("btnPrint.Text");
			this.btnPrint.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnPrint.TextAlign")));
			this.btnPrint.Visible = ((bool)(resources.GetObject("btnPrint.Visible")));
			this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
			// 
			// PrintingForm
			// 
			this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
			this.AccessibleName = resources.GetString("$this.AccessibleName");
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.Add(this.tabCntrlPrint);
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "PrintingForm";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.Closing += new System.ComponentModel.CancelEventHandler(this.PrintingForm_Closing);
			this.Load += new System.EventHandler(this.PrintingForm_Load);
			this.tabCntrlPrint.ResumeLayout(false);
			this.tbPrintPage1.ResumeLayout(false);
			this.pnToolPrint.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void PrintingForm_Load(object sender, System.EventArgs e)
		{
			def_lay = MainForm.actForm.FCADImage.CurrentLayoutIndex;
			mlng.RestoreLanguage(this.Controls, null);
			this.Text = "Custom Print Preview...";
			this.Text = mlng.SetLanguage(this.Controls, null, this.Text);
			if(MainForm.actForm.FCADImage == null) return;
			this.printPrevCnt.Columns =  2;
			this.printPrevCnt.Rows = MainForm.actForm.FCADImage.LayersCount / 2;
			this.printPrevCnt.Document = this.Print(false);
		}

		private void btnPrint_Click(object sender, System.EventArgs e)
		{
			if(this.printPrevCnt.Document != null)
			{
				printDlg.Document = printPrevCnt.Document;
				if(printDlg.ShowDialog() == DialogResult.OK)
					printPrevCnt.Document.Print();
			}
		}

		#region Help
		/// <summary>
		/// Prints a current CAD image.
		/// </summary>
		/// <param name="showDialog">A value indicating if printing proceeds right away after loading the 
		/// <see cref="CADImportForm.PrintingForm">PrintingForm</see> instance (<b>true</b>) or waits for 
		/// a user input (<b>false</b>).</param>
		/// <returns>A <see cref="System.Drawing.Printing.PrintDocument">PrintDocument</see> object that sends output to the printer.</returns>
		#endregion Help
		public virtual PrintDocument Print(bool showDialog)
		{
			PrintDocument pd = new PrintDocument();
			try
			{
				if(MainForm.actForm.FCADImage.AbsWidth > MainForm.actForm.FCADImage.AbsHeight)
					pd.DefaultPageSettings.Landscape = true;
				pd.PrintPage += new PrintPageEventHandler (this.pd_PrintPage);
				printDlg.Document = pd;
				if(showDialog) 
					if(printDlg.ShowDialog() == DialogResult.OK)
						pd.Print();
				return pd;
			}
			catch(Exception e) 
			{
				#if DEBUG
					MessageBox.Show(e.Message, "CADImport Net debug", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				#endif
				return null;
			}
		}
		
		private void pd_PrintPage(object sender, PrintPageEventArgs ev) 
		{
			//example all layouts
			/*if(cn_pages < MainForm.actForm.FCADImage.LayoutsCount)
			{
				MainForm.actForm.FCADImage.SetCurrentLayout(cn_pages);	
				MainForm.actForm.DoResize();
				if(MainForm.actForm.FCADImage.AbsWidth > MainForm.actForm.FCADImage.AbsHeight)
					(sender as PrintDocument).DefaultPageSettings.Landscape = true;
				else
					(sender as PrintDocument).DefaultPageSettings.Landscape = false;
				cn_pages++;
				if(cn_pages < MainForm.actForm.FCADImage.LayoutsCount)
					ev.HasMorePages = true;
			}
			else
			{
				ev.HasMorePages = false;
				MainForm.actForm.FCADImage.SetCurrentLayout(this.def_lay);	
				MainForm.actForm.DoResize();
				return;
			}*/
			float w_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Width, PrinterUnit.Display, PrinterUnit.ThousandthsOfAnInch);
			float h_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Height, PrinterUnit.Display, PrinterUnit.ThousandthsOfAnInch);
			DRect curRect = new DRect(0, 0, w_inch, h_inch);
			double wh = MainForm.actForm.FCADImage.AbsWidth / MainForm.actForm.FCADImage.AbsHeight; 
			double new_wh = curRect.Width / curRect.Height;
			if(new_wh > wh)
				curRect.Width = curRect.Height * wh;
			else 
			{
				if(new_wh < wh)
				{
					curRect.Height = curRect.Width / wh;
				}
			}
			Graphics g1 = this.CreateGraphics();
			IntPtr ipHdc = g1.GetHdc();
			Metafile mf = new Metafile(ipHdc, new Rectangle(0, 0, (int)curRect.Width, (int)curRect.Height),
				MetafileFrameUnit.Pixel);
			g1.ReleaseHdc(ipHdc);
			g1.Dispose();
			Graphics g2 = Graphics.FromImage(mf);
			Color tmpcol = MainForm.actForm.FCADImage.DefaultColor;
			MainForm.actForm.FCADImage.DefaultColor = Color.Black;
			float tmp = MainForm.actForm.FCADImage.NullWidth;
			MainForm.actForm.FCADImage.NullWidth = 10f;
			MainForm.actForm.FCADImage.Draw(g2, new RectangleF(0, 0, (float)curRect.Width, (float)curRect.Height));
			MainForm.actForm.FCADImage.DefaultColor = tmpcol;
			MainForm.actForm.FCADImage.NullWidth = tmp;
			g2.Dispose();
			w_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Width, PrinterUnit.ThousandthsOfAnInch, PrinterUnit.Display)*10;
			h_inch = PrinterUnitConvert.Convert(ev.MarginBounds.Height, PrinterUnit.ThousandthsOfAnInch, PrinterUnit.Display)*10;
			curRect = new DRect(0, 0, w_inch*1.254f, h_inch*1.254f);
			if(new_wh > wh)
				curRect.Width = curRect.Height * wh;
			else 
			{
				if(new_wh < wh)
				{
					curRect.Height = curRect.Width / wh;
				}
			}
			ev.Graphics.DrawImage(mf, 0, 0, (float)curRect.Width*scale, (float)curRect.Height*scale);
		}

		private void PrintingForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(this.printPrevCnt.Document != null)
				this.printPrevCnt.Document.Dispose();
		}

		private void btnScale_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.scale = Convert.ToSingle(this.textBox1.Text);
			}
			catch
			{
				this.scale = 1;
				this.textBox1.Text = "1";
			}
			this.printPrevCnt.Document = this.Print(false);
		}

		private void btnZoomOut_Click(object sender, System.EventArgs e)
		{
			this.printPrevCnt.Zoom /= 2;
		}

		private void btnZoomIn_Click(object sender, System.EventArgs e)
		{
			this.printPrevCnt.Zoom *= 2;
		}
	}
}
