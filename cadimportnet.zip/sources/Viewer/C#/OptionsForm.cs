using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CADImportFaceModule;
using System.IO;
using CADImportForm;
using CADImport;

namespace CADImportForm
{
	#region Help
	/// <summary>
	/// Represents a form in which different options can be set.
	/// </summary>
	/// <remarks>In <b>OptionsForm</b> a user can select a path to the file of language support, a current language, 
	/// a background color, a color mode (black or colored), and to show or to hide the entities tree panel. All 
	/// options set in the <b>OptionsForm</b> are saved.</remarks>
	#endregion Help
	public class OptionsForm : System.Windows.Forms.Form
	{
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbLnPath;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.FolderBrowserDialog fldBrow;
		private System.Windows.Forms.Button btClose;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbLang;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.RadioButton rdbWhite;
		private System.Windows.Forms.RadioButton rdbBlack;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox chbEnt;
		private System.Windows.Forms.RadioButton rdColorDraw;
		private System.Windows.Forms.RadioButton rdDrawBlack;
		private System.Windows.Forms.Button btDefPath;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private MultipleLanguage mlng;
		private string old_path;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="CADImportForm.OptionsForm">OptionsForm</see> class.
		/// </summary>
		#endregion Help
		public OptionsForm()
		{
			InitializeComponent();
			mlng = new MultipleLanguage(this.GetType());
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OptionsForm));
			this.tbLnPath = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.fldBrow = new System.Windows.Forms.FolderBrowserDialog();
			this.btClose = new System.Windows.Forms.Button();
			this.cbLang = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rdbBlack = new System.Windows.Forms.RadioButton();
			this.rdbWhite = new System.Windows.Forms.RadioButton();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.rdColorDraw = new System.Windows.Forms.RadioButton();
			this.rdDrawBlack = new System.Windows.Forms.RadioButton();
			this.chbEnt = new System.Windows.Forms.CheckBox();
			this.btDefPath = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// tbLnPath
			// 
			this.tbLnPath.AccessibleDescription = resources.GetString("tbLnPath.AccessibleDescription");
			this.tbLnPath.AccessibleName = resources.GetString("tbLnPath.AccessibleName");
			this.tbLnPath.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("tbLnPath.Anchor")));
			this.tbLnPath.AutoSize = ((bool)(resources.GetObject("tbLnPath.AutoSize")));
			this.tbLnPath.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbLnPath.BackgroundImage")));
			this.tbLnPath.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("tbLnPath.Dock")));
			this.tbLnPath.Enabled = ((bool)(resources.GetObject("tbLnPath.Enabled")));
			this.tbLnPath.Font = ((System.Drawing.Font)(resources.GetObject("tbLnPath.Font")));
			this.tbLnPath.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("tbLnPath.ImeMode")));
			this.tbLnPath.Location = ((System.Drawing.Point)(resources.GetObject("tbLnPath.Location")));
			this.tbLnPath.MaxLength = ((int)(resources.GetObject("tbLnPath.MaxLength")));
			this.tbLnPath.Multiline = ((bool)(resources.GetObject("tbLnPath.Multiline")));
			this.tbLnPath.Name = "tbLnPath";
			this.tbLnPath.PasswordChar = ((char)(resources.GetObject("tbLnPath.PasswordChar")));
			this.tbLnPath.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("tbLnPath.RightToLeft")));
			this.tbLnPath.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("tbLnPath.ScrollBars")));
			this.tbLnPath.Size = ((System.Drawing.Size)(resources.GetObject("tbLnPath.Size")));
			this.tbLnPath.TabIndex = ((int)(resources.GetObject("tbLnPath.TabIndex")));
			this.tbLnPath.Tag = "-1";
			this.tbLnPath.Text = resources.GetString("tbLnPath.Text");
			this.tbLnPath.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("tbLnPath.TextAlign")));
			this.tbLnPath.Visible = ((bool)(resources.GetObject("tbLnPath.Visible")));
			this.tbLnPath.WordWrap = ((bool)(resources.GetObject("tbLnPath.WordWrap")));
			// 
			// label1
			// 
			this.label1.AccessibleDescription = resources.GetString("label1.AccessibleDescription");
			this.label1.AccessibleName = resources.GetString("label1.AccessibleName");
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label1.Anchor")));
			this.label1.AutoSize = ((bool)(resources.GetObject("label1.AutoSize")));
			this.label1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label1.Dock")));
			this.label1.Enabled = ((bool)(resources.GetObject("label1.Enabled")));
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = ((System.Drawing.Font)(resources.GetObject("label1.Font")));
			this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
			this.label1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.ImageAlign")));
			this.label1.ImageIndex = ((int)(resources.GetObject("label1.ImageIndex")));
			this.label1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label1.ImeMode")));
			this.label1.Location = ((System.Drawing.Point)(resources.GetObject("label1.Location")));
			this.label1.Name = "label1";
			this.label1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label1.RightToLeft")));
			this.label1.Size = ((System.Drawing.Size)(resources.GetObject("label1.Size")));
			this.label1.TabIndex = ((int)(resources.GetObject("label1.TabIndex")));
			this.label1.Text = resources.GetString("label1.Text");
			this.label1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.TextAlign")));
			this.label1.Visible = ((bool)(resources.GetObject("label1.Visible")));
			// 
			// button1
			// 
			this.button1.AccessibleDescription = resources.GetString("button1.AccessibleDescription");
			this.button1.AccessibleName = resources.GetString("button1.AccessibleName");
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("button1.Anchor")));
			this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
			this.button1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("button1.Dock")));
			this.button1.Enabled = ((bool)(resources.GetObject("button1.Enabled")));
			this.button1.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("button1.FlatStyle")));
			this.button1.Font = ((System.Drawing.Font)(resources.GetObject("button1.Font")));
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button1.ImageAlign")));
			this.button1.ImageIndex = ((int)(resources.GetObject("button1.ImageIndex")));
			this.button1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("button1.ImeMode")));
			this.button1.Location = ((System.Drawing.Point)(resources.GetObject("button1.Location")));
			this.button1.Name = "button1";
			this.button1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("button1.RightToLeft")));
			this.button1.Size = ((System.Drawing.Size)(resources.GetObject("button1.Size")));
			this.button1.TabIndex = ((int)(resources.GetObject("button1.TabIndex")));
			this.button1.Text = resources.GetString("button1.Text");
			this.button1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button1.TextAlign")));
			this.button1.Visible = ((bool)(resources.GetObject("button1.Visible")));
			this.button1.Click += new System.EventHandler(this.SelectPath_Click);
			// 
			// fldBrow
			// 
			this.fldBrow.Description = resources.GetString("fldBrow.Description");
			this.fldBrow.SelectedPath = resources.GetString("fldBrow.SelectedPath");
			// 
			// btClose
			// 
			this.btClose.AccessibleDescription = resources.GetString("btClose.AccessibleDescription");
			this.btClose.AccessibleName = resources.GetString("btClose.AccessibleName");
			this.btClose.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btClose.Anchor")));
			this.btClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btClose.BackgroundImage")));
			this.btClose.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btClose.Dock")));
			this.btClose.Enabled = ((bool)(resources.GetObject("btClose.Enabled")));
			this.btClose.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btClose.FlatStyle")));
			this.btClose.Font = ((System.Drawing.Font)(resources.GetObject("btClose.Font")));
			this.btClose.Image = ((System.Drawing.Image)(resources.GetObject("btClose.Image")));
			this.btClose.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btClose.ImageAlign")));
			this.btClose.ImageIndex = ((int)(resources.GetObject("btClose.ImageIndex")));
			this.btClose.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btClose.ImeMode")));
			this.btClose.Location = ((System.Drawing.Point)(resources.GetObject("btClose.Location")));
			this.btClose.Name = "btClose";
			this.btClose.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btClose.RightToLeft")));
			this.btClose.Size = ((System.Drawing.Size)(resources.GetObject("btClose.Size")));
			this.btClose.TabIndex = ((int)(resources.GetObject("btClose.TabIndex")));
			this.btClose.Text = resources.GetString("btClose.Text");
			this.btClose.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btClose.TextAlign")));
			this.btClose.Visible = ((bool)(resources.GetObject("btClose.Visible")));
			this.btClose.Click += new System.EventHandler(this.btClose_Click);
			// 
			// cbLang
			// 
			this.cbLang.AccessibleDescription = resources.GetString("cbLang.AccessibleDescription");
			this.cbLang.AccessibleName = resources.GetString("cbLang.AccessibleName");
			this.cbLang.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("cbLang.Anchor")));
			this.cbLang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cbLang.BackgroundImage")));
			this.cbLang.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("cbLang.Dock")));
			this.cbLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbLang.Enabled = ((bool)(resources.GetObject("cbLang.Enabled")));
			this.cbLang.Font = ((System.Drawing.Font)(resources.GetObject("cbLang.Font")));
			this.cbLang.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("cbLang.ImeMode")));
			this.cbLang.IntegralHeight = ((bool)(resources.GetObject("cbLang.IntegralHeight")));
			this.cbLang.ItemHeight = ((int)(resources.GetObject("cbLang.ItemHeight")));
			this.cbLang.Location = ((System.Drawing.Point)(resources.GetObject("cbLang.Location")));
			this.cbLang.MaxDropDownItems = ((int)(resources.GetObject("cbLang.MaxDropDownItems")));
			this.cbLang.MaxLength = ((int)(resources.GetObject("cbLang.MaxLength")));
			this.cbLang.Name = "cbLang";
			this.cbLang.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("cbLang.RightToLeft")));
			this.cbLang.Size = ((System.Drawing.Size)(resources.GetObject("cbLang.Size")));
			this.cbLang.TabIndex = ((int)(resources.GetObject("cbLang.TabIndex")));
			this.cbLang.Tag = "-1";
			this.cbLang.Text = resources.GetString("cbLang.Text");
			this.cbLang.Visible = ((bool)(resources.GetObject("cbLang.Visible")));
			// 
			// label2
			// 
			this.label2.AccessibleDescription = resources.GetString("label2.AccessibleDescription");
			this.label2.AccessibleName = resources.GetString("label2.AccessibleName");
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label2.Anchor")));
			this.label2.AutoSize = ((bool)(resources.GetObject("label2.AutoSize")));
			this.label2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label2.Dock")));
			this.label2.Enabled = ((bool)(resources.GetObject("label2.Enabled")));
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label2.Font = ((System.Drawing.Font)(resources.GetObject("label2.Font")));
			this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
			this.label2.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label2.ImageAlign")));
			this.label2.ImageIndex = ((int)(resources.GetObject("label2.ImageIndex")));
			this.label2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label2.ImeMode")));
			this.label2.Location = ((System.Drawing.Point)(resources.GetObject("label2.Location")));
			this.label2.Name = "label2";
			this.label2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label2.RightToLeft")));
			this.label2.Size = ((System.Drawing.Size)(resources.GetObject("label2.Size")));
			this.label2.TabIndex = ((int)(resources.GetObject("label2.TabIndex")));
			this.label2.Text = resources.GetString("label2.Text");
			this.label2.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label2.TextAlign")));
			this.label2.Visible = ((bool)(resources.GetObject("label2.Visible")));
			// 
			// groupBox1
			// 
			this.groupBox1.AccessibleDescription = resources.GetString("groupBox1.AccessibleDescription");
			this.groupBox1.AccessibleName = resources.GetString("groupBox1.AccessibleName");
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("groupBox1.Anchor")));
			this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
			this.groupBox1.Controls.Add(this.rdbBlack);
			this.groupBox1.Controls.Add(this.rdbWhite);
			this.groupBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("groupBox1.Dock")));
			this.groupBox1.Enabled = ((bool)(resources.GetObject("groupBox1.Enabled")));
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Font = ((System.Drawing.Font)(resources.GetObject("groupBox1.Font")));
			this.groupBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("groupBox1.ImeMode")));
			this.groupBox1.Location = ((System.Drawing.Point)(resources.GetObject("groupBox1.Location")));
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("groupBox1.RightToLeft")));
			this.groupBox1.Size = ((System.Drawing.Size)(resources.GetObject("groupBox1.Size")));
			this.groupBox1.TabIndex = ((int)(resources.GetObject("groupBox1.TabIndex")));
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = resources.GetString("groupBox1.Text");
			this.groupBox1.Visible = ((bool)(resources.GetObject("groupBox1.Visible")));
			// 
			// rdbBlack
			// 
			this.rdbBlack.AccessibleDescription = resources.GetString("rdbBlack.AccessibleDescription");
			this.rdbBlack.AccessibleName = resources.GetString("rdbBlack.AccessibleName");
			this.rdbBlack.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("rdbBlack.Anchor")));
			this.rdbBlack.Appearance = ((System.Windows.Forms.Appearance)(resources.GetObject("rdbBlack.Appearance")));
			this.rdbBlack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rdbBlack.BackgroundImage")));
			this.rdbBlack.CheckAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbBlack.CheckAlign")));
			this.rdbBlack.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("rdbBlack.Dock")));
			this.rdbBlack.Enabled = ((bool)(resources.GetObject("rdbBlack.Enabled")));
			this.rdbBlack.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("rdbBlack.FlatStyle")));
			this.rdbBlack.Font = ((System.Drawing.Font)(resources.GetObject("rdbBlack.Font")));
			this.rdbBlack.Image = ((System.Drawing.Image)(resources.GetObject("rdbBlack.Image")));
			this.rdbBlack.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbBlack.ImageAlign")));
			this.rdbBlack.ImageIndex = ((int)(resources.GetObject("rdbBlack.ImageIndex")));
			this.rdbBlack.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("rdbBlack.ImeMode")));
			this.rdbBlack.Location = ((System.Drawing.Point)(resources.GetObject("rdbBlack.Location")));
			this.rdbBlack.Name = "rdbBlack";
			this.rdbBlack.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("rdbBlack.RightToLeft")));
			this.rdbBlack.Size = ((System.Drawing.Size)(resources.GetObject("rdbBlack.Size")));
			this.rdbBlack.TabIndex = ((int)(resources.GetObject("rdbBlack.TabIndex")));
			this.rdbBlack.Text = resources.GetString("rdbBlack.Text");
			this.rdbBlack.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbBlack.TextAlign")));
			this.rdbBlack.Visible = ((bool)(resources.GetObject("rdbBlack.Visible")));
			// 
			// rdbWhite
			// 
			this.rdbWhite.AccessibleDescription = resources.GetString("rdbWhite.AccessibleDescription");
			this.rdbWhite.AccessibleName = resources.GetString("rdbWhite.AccessibleName");
			this.rdbWhite.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("rdbWhite.Anchor")));
			this.rdbWhite.Appearance = ((System.Windows.Forms.Appearance)(resources.GetObject("rdbWhite.Appearance")));
			this.rdbWhite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rdbWhite.BackgroundImage")));
			this.rdbWhite.CheckAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbWhite.CheckAlign")));
			this.rdbWhite.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("rdbWhite.Dock")));
			this.rdbWhite.Enabled = ((bool)(resources.GetObject("rdbWhite.Enabled")));
			this.rdbWhite.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("rdbWhite.FlatStyle")));
			this.rdbWhite.Font = ((System.Drawing.Font)(resources.GetObject("rdbWhite.Font")));
			this.rdbWhite.Image = ((System.Drawing.Image)(resources.GetObject("rdbWhite.Image")));
			this.rdbWhite.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbWhite.ImageAlign")));
			this.rdbWhite.ImageIndex = ((int)(resources.GetObject("rdbWhite.ImageIndex")));
			this.rdbWhite.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("rdbWhite.ImeMode")));
			this.rdbWhite.Location = ((System.Drawing.Point)(resources.GetObject("rdbWhite.Location")));
			this.rdbWhite.Name = "rdbWhite";
			this.rdbWhite.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("rdbWhite.RightToLeft")));
			this.rdbWhite.Size = ((System.Drawing.Size)(resources.GetObject("rdbWhite.Size")));
			this.rdbWhite.TabIndex = ((int)(resources.GetObject("rdbWhite.TabIndex")));
			this.rdbWhite.Text = resources.GetString("rdbWhite.Text");
			this.rdbWhite.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdbWhite.TextAlign")));
			this.rdbWhite.Visible = ((bool)(resources.GetObject("rdbWhite.Visible")));
			// 
			// button2
			// 
			this.button2.AccessibleDescription = resources.GetString("button2.AccessibleDescription");
			this.button2.AccessibleName = resources.GetString("button2.AccessibleName");
			this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("button2.Anchor")));
			this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
			this.button2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("button2.Dock")));
			this.button2.Enabled = ((bool)(resources.GetObject("button2.Enabled")));
			this.button2.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("button2.FlatStyle")));
			this.button2.Font = ((System.Drawing.Font)(resources.GetObject("button2.Font")));
			this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
			this.button2.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button2.ImageAlign")));
			this.button2.ImageIndex = ((int)(resources.GetObject("button2.ImageIndex")));
			this.button2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("button2.ImeMode")));
			this.button2.Location = ((System.Drawing.Point)(resources.GetObject("button2.Location")));
			this.button2.Name = "button2";
			this.button2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("button2.RightToLeft")));
			this.button2.Size = ((System.Drawing.Size)(resources.GetObject("button2.Size")));
			this.button2.TabIndex = ((int)(resources.GetObject("button2.TabIndex")));
			this.button2.Text = resources.GetString("button2.Text");
			this.button2.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button2.TextAlign")));
			this.button2.Visible = ((bool)(resources.GetObject("button2.Visible")));
			this.button2.Click += new System.EventHandler(this.Ok_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.AccessibleDescription = resources.GetString("groupBox2.AccessibleDescription");
			this.groupBox2.AccessibleName = resources.GetString("groupBox2.AccessibleName");
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("groupBox2.Anchor")));
			this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
			this.groupBox2.Controls.Add(this.rdColorDraw);
			this.groupBox2.Controls.Add(this.rdDrawBlack);
			this.groupBox2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("groupBox2.Dock")));
			this.groupBox2.Enabled = ((bool)(resources.GetObject("groupBox2.Enabled")));
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Font = ((System.Drawing.Font)(resources.GetObject("groupBox2.Font")));
			this.groupBox2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("groupBox2.ImeMode")));
			this.groupBox2.Location = ((System.Drawing.Point)(resources.GetObject("groupBox2.Location")));
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("groupBox2.RightToLeft")));
			this.groupBox2.Size = ((System.Drawing.Size)(resources.GetObject("groupBox2.Size")));
			this.groupBox2.TabIndex = ((int)(resources.GetObject("groupBox2.TabIndex")));
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = resources.GetString("groupBox2.Text");
			this.groupBox2.Visible = ((bool)(resources.GetObject("groupBox2.Visible")));
			// 
			// rdColorDraw
			// 
			this.rdColorDraw.AccessibleDescription = resources.GetString("rdColorDraw.AccessibleDescription");
			this.rdColorDraw.AccessibleName = resources.GetString("rdColorDraw.AccessibleName");
			this.rdColorDraw.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("rdColorDraw.Anchor")));
			this.rdColorDraw.Appearance = ((System.Windows.Forms.Appearance)(resources.GetObject("rdColorDraw.Appearance")));
			this.rdColorDraw.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rdColorDraw.BackgroundImage")));
			this.rdColorDraw.CheckAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdColorDraw.CheckAlign")));
			this.rdColorDraw.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("rdColorDraw.Dock")));
			this.rdColorDraw.Enabled = ((bool)(resources.GetObject("rdColorDraw.Enabled")));
			this.rdColorDraw.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("rdColorDraw.FlatStyle")));
			this.rdColorDraw.Font = ((System.Drawing.Font)(resources.GetObject("rdColorDraw.Font")));
			this.rdColorDraw.Image = ((System.Drawing.Image)(resources.GetObject("rdColorDraw.Image")));
			this.rdColorDraw.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdColorDraw.ImageAlign")));
			this.rdColorDraw.ImageIndex = ((int)(resources.GetObject("rdColorDraw.ImageIndex")));
			this.rdColorDraw.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("rdColorDraw.ImeMode")));
			this.rdColorDraw.Location = ((System.Drawing.Point)(resources.GetObject("rdColorDraw.Location")));
			this.rdColorDraw.Name = "rdColorDraw";
			this.rdColorDraw.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("rdColorDraw.RightToLeft")));
			this.rdColorDraw.Size = ((System.Drawing.Size)(resources.GetObject("rdColorDraw.Size")));
			this.rdColorDraw.TabIndex = ((int)(resources.GetObject("rdColorDraw.TabIndex")));
			this.rdColorDraw.Text = resources.GetString("rdColorDraw.Text");
			this.rdColorDraw.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdColorDraw.TextAlign")));
			this.rdColorDraw.Visible = ((bool)(resources.GetObject("rdColorDraw.Visible")));
			// 
			// rdDrawBlack
			// 
			this.rdDrawBlack.AccessibleDescription = resources.GetString("rdDrawBlack.AccessibleDescription");
			this.rdDrawBlack.AccessibleName = resources.GetString("rdDrawBlack.AccessibleName");
			this.rdDrawBlack.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("rdDrawBlack.Anchor")));
			this.rdDrawBlack.Appearance = ((System.Windows.Forms.Appearance)(resources.GetObject("rdDrawBlack.Appearance")));
			this.rdDrawBlack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rdDrawBlack.BackgroundImage")));
			this.rdDrawBlack.CheckAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdDrawBlack.CheckAlign")));
			this.rdDrawBlack.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("rdDrawBlack.Dock")));
			this.rdDrawBlack.Enabled = ((bool)(resources.GetObject("rdDrawBlack.Enabled")));
			this.rdDrawBlack.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("rdDrawBlack.FlatStyle")));
			this.rdDrawBlack.Font = ((System.Drawing.Font)(resources.GetObject("rdDrawBlack.Font")));
			this.rdDrawBlack.Image = ((System.Drawing.Image)(resources.GetObject("rdDrawBlack.Image")));
			this.rdDrawBlack.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdDrawBlack.ImageAlign")));
			this.rdDrawBlack.ImageIndex = ((int)(resources.GetObject("rdDrawBlack.ImageIndex")));
			this.rdDrawBlack.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("rdDrawBlack.ImeMode")));
			this.rdDrawBlack.Location = ((System.Drawing.Point)(resources.GetObject("rdDrawBlack.Location")));
			this.rdDrawBlack.Name = "rdDrawBlack";
			this.rdDrawBlack.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("rdDrawBlack.RightToLeft")));
			this.rdDrawBlack.Size = ((System.Drawing.Size)(resources.GetObject("rdDrawBlack.Size")));
			this.rdDrawBlack.TabIndex = ((int)(resources.GetObject("rdDrawBlack.TabIndex")));
			this.rdDrawBlack.Text = resources.GetString("rdDrawBlack.Text");
			this.rdDrawBlack.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("rdDrawBlack.TextAlign")));
			this.rdDrawBlack.Visible = ((bool)(resources.GetObject("rdDrawBlack.Visible")));
			// 
			// chbEnt
			// 
			this.chbEnt.AccessibleDescription = resources.GetString("chbEnt.AccessibleDescription");
			this.chbEnt.AccessibleName = resources.GetString("chbEnt.AccessibleName");
			this.chbEnt.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("chbEnt.Anchor")));
			this.chbEnt.Appearance = ((System.Windows.Forms.Appearance)(resources.GetObject("chbEnt.Appearance")));
			this.chbEnt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbEnt.BackgroundImage")));
			this.chbEnt.CheckAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("chbEnt.CheckAlign")));
			this.chbEnt.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("chbEnt.Dock")));
			this.chbEnt.Enabled = ((bool)(resources.GetObject("chbEnt.Enabled")));
			this.chbEnt.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("chbEnt.FlatStyle")));
			this.chbEnt.Font = ((System.Drawing.Font)(resources.GetObject("chbEnt.Font")));
			this.chbEnt.Image = ((System.Drawing.Image)(resources.GetObject("chbEnt.Image")));
			this.chbEnt.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("chbEnt.ImageAlign")));
			this.chbEnt.ImageIndex = ((int)(resources.GetObject("chbEnt.ImageIndex")));
			this.chbEnt.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("chbEnt.ImeMode")));
			this.chbEnt.Location = ((System.Drawing.Point)(resources.GetObject("chbEnt.Location")));
			this.chbEnt.Name = "chbEnt";
			this.chbEnt.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("chbEnt.RightToLeft")));
			this.chbEnt.Size = ((System.Drawing.Size)(resources.GetObject("chbEnt.Size")));
			this.chbEnt.TabIndex = ((int)(resources.GetObject("chbEnt.TabIndex")));
			this.chbEnt.Text = resources.GetString("chbEnt.Text");
			this.chbEnt.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("chbEnt.TextAlign")));
			this.chbEnt.Visible = ((bool)(resources.GetObject("chbEnt.Visible")));
			// 
			// btDefPath
			// 
			this.btDefPath.AccessibleDescription = resources.GetString("btDefPath.AccessibleDescription");
			this.btDefPath.AccessibleName = resources.GetString("btDefPath.AccessibleName");
			this.btDefPath.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btDefPath.Anchor")));
			this.btDefPath.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btDefPath.BackgroundImage")));
			this.btDefPath.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btDefPath.Dock")));
			this.btDefPath.Enabled = ((bool)(resources.GetObject("btDefPath.Enabled")));
			this.btDefPath.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btDefPath.FlatStyle")));
			this.btDefPath.Font = ((System.Drawing.Font)(resources.GetObject("btDefPath.Font")));
			this.btDefPath.Image = ((System.Drawing.Image)(resources.GetObject("btDefPath.Image")));
			this.btDefPath.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btDefPath.ImageAlign")));
			this.btDefPath.ImageIndex = ((int)(resources.GetObject("btDefPath.ImageIndex")));
			this.btDefPath.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btDefPath.ImeMode")));
			this.btDefPath.Location = ((System.Drawing.Point)(resources.GetObject("btDefPath.Location")));
			this.btDefPath.Name = "btDefPath";
			this.btDefPath.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btDefPath.RightToLeft")));
			this.btDefPath.Size = ((System.Drawing.Size)(resources.GetObject("btDefPath.Size")));
			this.btDefPath.TabIndex = ((int)(resources.GetObject("btDefPath.TabIndex")));
			this.btDefPath.Text = resources.GetString("btDefPath.Text");
			this.btDefPath.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btDefPath.TextAlign")));
			this.btDefPath.Visible = ((bool)(resources.GetObject("btDefPath.Visible")));
			this.btDefPath.Click += new System.EventHandler(this.btDefPath_Click);
			// 
			// button3
			// 
			this.button3.AccessibleDescription = resources.GetString("button3.AccessibleDescription");
			this.button3.AccessibleName = resources.GetString("button3.AccessibleName");
			this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("button3.Anchor")));
			this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
			this.button3.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("button3.Dock")));
			this.button3.Enabled = ((bool)(resources.GetObject("button3.Enabled")));
			this.button3.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("button3.FlatStyle")));
			this.button3.Font = ((System.Drawing.Font)(resources.GetObject("button3.Font")));
			this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
			this.button3.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button3.ImageAlign")));
			this.button3.ImageIndex = ((int)(resources.GetObject("button3.ImageIndex")));
			this.button3.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("button3.ImeMode")));
			this.button3.Location = ((System.Drawing.Point)(resources.GetObject("button3.Location")));
			this.button3.Name = "button3";
			this.button3.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("button3.RightToLeft")));
			this.button3.Size = ((System.Drawing.Size)(resources.GetObject("button3.Size")));
			this.button3.TabIndex = ((int)(resources.GetObject("button3.TabIndex")));
			this.button3.Text = resources.GetString("button3.Text");
			this.button3.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button3.TextAlign")));
			this.button3.Visible = ((bool)(resources.GetObject("button3.Visible")));
			this.button3.Click += new System.EventHandler(this.CurrentPath_Click);
			// 
			// button4
			// 
			this.button4.AccessibleDescription = resources.GetString("button4.AccessibleDescription");
			this.button4.AccessibleName = resources.GetString("button4.AccessibleName");
			this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("button4.Anchor")));
			this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
			this.button4.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("button4.Dock")));
			this.button4.Enabled = ((bool)(resources.GetObject("button4.Enabled")));
			this.button4.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("button4.FlatStyle")));
			this.button4.Font = ((System.Drawing.Font)(resources.GetObject("button4.Font")));
			this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
			this.button4.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button4.ImageAlign")));
			this.button4.ImageIndex = ((int)(resources.GetObject("button4.ImageIndex")));
			this.button4.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("button4.ImeMode")));
			this.button4.Location = ((System.Drawing.Point)(resources.GetObject("button4.Location")));
			this.button4.Name = "button4";
			this.button4.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("button4.RightToLeft")));
			this.button4.Size = ((System.Drawing.Size)(resources.GetObject("button4.Size")));
			this.button4.TabIndex = ((int)(resources.GetObject("button4.TabIndex")));
			this.button4.Text = resources.GetString("button4.Text");
			this.button4.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button4.TextAlign")));
			this.button4.Visible = ((bool)(resources.GetObject("button4.Visible")));
			this.button4.Click += new System.EventHandler(this.ReloadPath_Click);
			// 
			// OptionsForm
			// 
			this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
			this.AccessibleName = resources.GetString("$this.AccessibleName");
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.Add(this.tbLnPath);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.btDefPath);
			this.Controls.Add(this.chbEnt);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbLang);
			this.Controls.Add(this.btClose);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximizeBox = false;
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "OptionsForm";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.Load += new System.EventHandler(this.Options_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void Options_Load(object sender, System.EventArgs e)
		{
			mlng.RestoreLanguage(this.Controls, null);
			this.Text = "Options";
			this.Text = mlng.SetLanguage(this.Controls, null, this.Text);
			old_path = MultipleLanguage.path;
			tbLnPath.Text = MultipleLanguage.path;
			this.cbLang.Items.Clear();
			string tmp;
			for(int i = 0; i < MultipleLanguage.languagesList.Length; i++)
			{
				tmp = MultipleLanguage.languagesList[i];
				this.cbLang.Items.Add(tmp);
				if(MultipleLanguage.language.ToUpper() == tmp.ToUpper())
					this.cbLang.SelectedIndex = i;
			}
			
			if(MainForm.settingsLst != null)
			{
				//BackgroundColor
				string key = "BackgroundColor";
				tmp = "BLACK";
				if(MainForm.settingsLst.ContainsKey(key))
					tmp = (string)MainForm.settingsLst[key];
				if(tmp.ToUpper() == "BLACK")
					this.rdbBlack.Checked = true;
				else this.rdbWhite.Checked = true;
				//Show entity panel
				key = "ShowEntity";
				if(MainForm.settingsLst.ContainsKey(key))
					tmp = Convert.ToString(MainForm.settingsLst[key]);
				if(tmp.ToUpper() == "TRUE") 
					this.chbEnt.Checked = true;
				else
					this.chbEnt.Checked = false;
				//Color drawing
				key = "ColorDraw";
				if(MainForm.settingsLst.ContainsKey(key))
					tmp = Convert.ToString(MainForm.settingsLst[key]);
				if(tmp.ToUpper() == "TRUE") 
					this.rdColorDraw.Checked = true;
				else this.rdDrawBlack.Checked = true;
			}
		}

		private void SelectPath_Click(object sender, System.EventArgs e)
		{
			fldBrow.ShowDialog();
			if(Directory.Exists(fldBrow.SelectedPath))
			{
				tbLnPath.Text = fldBrow.SelectedPath;
				MultipleLanguage.path = fldBrow.SelectedPath;
			}
		}

		private void btClose_Click(object sender, System.EventArgs e)
		{
			MultipleLanguage.path = this.old_path;
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void Ok_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			//BackgroundColor
			string key = "BackgroundColor";
			if(MainForm.settingsLst.ContainsKey(key))
			{
				if(this.rdbBlack.Checked)
					MainForm.settingsLst[key] = "Black";
				else MainForm.settingsLst[key] = "White";
			}
			//Show entity panel
			key = "ShowEntity";
			if(MainForm.settingsLst.ContainsKey(key))
				MainForm.settingsLst[key] = this.chbEnt.Checked;
			//Color drawing
			key = "ColorDraw";
			if(MainForm.settingsLst.ContainsKey(key))
				MainForm.settingsLst[key] = this.rdColorDraw.Checked;
			string tmp = this.tbLnPath.Text.Trim();
			//Language path
			key = "LanguagePath";
			if(Directory.Exists(tmp))
				MainForm.settingsLst[key] = tmp;
			//Language
			key = "Language";
			int cn = this.cbLang.SelectedIndex;
			if(MainForm.settingsLst.ContainsKey(key))
				if(cn > -1)
					MainForm.settingsLst[key] = this.cbLang.Items[cn] + ".lng";
			//Language ID
			key = "LanguageID";
			if(this.cbLang.SelectedIndex >= 0)
				MainForm.settingsLst[key] = this.cbLang.SelectedIndex;
			this.Close();
		}

		private void btDefPath_Click(object sender, System.EventArgs e)
		{
			MultipleLanguage.path = MainForm.cnstLngPath;
			tbLnPath.Text = MultipleLanguage.path;
		}

		private void CurrentPath_Click(object sender, System.EventArgs e)
		{
			string tmp = Application.StartupPath;
			MultipleLanguage.path = tmp;
			tbLnPath.Text = tmp;
		}

		private void ReloadPath_Click(object sender, System.EventArgs e)
		{
			MultipleLanguage.lngList.Clear();
			MainForm.actForm.ReloadLNG();
			this.cbLang.Items.Clear();
			string tmp;
			for(int i = 0; i < MultipleLanguage.languagesList.Length; i++)
			{
				tmp = MultipleLanguage.languagesList[i];
				this.cbLang.Items.Add(tmp);
				if(MultipleLanguage.language.ToUpper() == tmp.ToUpper())
					this.cbLang.SelectedIndex = i;
			}
		}
	}
}
