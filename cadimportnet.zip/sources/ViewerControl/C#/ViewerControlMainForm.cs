using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CADImportFaceModule;
using CADImportForm;
using CADImportControlModule;


namespace CADImportForm
{
	#region Help
	/// <summary>
	/// Represents the main application form in which a <B>CADImportControl</B> is used for viewing CAD files.
	/// </summary>
	#endregion Help
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem mFile;
		private System.Windows.Forms.MenuItem mOpenFile;
		private System.Windows.Forms.MenuItem mSaveFile;
		private System.Windows.Forms.MenuItem printMenuItem;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem mExit;
		private System.Windows.Forms.MenuItem editMenuItem;
		private System.Windows.Forms.MenuItem copyMenuItem;
		private System.Windows.Forms.MenuItem mView;
		private System.Windows.Forms.MenuItem toolMenuItem;
		private System.Windows.Forms.MenuItem entitiesMenuItem;
		private System.Windows.Forms.MenuItem menuItem24;
		private System.Windows.Forms.MenuItem zoomInMenuItem;
		private System.Windows.Forms.MenuItem zoomOutMenuItem;
		private System.Windows.Forms.MenuItem mScale;
		private System.Windows.Forms.MenuItem zoom10MenuItem;
		private System.Windows.Forms.MenuItem zoom25MenuItem;
		private System.Windows.Forms.MenuItem zoom50MenuItem;
		private System.Windows.Forms.MenuItem zoom100MenuItem;
		private System.Windows.Forms.MenuItem zoom200MenuItem;
		private System.Windows.Forms.MenuItem zoom400MenuItem;
		private System.Windows.Forms.MenuItem zoom800MenuItem;
		private System.Windows.Forms.MenuItem fitMenuItem;
		private System.Windows.Forms.MenuItem menuItem29;
		private System.Windows.Forms.MenuItem shxMenuItem;
		private System.Windows.Forms.MenuItem cADFilesMenuItem;
		private System.Windows.Forms.MenuItem colorMenuItem;
		private System.Windows.Forms.MenuItem blackMenuItem;
		private System.Windows.Forms.MenuItem whiteBackMenuItem;
		private System.Windows.Forms.MenuItem blackBackMenuItem;
		private System.Windows.Forms.MenuItem changeBackMenuItem;
		private System.Windows.Forms.MenuItem menuItem38;
		private System.Windows.Forms.MenuItem showLineWightMenuItem;
		private System.Windows.Forms.MenuItem arcsSplitMenuItem;
		private System.Windows.Forms.MenuItem dimShowMenuItem;
		private System.Windows.Forms.MenuItem textsShowMenuItem;
		private System.Windows.Forms.MenuItem menuItem43;
		private System.Windows.Forms.MenuItem layersShowMenuItem;
		private System.Windows.Forms.MenuItem helpMenuItem;
		private System.Windows.Forms.MenuItem menuItemReg;
		private System.Windows.Forms.MenuItem aboutMenuItem;
		private CADImportControl cadImportControl1;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MenuItem menuItem1;
		internal static MainForm actForm;
		//multy languages
		internal MultipleLanguage mlng;
		private int curLngInd = 0;
		//save options
		private bool colorDraw;
		private SaveSettings svSet;
		internal static SortedList settingsLst;
		private readonly string fileSettingsName = Application.StartupPath + @"\Settings.txt";
		private string lngFile;
		private System.Windows.Forms.MenuItem mnSaveDXF;
		private System.Windows.Forms.SaveFileDialog saveDXFDlg;
		private System.Windows.Forms.MenuItem miFloatLic;
		#region Help
		/// <summary>
		/// A <B>string</B> containing a name of the default directory where to search for the files of language support.
		/// </summary>
		#endregion Help
		public static readonly string cnstLngPath = @".\Languages";

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="CADImportForm.MainForm">MainForm</see> class.
		/// </summary>
		#endregion Help
		public MainForm()
		{
			InitializeComponent();
			#region protect
#if ((! floatprotect) && protect)
				this.miFloatLic.Enabled = false;
#endif
			#endregion
			mlng = new MultipleLanguage(this.GetType());
			//Save value of NoName elements for MainForm
			if(this.mainMenu != null)
				mlng.SaveNameMenuItem(this.mainMenu.MenuItems);
			MultipleLanguage.path = Application.StartupPath;
			//mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			//Load settings
			svSet = new SaveSettings(this.fileSettingsName);
			settingsLst = svSet.LoadOptions();
			if(settingsLst != null)
			{
				string key = "LanguagePath";
				if(settingsLst.ContainsKey(key))
					MultipleLanguage.path = Convert.ToString(settingsLst[key]);
			} 
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			if(settingsLst == null)
				CreateNewSettingsList();
			else
				SetSettings();
		}

		private void SelectLanguage()
		{
			for(int i = 0; i < this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count; i++)
				if(this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[i].Text == "English")
				{
					this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[i].Checked = true;
					curLngInd = i;
					break;
				}
		}

		private void LanguageSelect_Click(object sender, System.EventArgs e)
		{
			if(!(sender is MenuItem))
				return;
			MenuItem mn = (sender as MenuItem);
			curLngInd = (byte)mn.Index;
			lngFile = mn.Text + ".lng"; 
			cadImportControl1.SetLNG(lngFile);
			//MainForm Menu
			mlng.RestoreLanguage(this.Controls, this.Menu);
			this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Clear();
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
			if(this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count > this.curLngInd)
				this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[this.curLngInd].Checked = true;
			this.Text = "CADImport.Net Demo";
			this.Text = mlng.SetLanguage(this.Controls, this.Menu, this.Text);
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.mFile = new System.Windows.Forms.MenuItem();
			this.mOpenFile = new System.Windows.Forms.MenuItem();
			this.mnSaveDXF = new System.Windows.Forms.MenuItem();
			this.mSaveFile = new System.Windows.Forms.MenuItem();
			this.printMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mExit = new System.Windows.Forms.MenuItem();
			this.editMenuItem = new System.Windows.Forms.MenuItem();
			this.copyMenuItem = new System.Windows.Forms.MenuItem();
			this.mView = new System.Windows.Forms.MenuItem();
			this.toolMenuItem = new System.Windows.Forms.MenuItem();
			this.entitiesMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem24 = new System.Windows.Forms.MenuItem();
			this.zoomInMenuItem = new System.Windows.Forms.MenuItem();
			this.zoomOutMenuItem = new System.Windows.Forms.MenuItem();
			this.mScale = new System.Windows.Forms.MenuItem();
			this.zoom10MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom25MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom50MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom100MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom200MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom400MenuItem = new System.Windows.Forms.MenuItem();
			this.zoom800MenuItem = new System.Windows.Forms.MenuItem();
			this.fitMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem29 = new System.Windows.Forms.MenuItem();
			this.shxMenuItem = new System.Windows.Forms.MenuItem();
			this.cADFilesMenuItem = new System.Windows.Forms.MenuItem();
			this.colorMenuItem = new System.Windows.Forms.MenuItem();
			this.blackMenuItem = new System.Windows.Forms.MenuItem();
			this.whiteBackMenuItem = new System.Windows.Forms.MenuItem();
			this.blackBackMenuItem = new System.Windows.Forms.MenuItem();
			this.changeBackMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem38 = new System.Windows.Forms.MenuItem();
			this.showLineWightMenuItem = new System.Windows.Forms.MenuItem();
			this.arcsSplitMenuItem = new System.Windows.Forms.MenuItem();
			this.dimShowMenuItem = new System.Windows.Forms.MenuItem();
			this.textsShowMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem43 = new System.Windows.Forms.MenuItem();
			this.layersShowMenuItem = new System.Windows.Forms.MenuItem();
			this.helpMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemReg = new System.Windows.Forms.MenuItem();
			this.aboutMenuItem = new System.Windows.Forms.MenuItem();
			this.cadImportControl1 = new CADImportControlModule.CADImportControl();
			this.saveDXFDlg = new System.Windows.Forms.SaveFileDialog();
			this.miFloatLic = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mFile,
																					 this.editMenuItem,
																					 this.mView,
																					 this.cADFilesMenuItem,
																					 this.helpMenuItem});
			// 
			// mFile
			// 
			this.mFile.Index = 0;
			this.mFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mOpenFile,
																				  this.mnSaveDXF,
																				  this.mSaveFile,
																				  this.printMenuItem,
																				  this.menuItem2,
																				  this.mExit});
			this.mFile.Text = "&File";
			// 
			// mOpenFile
			// 
			this.mOpenFile.Index = 0;
			this.mOpenFile.Text = "Open Picture...";
			this.mOpenFile.Click += new System.EventHandler(this.mOpenFile_Click_1);
			// 
			// mnSaveDXF
			// 
			this.mnSaveDXF.Enabled = false;
			this.mnSaveDXF.Index = 1;
			this.mnSaveDXF.Text = "Save as DXF...";
			this.mnSaveDXF.Click += new System.EventHandler(this.mnSaveDXF_Click);
			// 
			// mSaveFile
			// 
			this.mSaveFile.Enabled = false;
			this.mSaveFile.Index = 2;
			this.mSaveFile.Text = "Save Picture...";
			this.mSaveFile.Click += new System.EventHandler(this.mSaveFile_Click_1);
			// 
			// printMenuItem
			// 
			this.printMenuItem.Enabled = false;
			this.printMenuItem.Index = 3;
			this.printMenuItem.Text = "Print";
			this.printMenuItem.Click += new System.EventHandler(this.printMenuItem_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 4;
			this.menuItem2.Text = "-";
			// 
			// mExit
			// 
			this.mExit.Index = 5;
			this.mExit.Text = "Close";
			this.mExit.Click += new System.EventHandler(this.mExit_Click);
			// 
			// editMenuItem
			// 
			this.editMenuItem.Index = 1;
			this.editMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.copyMenuItem});
			this.editMenuItem.Text = "&Edit";
			// 
			// copyMenuItem
			// 
			this.copyMenuItem.Enabled = false;
			this.copyMenuItem.Index = 0;
			this.copyMenuItem.Text = "Copy as BMP";
			this.copyMenuItem.Click += new System.EventHandler(this.copyMenuItem_Click);
			// 
			// mView
			// 
			this.mView.Index = 2;
			this.mView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.toolMenuItem,
																				  this.menuItem24,
																				  this.zoomInMenuItem,
																				  this.zoomOutMenuItem,
																				  this.mScale,
																				  this.fitMenuItem,
																				  this.menuItem29,
																				  this.shxMenuItem});
			this.mView.Text = "&View";
			// 
			// toolMenuItem
			// 
			this.toolMenuItem.Index = 0;
			this.toolMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.entitiesMenuItem});
			this.toolMenuItem.Text = "Show entities panel";
			// 
			// entitiesMenuItem
			// 
			this.entitiesMenuItem.Checked = true;
			this.entitiesMenuItem.Index = 0;
			this.entitiesMenuItem.Text = "Entities";
			this.entitiesMenuItem.Click += new System.EventHandler(this.entitiesMenuItem_Click);
			// 
			// menuItem24
			// 
			this.menuItem24.Index = 1;
			this.menuItem24.Text = "-";
			// 
			// zoomInMenuItem
			// 
			this.zoomInMenuItem.Enabled = false;
			this.zoomInMenuItem.Index = 2;
			this.zoomInMenuItem.Text = "Zoom In (+)";
			this.zoomInMenuItem.Click += new System.EventHandler(this.zoomInMenuItem_Click);
			// 
			// zoomOutMenuItem
			// 
			this.zoomOutMenuItem.Enabled = false;
			this.zoomOutMenuItem.Index = 3;
			this.zoomOutMenuItem.Text = "Zoom Out (-)";
			this.zoomOutMenuItem.Click += new System.EventHandler(this.zoomOutMenuItem_Click);
			// 
			// mScale
			// 
			this.mScale.Enabled = false;
			this.mScale.Index = 4;
			this.mScale.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.zoom10MenuItem,
																				   this.zoom25MenuItem,
																				   this.zoom50MenuItem,
																				   this.zoom100MenuItem,
																				   this.zoom200MenuItem,
																				   this.zoom400MenuItem,
																				   this.zoom800MenuItem});
			this.mScale.Text = "Scale";
			// 
			// zoom10MenuItem
			// 
			this.zoom10MenuItem.Index = 0;
			this.zoom10MenuItem.Text = "10%";
			this.zoom10MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom25MenuItem
			// 
			this.zoom25MenuItem.Index = 1;
			this.zoom25MenuItem.Text = "25%";
			this.zoom25MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom50MenuItem
			// 
			this.zoom50MenuItem.Index = 2;
			this.zoom50MenuItem.Text = "50%";
			this.zoom50MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom100MenuItem
			// 
			this.zoom100MenuItem.Index = 3;
			this.zoom100MenuItem.Text = "100%";
			this.zoom100MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom200MenuItem
			// 
			this.zoom200MenuItem.Index = 4;
			this.zoom200MenuItem.Text = "200%";
			this.zoom200MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom400MenuItem
			// 
			this.zoom400MenuItem.Index = 5;
			this.zoom400MenuItem.Text = "400%";
			this.zoom400MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// zoom800MenuItem
			// 
			this.zoom800MenuItem.Index = 6;
			this.zoom800MenuItem.Text = "800%";
			this.zoom800MenuItem.Click += new System.EventHandler(this.mScale_Click);
			// 
			// fitMenuItem
			// 
			this.fitMenuItem.Enabled = false;
			this.fitMenuItem.Index = 5;
			this.fitMenuItem.Text = "Fit drawing to window";
			this.fitMenuItem.Click += new System.EventHandler(this.fitMenuItem_Click);
			// 
			// menuItem29
			// 
			this.menuItem29.Index = 6;
			this.menuItem29.Text = "-";
			// 
			// shxMenuItem
			// 
			this.shxMenuItem.Index = 7;
			this.shxMenuItem.Text = "SHX Fonts";
			this.shxMenuItem.Click += new System.EventHandler(this.shxMenuItem_Click);
			// 
			// cADFilesMenuItem
			// 
			this.cADFilesMenuItem.Index = 3;
			this.cADFilesMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							 this.colorMenuItem,
																							 this.blackMenuItem,
																							 this.whiteBackMenuItem,
																							 this.blackBackMenuItem,
																							 this.changeBackMenuItem,
																							 this.menuItem38,
																							 this.showLineWightMenuItem,
																							 this.arcsSplitMenuItem,
																							 this.dimShowMenuItem,
																							 this.textsShowMenuItem,
																							 this.menuItem43,
																							 this.layersShowMenuItem});
			this.cADFilesMenuItem.Text = "&CAD files";
			// 
			// colorMenuItem
			// 
			this.colorMenuItem.Checked = true;
			this.colorMenuItem.Enabled = false;
			this.colorMenuItem.Index = 0;
			this.colorMenuItem.RadioCheck = true;
			this.colorMenuItem.Text = "Color drawing";
			this.colorMenuItem.Click += new System.EventHandler(this.colorMenuItem_Click);
			// 
			// blackMenuItem
			// 
			this.blackMenuItem.Enabled = false;
			this.blackMenuItem.Index = 1;
			this.blackMenuItem.RadioCheck = true;
			this.blackMenuItem.Text = "Black drawing";
			this.blackMenuItem.Click += new System.EventHandler(this.blackMenuItem_Click);
			// 
			// whiteBackMenuItem
			// 
			this.whiteBackMenuItem.Enabled = false;
			this.whiteBackMenuItem.Index = 2;
			this.whiteBackMenuItem.RadioCheck = true;
			this.whiteBackMenuItem.Text = "White Background";
			this.whiteBackMenuItem.Click += new System.EventHandler(this.whiteBackMenuItem_Click);
			// 
			// blackBackMenuItem
			// 
			this.blackBackMenuItem.Enabled = false;
			this.blackBackMenuItem.Index = 3;
			this.blackBackMenuItem.RadioCheck = true;
			this.blackBackMenuItem.Text = "Black Background";
			this.blackBackMenuItem.Click += new System.EventHandler(this.blackBackMenuItem_Click);
			// 
			// changeBackMenuItem
			// 
			this.changeBackMenuItem.Enabled = false;
			this.changeBackMenuItem.Index = 4;
			this.changeBackMenuItem.Text = "Change Background Color";
			this.changeBackMenuItem.Click += new System.EventHandler(this.changeBackMenuItem_Click);
			// 
			// menuItem38
			// 
			this.menuItem38.Index = 5;
			this.menuItem38.Text = "-";
			// 
			// showLineWightMenuItem
			// 
			this.showLineWightMenuItem.Checked = true;
			this.showLineWightMenuItem.Enabled = false;
			this.showLineWightMenuItem.Index = 6;
			this.showLineWightMenuItem.Text = "Show lineweight";
			this.showLineWightMenuItem.Click += new System.EventHandler(this.showLineWightMenuItem_Click);
			// 
			// arcsSplitMenuItem
			// 
			this.arcsSplitMenuItem.Checked = true;
			this.arcsSplitMenuItem.Enabled = false;
			this.arcsSplitMenuItem.Index = 7;
			this.arcsSplitMenuItem.Text = "Arcs Splitted";
			this.arcsSplitMenuItem.Click += new System.EventHandler(this.arcsSplitMenuItem_Click);
			// 
			// dimShowMenuItem
			// 
			this.dimShowMenuItem.Checked = true;
			this.dimShowMenuItem.Enabled = false;
			this.dimShowMenuItem.Index = 8;
			this.dimShowMenuItem.Text = "Dimensions Show";
			this.dimShowMenuItem.Click += new System.EventHandler(this.dimShowMenuItem_Click);
			// 
			// textsShowMenuItem
			// 
			this.textsShowMenuItem.Checked = true;
			this.textsShowMenuItem.Enabled = false;
			this.textsShowMenuItem.Index = 9;
			this.textsShowMenuItem.Text = "Texts Show";
			this.textsShowMenuItem.Click += new System.EventHandler(this.textsShowMenuItem_Click);
			// 
			// menuItem43
			// 
			this.menuItem43.Index = 10;
			this.menuItem43.Text = "-";
			// 
			// layersShowMenuItem
			// 
			this.layersShowMenuItem.Enabled = false;
			this.layersShowMenuItem.Index = 11;
			this.layersShowMenuItem.Text = "Show Layers";
			this.layersShowMenuItem.Click += new System.EventHandler(this.layersShowMenuItem_Click);
			// 
			// helpMenuItem
			// 
			this.helpMenuItem.Index = 4;
			this.helpMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem1,
																						 this.menuItemReg,
																						 this.miFloatLic,
																						 this.aboutMenuItem});
			this.helpMenuItem.Text = "&?";
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Language";
			// 
			// menuItemReg
			// 
			this.menuItemReg.Index = 1;
			this.menuItemReg.Text = "Register";
			this.menuItemReg.Click += new System.EventHandler(this.menuItemReg_Click);
			// 
			// aboutMenuItem
			// 
			this.aboutMenuItem.Index = 3;
			this.aboutMenuItem.Text = "About...";
			this.aboutMenuItem.Click += new System.EventHandler(this.aboutMenuItem_Click);
			// 
			// cadImportControl1
			// 
			this.cadImportControl1.CADImage = null;
			this.cadImportControl1.Deactiv = false;
			this.cadImportControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.cadImportControl1.EntitiesTreeVisible = true;
			this.cadImportControl1.FileName = "";
			this.cadImportControl1.LayoutsPanelVisible = true;
			this.cadImportControl1.Location = new System.Drawing.Point(0, 0);
			this.cadImportControl1.Name = "cadImportControl1";
			this.cadImportControl1.Position = ((System.Drawing.PointF)(resources.GetObject("cadImportControl1.Position")));
			this.cadImportControl1.Scaling = 1F;
			this.cadImportControl1.Size = new System.Drawing.Size(720, 403);
			this.cadImportControl1.TabIndex = 0;
			this.cadImportControl1.ToolsVisible = true;
			this.cadImportControl1.UseZoomRect = true;
			// 
			// saveDXFDlg
			// 
			this.saveDXFDlg.DefaultExt = "*.dxf";
			this.saveDXFDlg.Filter = "*.dxf|*.dxf";
			// 
			// miFloatLic
			// 
			this.miFloatLic.Index = 2;
			this.miFloatLic.Text = "Floating License Registration...";
			this.miFloatLic.Click += new System.EventHandler(this.miFloatLic_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(720, 403);
			this.Controls.Add(this.cadImportControl1);
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Viewer";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.Closed += new System.EventHandler(this.MainForm_Closed);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			actForm = new MainForm();
			Application.Run(actForm);
		}

		#region Help
		/// <summary>
		/// Processes Windows messages and allows the user to zoom in(out) the CAD image by mouse wheel.
		/// </summary>
		/// <param name="m">The Windows <see cref="System.Windows.Forms.Message">Message</see> to process.</param>
		#endregion Help
		protected override void WndProc(ref Message m)
		{
			if(m.Msg == 0x0112)
			{
				if(m.WParam.ToInt32() == 0xF020)
					cadImportControl1.Deactiv = true;
			}
			base.WndProc(ref m);
		}

		private void menuItemAbout_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.About();
		}

		private void mScale_Click(object sender, System.EventArgs e)
		{
			if(cadImportControl1.CADImage == null) return;
			float i = cadImportControl1.Scaling;
			switch((sender as MenuItem).Index)
			{
				case 0:
					i = 0.1f;
					break;
				case 1:
					i = 0.25f;
					break;
				case 2:
					i = 0.5f;
					break;
				case 3:
					i = 1;
					break;
				case 4:
					i = 2;
					break;
				case 5:
					i = 4;
					break;
				case 6:
					i = 8;
					break;
			}
			cadImportControl1.ResetScaling();
			cadImportControl1.Scaling = i;
			cadImportControl1.RefreshImage();
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			#region protect
			#if protect
			this.cadImportControl1.Register();
			#endif
			#endregion protect
			EnableButton(true);
		}

		#region Help
		/// <summary>
		/// Enables or disables buttons of the toolbar and menu items of the main menu.
		/// </summary>
		/// <param name="aVal"><b>true</b> if to enable the buttons and menu items; <b>false</b> if to disable them.</param>
		/// <remarks>The buttons and menu items are enabled after loading a CAD file and become disabled after closing the file.</remarks>
		#endregion Help
		public void EnableButton(bool aVal)
		{
			mScale.Enabled = aVal;
			mSaveFile.Enabled = aVal;
			copyMenuItem.Enabled = aVal;
			zoomInMenuItem.Enabled = aVal;
			zoomOutMenuItem.Enabled = aVal;
			fitMenuItem.Enabled = aVal;
			colorMenuItem.Enabled = aVal;
			blackMenuItem.Enabled = aVal;
			whiteBackMenuItem.Enabled = aVal;
			blackBackMenuItem.Enabled = aVal;
			changeBackMenuItem.Enabled = aVal;
			showLineWightMenuItem.Enabled = aVal;
			arcsSplitMenuItem.Enabled = aVal;
			dimShowMenuItem.Enabled = aVal;
			textsShowMenuItem.Enabled = aVal;
			layersShowMenuItem.Enabled = aVal;
			printMenuItem.Enabled = aVal;
			#region Export
			#if Export
			this.mnSaveDXF.Enabled = aVal;
			#endif
			#endregion
		}

		private void MainForm_Closed(object sender, System.EventArgs e)
		{
			#region protect
			#if protect
			this.cadImportControl1.Unregister();
			#endif
			#endregion
		}

		private void mOpenFile_Click_1(object sender, System.EventArgs e)
		{
			cadImportControl1.LoadFile(true);
		}

		private void mSaveFile_Click_1(object sender, System.EventArgs e)
		{
			cadImportControl1.SaveAsImage();
		}

		private void printMenuItem_Click(object sender, System.EventArgs e)
		{
			if(cadImportControl1.CADImage == null) 
				return;
			cadImportControl1.CADImage.Print(true, true);
		}

		private void copyMenuItem_Click(object sender, System.EventArgs e)
		{
			if(cadImportControl1.CADImage == null) 
			 return;
			CADImport.DRect tmpRect = new CADImport.DRect(0, 0, cadImportControl1.ClientRectangle.Width*cadImportControl1.Scaling, cadImportControl1.ClientRectangle.Height*cadImportControl1.Scaling);
			cadImportControl1.CADImage.SaveImageToClipboard(tmpRect);
		}

		private void entitiesMenuItem_Click(object sender, System.EventArgs e)
		{
			entitiesMenuItem.Checked = !entitiesMenuItem.Checked;
			cadImportControl1.EntitiesTreeVisible = entitiesMenuItem.Checked;
			cadImportControl1.DoResize();
		}

		private void mExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void menuItemReg_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.ShowRegForm();
		}

		private void aboutMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.About();
		}

		private void fitMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.ResetScaling();
		}

		private void zoomInMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.DoZoomIn();
		}

		private void zoomOutMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.DoZoomOut();
		}

		private void shxMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.AddSHXPaths();
		}

		private void colorMenuItem_Click(object sender, System.EventArgs e)
		{
			colorMenuItem.Checked = true;
			blackMenuItem.Checked = false;
			cadImportControl1.DoNormalColor();
		}

		private void blackMenuItem_Click(object sender, System.EventArgs e)
		{
			colorMenuItem.Checked = false;
			blackMenuItem.Checked = true;
			cadImportControl1.DoBlackColor();
		}

		private void whiteBackMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.White_Click();
		}

		private void blackBackMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.Black_Click();
		}

		private void changeBackMenuItem_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.Color_Click();
		}

		private void showLineWightMenuItem_Click(object sender, System.EventArgs e)
		{
			if(cadImportControl1.CADImage == null) return;
			showLineWightMenuItem.Checked = !showLineWightMenuItem.Checked;
			cadImportControl1.CADImage.IsShowLineWeight = showLineWightMenuItem.Checked;
			cadImportControl1.Refresh();
		}

		private void arcsSplitMenuItem_Click(object sender, System.EventArgs e)
		{
			arcsSplitMenuItem.Checked = !arcsSplitMenuItem.Checked;
			cadImportControl1.UseWinEllipse();
		}

		private void dimShowMenuItem_Click(object sender, System.EventArgs e)
		{
			dimShowMenuItem.Checked = !dimShowMenuItem.Checked;
			cadImportControl1.ChangeDimensionsVisiblity();
		}

		private void textsShowMenuItem_Click(object sender, System.EventArgs e)
		{
			textsShowMenuItem.Checked = !textsShowMenuItem.Checked;
			cadImportControl1.ChangeTextsVisiblity();
		}

		private void layersShowMenuItem_Click(object sender, System.EventArgs e)
		{
			if(cadImportControl1.CADImage == null) 
				return;
			cadImportControl1.ShowLayersForm();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			cadImportControl1.SetLNG("�������.lng");
		}

		private void CreateNewSettingsList()
		{
			string tmp; 
			settingsLst = new SortedList();
			//Language path
			settingsLst.Add("LanguagePath", MultipleLanguage.path);
			//Language
			settingsLst.Add("Language", lngFile);
			//Language ID
			settingsLst.Add("LanguageID", this.curLngInd);
			//BackgroundColor
			if(cadImportControl1.CADPictureBox.BackColor == Color.Black)
				tmp = "Black";
			else tmp = "White";
			settingsLst.Add("BackgroundColor", tmp);
			//Show entity panel
			settingsLst.Add("ShowEntity", cadImportControl1.EntitiesTreeVisible);
			//Color drawing
			settingsLst.Add("ColorDraw", this.colorDraw);
			//SHXPathCount
			int cn = cadImportControl1.shxFrm.lstDir.Items.Count;
			settingsLst.Add("SHXPathCount", cadImportControl1.shxFrm.lstDir.Items.Count);
			//SHXPaths
			for(int i = 0; i < cn; i++)
			{
				settingsLst.Add("SHXPath_" + (i + 1), cadImportControl1.shxFrm.lstDir.Items[i]);
			}
			this.cadImportControl1.NewProtectionSettings(settingsLst);
		}

		//set loads settings
		internal void SetSettings()
		{
			if(settingsLst == null)
				return;
			string tmp;
			int cn = 0;
			//Language path
			string key = "LanguagePath";
			if(settingsLst.ContainsKey(key))
				MultipleLanguage.path = Convert.ToString(settingsLst[key]);
			//Language
			key = "Language";
			if(settingsLst.ContainsKey(key))
				lngFile = (string)settingsLst[key];
			mlng.LoadLNG(lngFile);
			cadImportControl1.SetLNG(lngFile);
			this.Text = mlng.SetLanguage(this.Controls, this.Menu, this.Text);
			//Language ID
			key = "LanguageID";
			if(settingsLst.ContainsKey(key))
			{
				this.curLngInd = Convert.ToByte(settingsLst[key]);
				if(this.mainMenu.MenuItems[4].MenuItems[0].MenuItems.Count > this.curLngInd)
					this.mainMenu.MenuItems[4].MenuItems[0].MenuItems[this.curLngInd].Checked = true;
			}
			//BackgroundColor
			key = "BackgroundColor";
			tmp = "BLACK";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "BLACK")
				this.cadImportControl1.Black_Click();
			else this.cadImportControl1.White_Click();
			//Show entity panel
			key = "ShowEntity";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "TRUE") 
			{
				this.entitiesMenuItem.Checked = true;
				this.cadImportControl1.EntitiesTreeVisible = true;
			}
			else
			{
				this.entitiesMenuItem.Checked = false;
				this.cadImportControl1.EntitiesTreeVisible = false;
			}
			//Color drawing
			key = "ColorDraw";
			if(settingsLst.ContainsKey(key))
				tmp = Convert.ToString(settingsLst[key]);
			if(tmp.ToUpper() == "TRUE") 
				this.colorDraw = true;
			else this.colorDraw = false;
			//SHXPathCount
			key = "SHXPathCount";
			if(settingsLst.ContainsKey(key))
				cn = Convert.ToInt32(settingsLst[key]);
			//SHXPaths
			for(int i = 0; i < cn; i++)
			{
				key = "SHXPath_" + (i + 1);
				if(settingsLst.ContainsKey(key))
					this.cadImportControl1.shxFrm.AddPath(Convert.ToString(settingsLst[key]));
			}
			//First start
			key = "Install";
			if(settingsLst.ContainsKey(key))
			{
				if(CADImport.CADConst.SearchSHXPaths)
				{
					this.cadImportControl1.shxFrm.lstDir.Items.Clear();
					this.cadImportControl1.shxFrm.lstPath.Clear();
					ArrayList vPaths = new ArrayList();
					CADImport.CADConst.FindAutoCADSHXPaths(vPaths);
					for(int i = 0; i < vPaths.Count; i++)
					{
						tmp = (string)vPaths[i];
						this.cadImportControl1.shxFrm.lstDir.Items.Add(tmp);
						this.cadImportControl1.shxFrm.lstPath.Add(tmp, "");
						CADImport.CADConst.SHXSearchPaths += CADImport.CADConst.SHXSearchPaths + tmp + ";";
					}
				}
			}
			this.cadImportControl1.SaveProtectionSettings(settingsLst);
		}

		internal void ReloadLNG()
		{
			mlng.LoadLngFileList(this.mainMenu.MenuItems[4].MenuItems[0], new System.EventHandler(LanguageSelect_Click));
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			CreateNewSettingsList();
			svSet.SaveOptions(settingsLst);
		}

		private void mnSaveDXF_Click(object sender, System.EventArgs e)
		{
			if(this.cadImportControl1.CADImage == null) return;
			if(this.saveDXFDlg.ShowDialog() != DialogResult.OK) return;
			this.cadImportControl1.SaveAsDXF(this.saveDXFDlg.FileName);
		}

		private void button1_Click_1(object sender, System.EventArgs e)
		{
			this.cadImportControl1.LayoutsPanelVisible = ! this.cadImportControl1.LayoutsPanelVisible;
		}

		private void miFloatLic_Click(object sender, System.EventArgs e)
		{
			this.cadImportControl1.ShowFloatRegForm();
		}
	}
}
