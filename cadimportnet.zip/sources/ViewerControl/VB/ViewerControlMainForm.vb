Imports CADImportControlModule
Imports CADImportFaceModule
Imports CADImport
Public Class MainForm
    Inherits System.Windows.Forms.Form

    'multy languages
    Friend mlng As MultipleLanguage
    Private curLngInd As Integer = 0
    'save options
    Private colorDraw As Boolean
    Private svSet As SaveSettings
    Friend Shared settingsLst As SortedList
    Private ReadOnly fileSettingsName As String = Application.StartupPath + "\Settings.txt"
    Private lngFile As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()

#If ((Not floatprotect) And protect) Then
        Me.miFloatLic.Enabled = False
#End If
        'Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents mFile As System.Windows.Forms.MenuItem
    Friend WithEvents mOpenFile As System.Windows.Forms.MenuItem
    Friend WithEvents mSaveFile As System.Windows.Forms.MenuItem
    Friend WithEvents printMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mExit As System.Windows.Forms.MenuItem
    Friend WithEvents editMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents copyMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mView As System.Windows.Forms.MenuItem
    Friend WithEvents toolMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents entitiesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents zoomInMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoomOutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mScale As System.Windows.Forms.MenuItem
    Friend WithEvents zoom10MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom25MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom50MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom100MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom200MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom400MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents zoom800MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem29 As System.Windows.Forms.MenuItem
    Friend WithEvents shxMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents cADFilesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents colorMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents blackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents whiteBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents blackBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents changeBackMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem38 As System.Windows.Forms.MenuItem
    Friend WithEvents showLineWightMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents arcsSplitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents dimShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents textsShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem43 As System.Windows.Forms.MenuItem
    Friend WithEvents layersShowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents helpMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItemReg As System.Windows.Forms.MenuItem
    Friend WithEvents aboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents CadImportControl1 As CADImportControl
    Friend WithEvents mnSaveAsDXF As System.Windows.Forms.MenuItem
    Friend WithEvents saveDXFDlg As System.Windows.Forms.SaveFileDialog
    Friend WithEvents miFloatLic As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.mainMenu = New System.Windows.Forms.MainMenu
        Me.mFile = New System.Windows.Forms.MenuItem
        Me.mOpenFile = New System.Windows.Forms.MenuItem
        Me.mSaveFile = New System.Windows.Forms.MenuItem
        Me.mnSaveAsDXF = New System.Windows.Forms.MenuItem
        Me.printMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.mExit = New System.Windows.Forms.MenuItem
        Me.editMenuItem = New System.Windows.Forms.MenuItem
        Me.copyMenuItem = New System.Windows.Forms.MenuItem
        Me.mView = New System.Windows.Forms.MenuItem
        Me.toolMenuItem = New System.Windows.Forms.MenuItem
        Me.entitiesMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem24 = New System.Windows.Forms.MenuItem
        Me.zoomInMenuItem = New System.Windows.Forms.MenuItem
        Me.zoomOutMenuItem = New System.Windows.Forms.MenuItem
        Me.mScale = New System.Windows.Forms.MenuItem
        Me.zoom10MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom25MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom50MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom100MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom200MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom400MenuItem = New System.Windows.Forms.MenuItem
        Me.zoom800MenuItem = New System.Windows.Forms.MenuItem
        Me.fitMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem29 = New System.Windows.Forms.MenuItem
        Me.shxMenuItem = New System.Windows.Forms.MenuItem
        Me.cADFilesMenuItem = New System.Windows.Forms.MenuItem
        Me.colorMenuItem = New System.Windows.Forms.MenuItem
        Me.blackMenuItem = New System.Windows.Forms.MenuItem
        Me.whiteBackMenuItem = New System.Windows.Forms.MenuItem
        Me.blackBackMenuItem = New System.Windows.Forms.MenuItem
        Me.changeBackMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem38 = New System.Windows.Forms.MenuItem
        Me.showLineWightMenuItem = New System.Windows.Forms.MenuItem
        Me.arcsSplitMenuItem = New System.Windows.Forms.MenuItem
        Me.dimShowMenuItem = New System.Windows.Forms.MenuItem
        Me.textsShowMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItem43 = New System.Windows.Forms.MenuItem
        Me.layersShowMenuItem = New System.Windows.Forms.MenuItem
        Me.helpMenuItem = New System.Windows.Forms.MenuItem
        Me.menuItemReg = New System.Windows.Forms.MenuItem
        Me.aboutMenuItem = New System.Windows.Forms.MenuItem
        Me.CadImportControl1 = New CADImportControlModule.CADImportControl
        Me.saveDXFDlg = New System.Windows.Forms.SaveFileDialog
        Me.miFloatLic = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFile, Me.editMenuItem, Me.mView, Me.cADFilesMenuItem, Me.helpMenuItem})
        '
        'mFile
        '
        Me.mFile.Index = 0
        Me.mFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mOpenFile, Me.mSaveFile, Me.mnSaveAsDXF, Me.printMenuItem, Me.menuItem2, Me.mExit})
        Me.mFile.Text = "&File"
        '
        'mOpenFile
        '
        Me.mOpenFile.Index = 0
        Me.mOpenFile.Text = "&Open File..."
        '
        'mSaveFile
        '
        Me.mSaveFile.Enabled = False
        Me.mSaveFile.Index = 1
        Me.mSaveFile.Text = "Save File As..."
        '
        'mnSaveAsDXF
        '
        Me.mnSaveAsDXF.Enabled = False
        Me.mnSaveAsDXF.Index = 2
        Me.mnSaveAsDXF.Text = "SaveAsDXF..."
        '
        'printMenuItem
        '
        Me.printMenuItem.Enabled = False
        Me.printMenuItem.Index = 3
        Me.printMenuItem.Text = "Print File"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 4
        Me.menuItem2.Text = "-"
        '
        'mExit
        '
        Me.mExit.Index = 5
        Me.mExit.Text = "&Exit"
        '
        'editMenuItem
        '
        Me.editMenuItem.Index = 1
        Me.editMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.copyMenuItem})
        Me.editMenuItem.Text = "&Edit"
        '
        'copyMenuItem
        '
        Me.copyMenuItem.Enabled = False
        Me.copyMenuItem.Index = 0
        Me.copyMenuItem.Text = "Copy as BMP"
        '
        'mView
        '
        Me.mView.Index = 2
        Me.mView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.toolMenuItem, Me.menuItem24, Me.zoomInMenuItem, Me.zoomOutMenuItem, Me.mScale, Me.fitMenuItem, Me.menuItem29, Me.shxMenuItem})
        Me.mView.Text = "&View"
        '
        'toolMenuItem
        '
        Me.toolMenuItem.Index = 0
        Me.toolMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.entitiesMenuItem})
        Me.toolMenuItem.Text = "Toolbars"
        '
        'entitiesMenuItem
        '
        Me.entitiesMenuItem.Checked = True
        Me.entitiesMenuItem.Index = 0
        Me.entitiesMenuItem.Text = "Entities"
        '
        'menuItem24
        '
        Me.menuItem24.Index = 1
        Me.menuItem24.Text = "-"
        '
        'zoomInMenuItem
        '
        Me.zoomInMenuItem.Enabled = False
        Me.zoomInMenuItem.Index = 2
        Me.zoomInMenuItem.Text = "Zoom In (+)"
        '
        'zoomOutMenuItem
        '
        Me.zoomOutMenuItem.Enabled = False
        Me.zoomOutMenuItem.Index = 3
        Me.zoomOutMenuItem.Text = "Zoom Out (-)"
        '
        'mScale
        '
        Me.mScale.Enabled = False
        Me.mScale.Index = 4
        Me.mScale.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.zoom10MenuItem, Me.zoom25MenuItem, Me.zoom50MenuItem, Me.zoom100MenuItem, Me.zoom200MenuItem, Me.zoom400MenuItem, Me.zoom800MenuItem})
        Me.mScale.Text = "&Scale"
        '
        'zoom10MenuItem
        '
        Me.zoom10MenuItem.Index = 0
        Me.zoom10MenuItem.Text = "10%"
        '
        'zoom25MenuItem
        '
        Me.zoom25MenuItem.Index = 1
        Me.zoom25MenuItem.Text = "25%"
        '
        'zoom50MenuItem
        '
        Me.zoom50MenuItem.Index = 2
        Me.zoom50MenuItem.Text = "50%"
        '
        'zoom100MenuItem
        '
        Me.zoom100MenuItem.Index = 3
        Me.zoom100MenuItem.Text = "100%"
        '
        'zoom200MenuItem
        '
        Me.zoom200MenuItem.Index = 4
        Me.zoom200MenuItem.Text = "200%"
        '
        'zoom400MenuItem
        '
        Me.zoom400MenuItem.Index = 5
        Me.zoom400MenuItem.Text = "400%"
        '
        'zoom800MenuItem
        '
        Me.zoom800MenuItem.Index = 6
        Me.zoom800MenuItem.Text = "800%"
        '
        'fitMenuItem
        '
        Me.fitMenuItem.Enabled = False
        Me.fitMenuItem.Index = 5
        Me.fitMenuItem.Text = "Fit To Window"
        '
        'menuItem29
        '
        Me.menuItem29.Index = 6
        Me.menuItem29.Text = "-"
        '
        'shxMenuItem
        '
        Me.shxMenuItem.Index = 7
        Me.shxMenuItem.Text = "SHX Fonts..."
        '
        'cADFilesMenuItem
        '
        Me.cADFilesMenuItem.Index = 3
        Me.cADFilesMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.colorMenuItem, Me.blackMenuItem, Me.whiteBackMenuItem, Me.blackBackMenuItem, Me.changeBackMenuItem, Me.menuItem38, Me.showLineWightMenuItem, Me.arcsSplitMenuItem, Me.dimShowMenuItem, Me.textsShowMenuItem, Me.menuItem43, Me.layersShowMenuItem})
        Me.cADFilesMenuItem.Text = "CAD files"
        '
        'colorMenuItem
        '
        Me.colorMenuItem.Checked = True
        Me.colorMenuItem.Enabled = False
        Me.colorMenuItem.Index = 0
        Me.colorMenuItem.RadioCheck = True
        Me.colorMenuItem.Text = "Color drawing"
        '
        'blackMenuItem
        '
        Me.blackMenuItem.Enabled = False
        Me.blackMenuItem.Index = 1
        Me.blackMenuItem.RadioCheck = True
        Me.blackMenuItem.Text = "Black drawing"
        '
        'whiteBackMenuItem
        '
        Me.whiteBackMenuItem.Enabled = False
        Me.whiteBackMenuItem.Index = 2
        Me.whiteBackMenuItem.RadioCheck = True
        Me.whiteBackMenuItem.Text = "White background"
        '
        'blackBackMenuItem
        '
        Me.blackBackMenuItem.Enabled = False
        Me.blackBackMenuItem.Index = 3
        Me.blackBackMenuItem.RadioCheck = True
        Me.blackBackMenuItem.Text = "Black background"
        '
        'changeBackMenuItem
        '
        Me.changeBackMenuItem.Enabled = False
        Me.changeBackMenuItem.Index = 4
        Me.changeBackMenuItem.Text = "Change background color"
        '
        'menuItem38
        '
        Me.menuItem38.Index = 5
        Me.menuItem38.Text = "-"
        '
        'showLineWightMenuItem
        '
        Me.showLineWightMenuItem.Checked = True
        Me.showLineWightMenuItem.Enabled = False
        Me.showLineWightMenuItem.Index = 6
        Me.showLineWightMenuItem.Text = "Show lineweight"
        '
        'arcsSplitMenuItem
        '
        Me.arcsSplitMenuItem.Checked = True
        Me.arcsSplitMenuItem.Enabled = False
        Me.arcsSplitMenuItem.Index = 7
        Me.arcsSplitMenuItem.Text = "Arcs Splitted"
        '
        'dimShowMenuItem
        '
        Me.dimShowMenuItem.Checked = True
        Me.dimShowMenuItem.Enabled = False
        Me.dimShowMenuItem.Index = 8
        Me.dimShowMenuItem.Text = "Dimensions Show"
        '
        'textsShowMenuItem
        '
        Me.textsShowMenuItem.Checked = True
        Me.textsShowMenuItem.Enabled = False
        Me.textsShowMenuItem.Index = 9
        Me.textsShowMenuItem.Text = "Texts Show"
        '
        'menuItem43
        '
        Me.menuItem43.Index = 10
        Me.menuItem43.Text = "-"
        '
        'layersShowMenuItem
        '
        Me.layersShowMenuItem.Enabled = False
        Me.layersShowMenuItem.Index = 11
        Me.layersShowMenuItem.Text = "Show layers"
        '
        'helpMenuItem
        '
        Me.helpMenuItem.Index = 4
        Me.helpMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItemReg, Me.miFloatLic, Me.aboutMenuItem})
        Me.helpMenuItem.Text = "&?"
        '
        'menuItemReg
        '
        Me.menuItemReg.Index = 0
        Me.menuItemReg.Text = "Register"
        '
        'aboutMenuItem
        '
        Me.aboutMenuItem.Index = 2
        Me.aboutMenuItem.Text = "About"
        '
        'CadImportControl1
        '
        Me.CadImportControl1.CADImage = Nothing
        Me.CadImportControl1.Deactiv = False
        Me.CadImportControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CadImportControl1.EntitiesTreeVisible = True
        Me.CadImportControl1.FileName = ""
        Me.CadImportControl1.LayoutsPanelVisible = True
        Me.CadImportControl1.Location = New System.Drawing.Point(0, 0)
        Me.CadImportControl1.Name = "CadImportControl1"
        Me.CadImportControl1.Position = CType(resources.GetObject("CadImportControl1.Position"), System.Drawing.PointF)
        Me.CadImportControl1.Scaling = 1.0!
        Me.CadImportControl1.Size = New System.Drawing.Size(704, 435)
        Me.CadImportControl1.TabIndex = 0
        Me.CadImportControl1.ToolsVisible = True
        Me.CadImportControl1.UseZoomRect = True
        '
        'saveDXFDlg
        '
        Me.saveDXFDlg.DefaultExt = "*.dxf"
        Me.saveDXFDlg.Filter = "*.dxf|*.dxf"
        '
        'miFloatLic
        '
        Me.miFloatLic.Index = 1
        Me.miFloatLic.Text = "Floating License Registration..."
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 435)
        Me.Controls.Add(Me.CadImportControl1)
        Me.Menu = Me.mainMenu
        Me.Name = "MainForm"
        Me.Text = "Viewer"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    <System.STAThread()> _
         Public Shared Sub Main()
        Application.EnableVisualStyles()
        Application.DoEvents()
        Application.Run(New MainForm)
    End Sub

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        EnableButton(True)
        'options and language 
        mlng = New MultipleLanguage(Me.GetType())
        'Save value of NoName elements for MainForm
        If (Not (Me.mainMenu Is Nothing)) Then _
            mlng.SaveNameMenuItem(Me.mainMenu.MenuItems)
        MultipleLanguage.path = Application.StartupPath
        'Load settings
        svSet = New SaveSettings(Me.fileSettingsName)
        settingsLst = svSet.LoadOptions()
        If (Not (settingsLst Is Nothing)) Then
            Dim key As String = "LanguagePath"
            If (settingsLst.ContainsKey(key)) Then _
                MultipleLanguage.path = Convert.ToString(settingsLst(key))
        End If
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), AddressOf LanguageSelect_Click)
        If (settingsLst Is Nothing) Then
            CreateNewSettingsList()
        Else
            SetSettings()
        End If
#If protect Then
        Me.CadImportControl1.Register()
#End If
    End Sub

    Friend Sub SetSettings()
        If (Not settingsLst Is Nothing) Then
            Dim num1 As Integer = 0
            Dim text2 As String = "LanguagePath"
            If settingsLst.ContainsKey(text2) Then
                MultipleLanguage.path = Convert.ToString(settingsLst.Item(text2))
            End If
            text2 = "Language"
            If settingsLst.ContainsKey(text2) Then
                Me.lngFile = CStr(settingsLst.Item(text2))
            End If
            Me.mlng.LoadLNG(Me.lngFile)
            Me.CadImportControl1.SetLNG(Me.lngFile)
            Me.Text = Me.mlng.SetLanguage(MyBase.Controls, MyBase.Menu, Me.Text)
            text2 = "LanguageID"
            If settingsLst.ContainsKey(text2) Then
                Me.curLngInd = Convert.ToByte(settingsLst.Item(text2))
                If (Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Count > Me.curLngInd) Then
                    Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Item(Me.curLngInd).Checked = True
                End If
            End If
            text2 = "BackgroundColor"
            Dim text1 As String = "BLACK"
            If settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("BLACK")) Then
                Me.CadImportControl1.Black_Click()
            Else
                Me.CadImportControl1.White_Click()
            End If
            text2 = "ShowEntity"
            If settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.entitiesMenuItem.Checked = True
                Me.CadImportControl1.EntitiesTreeVisible = True
            Else
                Me.entitiesMenuItem.Checked = False
                Me.CadImportControl1.EntitiesTreeVisible = False
            End If
            text2 = "ColorDraw"
            If settingsLst.ContainsKey(text2) Then
                text1 = Convert.ToString(settingsLst.Item(text2))
            End If
            If (text1.ToUpper.Equals("TRUE")) Then
                Me.colorDraw = True
            Else
                Me.colorDraw = False
            End If
            text2 = "SHXPathCount"
            If settingsLst.ContainsKey(text2) Then
                num1 = Convert.ToInt32(settingsLst.Item(text2))
            End If
            Dim num2 As Integer = 0
            Do While (num2 < num1)
                text2 = ("SHXPath_" & (num2 + 1))
                If settingsLst.ContainsKey(text2) Then
                    Me.CadImportControl1.shxFrm.AddPath(Convert.ToString(settingsLst.Item(text2)))
                End If
                num2 += 1
            Loop
            text2 = "Install"
            If (settingsLst.ContainsKey(text2) AndAlso CADConst.SearchSHXPaths) Then
                Me.CadImportControl1.shxFrm.lstDir.Items.Clear()
                Me.CadImportControl1.shxFrm.lstPath.Clear()
                Dim list1 As New ArrayList
                CADConst.FindAutoCADSHXPaths(list1)
                Dim num3 As Integer = 0
                Do While (num3 < list1.Count)
                    text1 = CStr(list1.Item(num3))
                    Me.CadImportControl1.shxFrm.lstDir.Items.Add(text1)
                    Me.CadImportControl1.shxFrm.lstPath.Add(text1, "")
                    CADConst.SHXSearchPaths = (CADConst.SHXSearchPaths & CADConst.SHXSearchPaths & text1 & ";")
                    num3 += 1
                Loop
            End If
        End If
        Me.CadImportControl1.SaveProtectionSettings(settingsLst)
    End Sub

    Private Sub CreateNewSettingsList()
        Dim text1 As String
        settingsLst = New SortedList
        settingsLst.Add("LanguagePath", MultipleLanguage.path)
        settingsLst.Add("Language", Me.lngFile)
        settingsLst.Add("LanguageID", Me.curLngInd)
        If (Me.CadImportControl1.CADPictureBox.BackColor.Equals(Color.Black)) Then
            text1 = "Black"
        Else
            text1 = "White"
        End If
        settingsLst.Add("BackgroundColor", text1)
        settingsLst.Add("ShowEntity", Me.CadImportControl1.EntitiesTreeVisible)
        settingsLst.Add("ColorDraw", Me.colorDraw)
        Dim num1 As Integer = Me.CadImportControl1.shxFrm.lstDir.Items.Count
        settingsLst.Add("SHXPathCount", Me.CadImportControl1.shxFrm.lstDir.Items.Count)
        Dim num2 As Integer = 0
        Do While (num2 < num1)
            settingsLst.Add(("SHXPath_" & (num2 + 1)), Me.CadImportControl1.shxFrm.lstDir.Items.Item(num2))
            num2 += 1
        Loop
        Me.CadImportControl1.NewProtectionSettings(settingsLst)
    End Sub

    Private Sub SelectLanguage()
        Dim num1 As Integer = 0
        Do While (num1 < Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Count)
            If (Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Item(num1).Text Is "English") Then
                Me.mainMenu.MenuItems.Item(4).MenuItems.Item(0).MenuItems.Item(num1).Checked = True
                Me.curLngInd = num1
                Return
            End If
            num1 += 1
        Loop
    End Sub

    Private Sub LanguageSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        If (Not (TypeOf sender Is MenuItem)) Then _
            Return
        Dim mn As MenuItem = CType(sender, MenuItem)
        curLngInd = CByte(mn.Index)
        lngFile = mn.Text + ".lng"
        CadImportControl1.SetLNG(lngFile)
        'MainForm Menu
        mlng.RestoreLanguage(Me.Controls, Me.Menu)
        Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems.Clear()
        mlng.LoadLngFileList(Me.mainMenu.MenuItems(4).MenuItems(0), AddressOf LanguageSelect_Click)
        If (Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems.Count > Me.curLngInd) Then _
            Me.mainMenu.MenuItems(4).MenuItems(0).MenuItems(Me.curLngInd).Checked = True
        Me.Text = "CADImport.Net Demo"
        Me.Text = mlng.SetLanguage(Me.Controls, Me.Menu, Me.Text)
    End Sub

    Public Sub EnableButton(ByVal aVal As Boolean)
        mScale.Enabled = aVal
        mSaveFile.Enabled = aVal
        copyMenuItem.Enabled = aVal
        zoomInMenuItem.Enabled = aVal
        zoomOutMenuItem.Enabled = aVal
        fitMenuItem.Enabled = aVal
        colorMenuItem.Enabled = aVal
        blackMenuItem.Enabled = aVal
        whiteBackMenuItem.Enabled = aVal
        blackBackMenuItem.Enabled = aVal
        changeBackMenuItem.Enabled = aVal
        showLineWightMenuItem.Enabled = aVal
        arcsSplitMenuItem.Enabled = aVal
        dimShowMenuItem.Enabled = aVal
        textsShowMenuItem.Enabled = aVal
        layersShowMenuItem.Enabled = aVal
        printMenuItem.Enabled = aVal
#If Export Then
        Me.mnSaveAsDXF.Enabled = aVal
#End If
    End Sub

    Private Sub aboutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles aboutMenuItem.Click
        CadImportControl1.About()
    End Sub

    Private Sub menuItemReg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItemReg.Click
        CadImportControl1.ShowRegForm()
    End Sub

    Private Sub colorMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles colorMenuItem.Click
        colorMenuItem.Checked = True
        blackMenuItem.Checked = False
        CadImportControl1.DoNormalColor()
    End Sub

    Private Sub blackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blackMenuItem.Click
        colorMenuItem.Checked = False
        blackMenuItem.Checked = True
        CadImportControl1.DoBlackColor()
    End Sub

    Private Sub whiteBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles whiteBackMenuItem.Click
        CadImportControl1.White_Click()
    End Sub

    Private Sub blackBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blackBackMenuItem.Click
        CadImportControl1.Black_Click()
    End Sub

    Private Sub changeBackMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles changeBackMenuItem.Click
        CadImportControl1.Color_Click()
    End Sub

    Private Sub showLineWightMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles showLineWightMenuItem.Click
        If (CadImportControl1.CADImage Is Nothing) Then Return
        showLineWightMenuItem.Checked = Not showLineWightMenuItem.Checked
        CadImportControl1.CADImage.IsShowLineWeight = showLineWightMenuItem.Checked
        CadImportControl1.Refresh()
    End Sub

    Private Sub arcsSplitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles arcsSplitMenuItem.Click
        arcsSplitMenuItem.Checked = Not arcsSplitMenuItem.Checked
        CadImportControl1.UseWinEllipse()
    End Sub

    Private Sub dimShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dimShowMenuItem.Click
        dimShowMenuItem.Checked = Not dimShowMenuItem.Checked
        CadImportControl1.ChangeDimensionsVisiblity()
    End Sub

    Private Sub textsShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textsShowMenuItem.Click
        textsShowMenuItem.Checked = Not textsShowMenuItem.Checked
        CadImportControl1.ChangeTextsVisiblity()
    End Sub

    Private Sub layersShowMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles layersShowMenuItem.Click
        If (CadImportControl1.CADImage Is Nothing) Then Return
        CadImportControl1.ShowLayersForm()
    End Sub

    Private Sub entitiesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles entitiesMenuItem.Click
        entitiesMenuItem.Checked = Not entitiesMenuItem.Checked
        CadImportControl1.EntitiesTreeVisible = entitiesMenuItem.Checked
        CadImportControl1.DoResize()
    End Sub

    Private Sub zoomInMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoomInMenuItem.Click
        CadImportControl1.DoZoomIn()
    End Sub

    Private Sub zoomOutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoomOutMenuItem.Click
        CadImportControl1.DoZoomOut()
    End Sub

    Private Sub fitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fitMenuItem.Click
        CadImportControl1.ResetScaling()
    End Sub

    Private Sub shxMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shxMenuItem.Click
        CadImportControl1.AddSHXPaths()
    End Sub

    Private Sub mScale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zoom10MenuItem.Click, zoom25MenuItem.Click, _
    zoom50MenuItem.Click, zoom100MenuItem.Click, zoom200MenuItem.Click, zoom400MenuItem.Click, zoom800MenuItem.Click
        If (CadImportControl1.CADImage Is Nothing) Then
            Return
        End If
        Dim i As Single = CadImportControl1.Scaling
        Select Case CType(sender, MenuItem).Index

            Case 0
                i = 0.1!
            Case 1
                i = 0.25!
            Case 2
                i = 0.5!
            Case 3
                i = 1.0!
            Case 4
                i = 2.0!
            Case 5
                i = 4.0!
            Case 6
                i = 8.0!
        End Select
        CadImportControl1.ResetScaling()
        CadImportControl1.Scaling = i
        CadImportControl1.RefreshImage()
    End Sub

    Private Sub copyMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles copyMenuItem.Click
        If (CadImportControl1.CADImage Is Nothing) Then
            Return
        End If
        Dim tmpRect As CADImport.DRect = New CADImport.DRect(0, 0, CadImportControl1.ClientRectangle.Width * CadImportControl1.Scaling, CadImportControl1.ClientRectangle.Height * CadImportControl1.Scaling)
        CadImportControl1.CADImage.SaveImageToClipboard(tmpRect)
    End Sub

    Private Sub mOpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mOpenFile.Click
        CadImportControl1.LoadFile(True)
        EnableButton(True)
    End Sub

    Private Sub mSaveFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mSaveFile.Click
        CadImportControl1.SaveAsImage()
    End Sub

    Private Sub printMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printMenuItem.Click
        If (CadImportControl1.CADImage Is Nothing) Then
            Return
        End If
        CadImportControl1.CADImage.Print(True, True)
    End Sub

    Private Sub mExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mExit.Click
        Me.Close()
    End Sub

    Private Sub MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
#If protect Then
        CADImport.Protection.CloseApplication()
#End If
        CreateNewSettingsList()
        svSet.SaveOptions(settingsLst)
    End Sub

    Private Sub mnSaveAsDXF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSaveAsDXF.Click
        If (Me.CadImportControl1.CADImage Is Nothing) Then Return
        If (Me.saveDXFDlg.ShowDialog() <> DialogResult.OK) Then Return
        Me.CadImportControl1.SaveAsDXF(Me.saveDXFDlg.FileName)
    End Sub

    Private Sub miFloatLic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miFloatLic.Click
        Me.CadImportControl1.ShowFloatRegForm()
    End Sub
End Class
