using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CADImport;
using CADImportForm;

namespace AddEntityDemoApplication
{
	#region Help
	/// <summary>
	/// Represents a form in which the properties of the multiline text are set 
	/// before adding it to the current CAD image.
	/// </summary>
	#endregion Help
	public class AddMTextForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button pickColorButton;
		private System.Windows.Forms.Label colorLab;
		private ColorDialog setColorDlg;
		private System.Windows.Forms.Label line5;
		private System.Windows.Forms.Label line4;
		private System.Windows.Forms.Label line3;
		private System.Windows.Forms.Label line2;
		private System.Windows.Forms.Label line1;
		private System.Windows.Forms.Label Ylab;
		private System.Windows.Forms.Label Zlab;
		private System.Windows.Forms.Label Xlab;
		private System.Windows.Forms.TextBox ZTb;
		private System.Windows.Forms.TextBox YTb;
		private System.Windows.Forms.TextBox XTb;
		private System.Windows.Forms.Label vertLine2;
		private System.Windows.Forms.Label vertLine1;
		private System.Windows.Forms.Label firstLab;
		private CADMText cMText;
		private System.Windows.Forms.Label RAlab;
		private System.Windows.Forms.TextBox raTb;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button addMTextCancel;
		private System.Windows.Forms.Button addMTextOK;
		private System.Windows.Forms.Label label2;
		private FontDialog fDialog;
		private System.Windows.Forms.Button selectFontBut;
		private System.Windows.Forms.TextBox selectedFont;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.RichTextBox richTextBox1;

		private System.ComponentModel.Container components = null;
		private string fName;
		private string bValue;
		private string iValue;
		private string hValue;
		private string uValue;
		private string cValue;
		private string textValue;
		private string template;
		private ArrayList mTextList;
		private ColorSelector cSelector;
		private byte colorIndex;
		private System.Windows.Forms.Button button2;
		private string result = "";
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private ArrayList strings;
		private ArrayList attributes;
		private ArrayList fonts;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label fontLabel;
		private System.Windows.Forms.Label attributesLab;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label colorB;
		private ArrayList colors;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="AddEntityDemoApplication.AddMTextForm">AddMTextForm</see> class.
		/// </summary>
		#endregion Help
		public AddMTextForm()
		{
		
			InitializeComponent();
			
			fName = "SansSerif";
			bValue = "0";
			iValue = "0";
			hValue = "1.0";
			uValue = "l";
			cValue = "0";
			textValue = "";
			
			mTextList = new ArrayList();
			setColorDlg = new ColorDialog();
			setColorDlg.SolidColorOnly = true;
			this.StartPosition = FormStartPosition.CenterScreen;
			fDialog = new FontDialog();
			cMText = new CADMText();
			colorIndex = 0;
			strings = new ArrayList();
			attributes = new ArrayList();
			colors = new ArrayList();
			fonts = new ArrayList();
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pickColorButton = new System.Windows.Forms.Button();
			this.colorLab = new System.Windows.Forms.Label();
			this.RAlab = new System.Windows.Forms.Label();
			this.line5 = new System.Windows.Forms.Label();
			this.line4 = new System.Windows.Forms.Label();
			this.line3 = new System.Windows.Forms.Label();
			this.line2 = new System.Windows.Forms.Label();
			this.line1 = new System.Windows.Forms.Label();
			this.Ylab = new System.Windows.Forms.Label();
			this.Zlab = new System.Windows.Forms.Label();
			this.Xlab = new System.Windows.Forms.Label();
			this.ZTb = new System.Windows.Forms.TextBox();
			this.YTb = new System.Windows.Forms.TextBox();
			this.XTb = new System.Windows.Forms.TextBox();
			this.vertLine2 = new System.Windows.Forms.Label();
			this.vertLine1 = new System.Windows.Forms.Label();
			this.firstLab = new System.Windows.Forms.Label();
			this.addMTextCancel = new System.Windows.Forms.Button();
			this.addMTextOK = new System.Windows.Forms.Button();
			this.raTb = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.selectFontBut = new System.Windows.Forms.Button();
			this.selectedFont = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.fontLabel = new System.Windows.Forms.Label();
			this.attributesLab = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.colorB = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pickColorButton
			// 
			this.pickColorButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.pickColorButton.Location = new System.Drawing.Point(128, 64);
			this.pickColorButton.Name = "pickColorButton";
			this.pickColorButton.Size = new System.Drawing.Size(95, 25);
			this.pickColorButton.TabIndex = 10;
			this.pickColorButton.Text = "Pick a color";
			this.pickColorButton.Click += new System.EventHandler(this.pickColorButton_Click);
			// 
			// colorLab
			// 
			this.colorLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.colorLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.colorLab.Location = new System.Drawing.Point(8, 72);
			this.colorLab.Name = "colorLab";
			this.colorLab.Size = new System.Drawing.Size(48, 23);
			this.colorLab.TabIndex = 8;
			this.colorLab.Text = "Color :";
			// 
			// RAlab
			// 
			this.RAlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.RAlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.RAlab.Location = new System.Drawing.Point(8, 104);
			this.RAlab.Name = "RAlab";
			this.RAlab.Size = new System.Drawing.Size(104, 20);
			this.RAlab.TabIndex = 31;
			this.RAlab.Text = "Rotation angle :";
			// 
			// line5
			// 
			this.line5.BackColor = System.Drawing.Color.Black;
			this.line5.Location = new System.Drawing.Point(8, 280);
			this.line5.Name = "line5";
			this.line5.Size = new System.Drawing.Size(212, 1);
			this.line5.TabIndex = 37;
			// 
			// line4
			// 
			this.line4.BackColor = System.Drawing.Color.Black;
			this.line4.Location = new System.Drawing.Point(8, 248);
			this.line4.Name = "line4";
			this.line4.Size = new System.Drawing.Size(212, 1);
			this.line4.TabIndex = 36;
			// 
			// line3
			// 
			this.line3.BackColor = System.Drawing.Color.Black;
			this.line3.Location = new System.Drawing.Point(8, 216);
			this.line3.Name = "line3";
			this.line3.Size = new System.Drawing.Size(212, 1);
			this.line3.TabIndex = 35;
			// 
			// line2
			// 
			this.line2.BackColor = System.Drawing.Color.Black;
			this.line2.Location = new System.Drawing.Point(8, 184);
			this.line2.Name = "line2";
			this.line2.Size = new System.Drawing.Size(212, 1);
			this.line2.TabIndex = 34;
			// 
			// line1
			// 
			this.line1.BackColor = System.Drawing.Color.Black;
			this.line1.Location = new System.Drawing.Point(8, 160);
			this.line1.Name = "line1";
			this.line1.Size = new System.Drawing.Size(212, 1);
			this.line1.TabIndex = 33;
			// 
			// Ylab
			// 
			this.Ylab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Ylab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Ylab.Location = new System.Drawing.Point(8, 224);
			this.Ylab.Name = "Ylab";
			this.Ylab.Size = new System.Drawing.Size(98, 20);
			this.Ylab.TabIndex = 39;
			this.Ylab.Text = "Y coordinate :";
			this.Ylab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Zlab
			// 
			this.Zlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Zlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Zlab.Location = new System.Drawing.Point(8, 256);
			this.Zlab.Name = "Zlab";
			this.Zlab.Size = new System.Drawing.Size(98, 20);
			this.Zlab.TabIndex = 40;
			this.Zlab.Text = "Z coordinate :";
			this.Zlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Xlab
			// 
			this.Xlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Xlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Xlab.Location = new System.Drawing.Point(8, 192);
			this.Xlab.Name = "Xlab";
			this.Xlab.Size = new System.Drawing.Size(98, 20);
			this.Xlab.TabIndex = 38;
			this.Xlab.Text = "X coordinate :";
			this.Xlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ZTb
			// 
			this.ZTb.Location = new System.Drawing.Point(112, 256);
			this.ZTb.Name = "ZTb";
			this.ZTb.TabIndex = 43;
			this.ZTb.Text = "0,0";
			// 
			// YTb
			// 
			this.YTb.Location = new System.Drawing.Point(112, 224);
			this.YTb.Name = "YTb";
			this.YTb.TabIndex = 42;
			this.YTb.Text = "0,0";
			// 
			// XTb
			// 
			this.XTb.Location = new System.Drawing.Point(112, 192);
			this.XTb.Name = "XTb";
			this.XTb.TabIndex = 41;
			this.XTb.Text = "0,0";
			// 
			// vertLine2
			// 
			this.vertLine2.BackColor = System.Drawing.Color.Black;
			this.vertLine2.Location = new System.Drawing.Point(220, 160);
			this.vertLine2.Name = "vertLine2";
			this.vertLine2.Size = new System.Drawing.Size(1, 120);
			this.vertLine2.TabIndex = 45;
			// 
			// vertLine1
			// 
			this.vertLine1.BackColor = System.Drawing.Color.Black;
			this.vertLine1.Location = new System.Drawing.Point(104, 160);
			this.vertLine1.Name = "vertLine1";
			this.vertLine1.Size = new System.Drawing.Size(1, 120);
			this.vertLine1.TabIndex = 44;
			// 
			// firstLab
			// 
			this.firstLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.firstLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.firstLab.Location = new System.Drawing.Point(112, 160);
			this.firstLab.Name = "firstLab";
			this.firstLab.Size = new System.Drawing.Size(68, 16);
			this.firstLab.TabIndex = 46;
			this.firstLab.Text = "Start point";
			// 
			// addMTextCancel
			// 
			this.addMTextCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addMTextCancel.Location = new System.Drawing.Point(376, 288);
			this.addMTextCancel.Name = "addMTextCancel";
			this.addMTextCancel.Size = new System.Drawing.Size(75, 25);
			this.addMTextCancel.TabIndex = 48;
			this.addMTextCancel.Text = "Cancel";
			this.addMTextCancel.Click += new System.EventHandler(this.addMTextCancel_Click);
			// 
			// addMTextOK
			// 
			this.addMTextOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addMTextOK.Location = new System.Drawing.Point(285, 288);
			this.addMTextOK.Name = "addMTextOK";
			this.addMTextOK.Size = new System.Drawing.Size(75, 25);
			this.addMTextOK.TabIndex = 47;
			this.addMTextOK.Text = "OK";
			this.addMTextOK.Click += new System.EventHandler(this.addMTextOK_Click);
			// 
			// raTb
			// 
			this.raTb.Location = new System.Drawing.Point(8, 128);
			this.raTb.Name = "raTb";
			this.raTb.Size = new System.Drawing.Size(104, 20);
			this.raTb.TabIndex = 49;
			this.raTb.Text = "0";
			// 
			// label1
			// 
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label1.Location = new System.Drawing.Point(240, 96);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 23);
			this.label1.TabIndex = 52;
			this.label1.Text = "Text contents :";
			// 
			// label2
			// 
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label2.Location = new System.Drawing.Point(8, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 54;
			this.label2.Text = "Font :";
			// 
			// selectFontBut
			// 
			this.selectFontBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.selectFontBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.selectFontBut.Location = new System.Drawing.Point(128, 32);
			this.selectFontBut.Name = "selectFontBut";
			this.selectFontBut.Size = new System.Drawing.Size(95, 25);
			this.selectFontBut.TabIndex = 55;
			this.selectFontBut.Text = "Select";
			this.selectFontBut.Click += new System.EventHandler(this.selectFontBut_Click);
			// 
			// selectedFont
			// 
			this.selectedFont.BackColor = System.Drawing.Color.White;
			this.selectedFont.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.selectedFont.Location = new System.Drawing.Point(8, 32);
			this.selectedFont.Multiline = true;
			this.selectedFont.Name = "selectedFont";
			this.selectedFont.ReadOnly = true;
			this.selectedFont.Size = new System.Drawing.Size(104, 22);
			this.selectedFont.TabIndex = 56;
			this.selectedFont.Text = "Microsoft Sans Serif";
			// 
			// label3
			// 
			this.label3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label3.Location = new System.Drawing.Point(240, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 23);
			this.label3.TabIndex = 57;
			this.label3.Text = "Enter a text line :";
			// 
			// listBox1
			// 
			this.listBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.listBox1.Location = new System.Drawing.Point(240, 120);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(208, 56);
			this.listBox1.TabIndex = 58;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(240, 64);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(95, 25);
			this.button1.TabIndex = 59;
			this.button1.Text = "Add";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(240, 32);
			this.richTextBox1.Multiline = false;
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(208, 20);
			this.richTextBox1.TabIndex = 60;
			this.richTextBox1.Text = "";
			// 
			// button2
			// 
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button2.Location = new System.Drawing.Point(352, 64);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(95, 25);
			this.button2.TabIndex = 61;
			this.button2.Text = "Remove";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// textBox1
			// 
			this.textBox1.BackColor = System.Drawing.Color.Black;
			this.textBox1.Enabled = false;
			this.textBox1.Location = new System.Drawing.Point(288, 216);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(40, 23);
			this.textBox1.TabIndex = 62;
			this.textBox1.Text = "";
			// 
			// label4
			// 
			this.label4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label4.Location = new System.Drawing.Point(240, 192);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(216, 18);
			this.label4.TabIndex = 63;
			this.label4.Text = "Attributes of the selected text line :";
			// 
			// label5
			// 
			this.label5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label5.Location = new System.Drawing.Point(240, 216);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(44, 18);
			this.label5.TabIndex = 64;
			this.label5.Text = "Color :";
			// 
			// label6
			// 
			this.label6.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label6.Location = new System.Drawing.Point(240, 264);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(78, 18);
			this.label6.TabIndex = 66;
			this.label6.Text = "Font name :";
			// 
			// label7
			// 
			this.label7.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.label7.Location = new System.Drawing.Point(240, 240);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(78, 18);
			this.label7.TabIndex = 67;
			this.label7.Text = "Font style :";
			// 
			// fontLabel
			// 
			this.fontLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.fontLabel.Location = new System.Drawing.Point(312, 264);
			this.fontLabel.Name = "fontLabel";
			this.fontLabel.Size = new System.Drawing.Size(152, 18);
			this.fontLabel.TabIndex = 68;
			this.fontLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// attributesLab
			// 
			this.attributesLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.attributesLab.Location = new System.Drawing.Point(312, 240);
			this.attributesLab.Name = "attributesLab";
			this.attributesLab.Size = new System.Drawing.Size(144, 18);
			this.attributesLab.TabIndex = 65;
			this.attributesLab.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.Black;
			this.label8.Location = new System.Drawing.Point(8, 160);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(1, 121);
			this.label8.TabIndex = 69;
			// 
			// colorB
			// 
			this.colorB.BackColor = System.Drawing.Color.Black;
			this.colorB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.colorB.Location = new System.Drawing.Point(64, 71);
			this.colorB.Name = "colorB";
			this.colorB.Size = new System.Drawing.Size(48, 23);
			this.colorB.TabIndex = 70;
			this.colorB.Click += new System.EventHandler(this.colorTB_Click);
			// 
			// AddMTextForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(458, 317);
			this.Controls.Add(this.colorB);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.fontLabel);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.attributesLab);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.selectedFont);
			this.Controls.Add(this.raTb);
			this.Controls.Add(this.ZTb);
			this.Controls.Add(this.YTb);
			this.Controls.Add(this.XTb);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.selectFontBut);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.addMTextCancel);
			this.Controls.Add(this.addMTextOK);
			this.Controls.Add(this.vertLine2);
			this.Controls.Add(this.vertLine1);
			this.Controls.Add(this.Ylab);
			this.Controls.Add(this.Zlab);
			this.Controls.Add(this.Xlab);
			this.Controls.Add(this.line5);
			this.Controls.Add(this.line4);
			this.Controls.Add(this.line3);
			this.Controls.Add(this.line2);
			this.Controls.Add(this.line1);
			this.Controls.Add(this.RAlab);
			this.Controls.Add(this.pickColorButton);
			this.Controls.Add(this.colorLab);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.firstLab);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "AddMTextForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Add MText";
			this.ResumeLayout(false);

		}
		#endregion

		private void pickColorButton_Click(object sender, System.EventArgs e)
		{
			cSelector = new ColorSelector(colorIndex);
			cSelector.ShowDialog();
			
			if(cSelector.DialogResult == DialogResult.OK)
			{
				colorB.BackColor = Color.FromArgb(cSelector.R, cSelector.G, cSelector.B);
				this.richTextBox1.ForeColor = colorB.BackColor;
				colorIndex = cSelector.ColorIndex;
				cValue = colorIndex.ToString();
			}
		}

		private void addMTextOK_Click(object sender, System.EventArgs e)
		{
			try
			{
				for(int i = 0; i < strings.Count; i++)
				{
					result = result + strings[i].ToString();
				}
				result = "{" + result + "}";
				cMText.Point = new DPoint(Convert.ToDouble(this.XTb.Text), Convert.ToDouble(this.YTb.Text), Convert.ToDouble(this.ZTb.Text));
				cMText.Angle = Convert.ToInt32(this.raTb.Text);
				cMText.Text = result;
				AddEntityForm.actForm.FCADImage.Converter.GetSection(ConvSection.Entities).AddEntity(cMText);
				AddEntityForm.actForm.FCADImage.Converter.OnCreate(cMText);
				AddEntityForm.actForm.FCADImage.Converter.Loads(cMText);
				AddEntityForm.actForm.FCADImage.GetExtents();
				AddEntityForm.actForm.DoResize();
			}
			catch(FormatException exception)
			{
				MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			
			AddEntityForm.actForm.Invalidate();
			this.Close();
		}

		private void addMTextCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void selectFontBut_Click(object sender, System.EventArgs e)
		{
			if (fDialog.ShowDialog() == DialogResult.OK)
			{
				selectedFont.Text = fDialog.Font.Name;
				if(cMText != null)
				{
					fName = fDialog.Font.Name;
					if(fDialog.Font.Bold)
						bValue = "1";
					else
						bValue = "0";
					if(fDialog.Font.Italic)
						iValue = "1";
					else
						iValue = "0";
					if(fDialog.Font.Underline)
						uValue = "L";
					else
						uValue = "l";
					hValue = fDialog.Font.Height.ToString();
					this.richTextBox1.Font = fDialog.Font;
				}
			}
		}

		private void button1_Click(object sender, System.EventArgs e) // add text line
		{
			string attrib = "";
			if(bValue == "1")
				attrib = "bold";
			else
				attrib = "regular";
			if(iValue == "1")
				attrib = attrib + ", italic";
			if(uValue == "L")
				attrib = attrib + ", underlined";
			attrib = attrib + ".";
			attributes.Add(attrib);
			colors.Add(colorB.BackColor);
			fonts.Add(fName);
			textValue = richTextBox1.Text;
			template = @"\f" + fName + "|b" + bValue + "|i" + iValue + @";\H" + hValue + @";\" + uValue + @"\C" + cValue + ";" + textValue + @"\P";
			strings.Add(template);
			listBox1.Items.Add(richTextBox1.Text);
		}

		private void button2_Click(object sender, System.EventArgs e) // remove text line
		{
			int n = 0;
			if(listBox1.SelectedIndex >= 0)
			{
				n = listBox1.SelectedIndex;
				strings.RemoveAt(n);
				listBox1.Items.RemoveAt(n);
				attributes.RemoveAt(n);
				colors.RemoveAt(n);
				fonts.RemoveAt(n);
			}
		}

		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(((ListBox)sender).SelectedItem != null)
			{
				this.richTextBox1.Text = ((ListBox)sender).SelectedItem.ToString();
				this.attributesLab.Text = attributes[((ListBox)sender).SelectedIndex].ToString();
				this.textBox1.BackColor = (Color)colors[((ListBox)sender).SelectedIndex];
				this.fontLabel.Text = fonts[((ListBox)sender).SelectedIndex].ToString();
			}
		}

		private void colorTB_Click(object sender, System.EventArgs e)
		{
			cSelector = new ColorSelector(colorIndex);
			cSelector.ShowDialog();
			
			if(cSelector.DialogResult == DialogResult.OK)
			{
				colorB.BackColor = Color.FromArgb(cSelector.R, cSelector.G, cSelector.B);
				this.richTextBox1.ForeColor = colorB.BackColor;
				colorIndex = cSelector.ColorIndex;
				cValue = colorIndex.ToString();
			}
		}
	}
}
