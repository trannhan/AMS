//To compile the project you need the extended version of the CADImport .NET library
//that allows to access CAD entities directly.  You can get this version of the 
//library free of charge by emailing your request to: info@cadsofttools.com
using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using CADImport;
using CADImportForm;
using CADImportFaceModule;
using RasterImage;
using HPGL2;

namespace AddEntityDemoApplication
{
	#region Help
	/// <summary>
	/// Represents the main application form where CAD image and added CAD entities can be viewed.
	/// </summary>
	#endregion Help
	public class AddEntityForm: System.Windows.Forms.Form
	{
		private const int OnMouseScroll = 522;

		private bool deactiv;
		private PointF old_Pos;
		private LayerForm lForm;
		internal static AddEntityForm actForm;
		private PointF pos;
		private Rectangle curClRect;
		private float wh;
		private float scale;
		private DPoint ScaleRect;
		private ArrayList layouts;
		private int cX, cY;
		private bool det1;
		private float prev_scale = 1;
		private System.Windows.Forms.ItemCheckEventHandler dl1;
		private System.Windows.Forms.OpenFileDialog openFileDlg;
		private System.Windows.Forms.StatusBar stBar;
		private System.Windows.Forms.StatusBarPanel sbOpen;
		private System.Windows.Forms.StatusBarPanel sbScale;
		private System.Windows.Forms.ToolBarButton tlbOpen;
		private System.Windows.Forms.ToolBarButton tlbZoomIn;
		private System.Windows.Forms.ToolBarButton tlbZoomOut;
		private System.Windows.Forms.ToolBarButton tlbLay;
		private System.Windows.Forms.ToolBarButton tlbWhite;
		private System.Windows.Forms.ToolBarButton tlbBlack;
		private System.Windows.Forms.ToolBarButton tlbAddEnt;
		private System.Windows.Forms.ToolBarButton tlbSave;
		private System.Windows.Forms.ToolBar tlbTool;
		private System.Windows.Forms.StatusBarPanel sbCoord;
		private System.Windows.Forms.PictureBox cadPictBox;
		private System.Windows.Forms.ImageList toolBtnImageList;
		private System.ComponentModel.IContainer components;
		internal CADImage FCADImage;
		private ContextMenu addContextMenu;
		private MenuItem addLineMenuItem;
		private MenuItem addPolyLineMenuItem;
		private MenuItem addCircleMenuItem;
		private System.Windows.Forms.SaveFileDialog saveImgDlg;
		private AddCircleForm aCForm;
		private AddLineForm aLForm;
		private AddPolyForm aPForm;
		private AddTextForm aTForm;
		private AddMTextForm aMTForm;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private AboutForm aboutForm;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem mSaveAsDXF;
		private System.Windows.Forms.SaveFileDialog saveDXFDlg;
		private SelectorForm sForm;
		private System.Windows.Forms.ToolBarButton tlbShx;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private SHXForm frmSHX;
		private ClipRect clipRectangle;
		private System.Windows.Forms.MenuItem miFloatLic;
		#region protect
		#if protect
			private RegForm regFrm;
		#endif
		#if (protect && floatprotect)
			private FloatLicForm floatLicFrm;
		#endif
		#endregion protect
		private static readonly ArrayList HPGLExt;

		static AddEntityForm()
		{
			HPGLExt = new ArrayList(new string[]{".HPG", ".PLT", ".RTL", ".SPL", ".PRN", ".GL2", ".HPGL2", ".HPGL",
													".HP2", ".HP1", ".HP", ".PLO", ".HG", ".HGL"});
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AddEntityForm));
			this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
			this.stBar = new System.Windows.Forms.StatusBar();
			this.sbOpen = new System.Windows.Forms.StatusBarPanel();
			this.sbScale = new System.Windows.Forms.StatusBarPanel();
			this.sbCoord = new System.Windows.Forms.StatusBarPanel();
			this.tlbTool = new System.Windows.Forms.ToolBar();
			this.tlbOpen = new System.Windows.Forms.ToolBarButton();
			this.tlbZoomIn = new System.Windows.Forms.ToolBarButton();
			this.tlbZoomOut = new System.Windows.Forms.ToolBarButton();
			this.tlbWhite = new System.Windows.Forms.ToolBarButton();
			this.tlbBlack = new System.Windows.Forms.ToolBarButton();
			this.tlbLay = new System.Windows.Forms.ToolBarButton();
			this.tlbAddEnt = new System.Windows.Forms.ToolBarButton();
			this.addContextMenu = new System.Windows.Forms.ContextMenu();
			this.addCircleMenuItem = new System.Windows.Forms.MenuItem();
			this.addLineMenuItem = new System.Windows.Forms.MenuItem();
			this.addPolyLineMenuItem = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.tlbSave = new System.Windows.Forms.ToolBarButton();
			this.tlbShx = new System.Windows.Forms.ToolBarButton();
			this.toolBtnImageList = new System.Windows.Forms.ImageList(this.components);
			this.cadPictBox = new System.Windows.Forms.PictureBox();
			this.saveImgDlg = new System.Windows.Forms.SaveFileDialog();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mSaveAsDXF = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.miFloatLic = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.saveDXFDlg = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).BeginInit();
			this.SuspendLayout();
			// 
			// openFileDlg
			// 
			this.openFileDlg.DefaultExt = "*.dxf;*.dwg";
			this.openFileDlg.Filter = @"All(*.dxf,*.dwg,*.hpg,*.plt,*.rtl, *.spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1, *.hp, *.plo, *.hg,*.hgl,*.cgm, *.bmp,*.jpg, *.jpeg,*.tiff, *.gif, *.ico, *.cur, *.png, *.emf, *.wmf)|*.bmp;*.jpg;*.jpeg;*.tiff; *.gif; *.ico;*.dxf;*.dwg;*.hpg;*.plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;*.hgl;*.cur;*.png; *.emf; *.wmf; *.cgm|CAD files(*.dxf, *.dwg)|*.dxf;*.dwg|All raster files (*.bmp,*.jpg, *.jpeg,*.tiff,*.tif, *.gif, *.ico, *.cur, *.png)|*.bmp;*.jpg;*.jpeg;*.tiff;*.tif; *.gif;*.ico;*.cur; *.png|Metafiles ( *.emf, *.wmf)| *.emf; *.wmf|DXF files(*.dxf)|*.dxf|DWG files(*.dwg)|*.dwg|BMP(*.bmp)|*.bmp|JPG(*.jpg, *.jpeg)| *.jpg; *.jpeg|TIFF(*.tiff, *.tif)|*.tiff;*.tif|GIF(*.gif)|*.gif|ICO(*.ico)|*.ico|PNG(*.png)|*.png|Cursors(*.cur)|*.cur|HPGL(*.hpg,*.plt,*.rtl, *.spl, *.prn, *.gl2,*.hpgl2,*.hpgl,*.hp2,*.hp1, *.hp, *.plo, *.hg,*.hgl)|*.hpg;*.plt;*.rtl; *.spl; *.prn; *.gl2;*.hpgl2;*.hpgl;*.hp2;*.hp1; *.hp; *.plo; *.hg;*.hgl|CGM (*.cgm)|*.cgm";
			this.openFileDlg.ShowHelp = true;
			// 
			// stBar
			// 
			this.stBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.stBar.Location = new System.Drawing.Point(0, 390);
			this.stBar.Name = "stBar";
			this.stBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					 this.sbOpen,
																					 this.sbScale,
																					 this.sbCoord});
			this.stBar.ShowPanels = true;
			this.stBar.Size = new System.Drawing.Size(687, 16);
			this.stBar.TabIndex = 9;
			// 
			// sbOpen
			// 
			this.sbOpen.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbOpen.MinWidth = 100;
			this.sbOpen.ToolTipText = "File Name";
			// 
			// sbScale
			// 
			this.sbScale.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbScale.ToolTipText = "Scale";
			this.sbScale.Width = 520;
			// 
			// sbCoord
			// 
			this.sbCoord.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
			this.sbCoord.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.sbCoord.Text = "0 - 0 - 0";
			this.sbCoord.Width = 51;
			// 
			// tlbTool
			// 
			this.tlbTool.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.tlbTool.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tlbTool.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.tlbOpen,
																					   this.tlbZoomIn,
																					   this.tlbZoomOut,
																					   this.tlbWhite,
																					   this.tlbBlack,
																					   this.tlbLay,
																					   this.tlbAddEnt,
																					   this.tlbSave,
																					   this.tlbShx});
			this.tlbTool.ButtonSize = new System.Drawing.Size(20, 20);
			this.tlbTool.DropDownArrows = true;
			this.tlbTool.ImageList = this.toolBtnImageList;
			this.tlbTool.Location = new System.Drawing.Point(0, 0);
			this.tlbTool.Name = "tlbTool";
			this.tlbTool.ShowToolTips = true;
			this.tlbTool.Size = new System.Drawing.Size(687, 29);
			this.tlbTool.TabIndex = 10;
			this.tlbTool.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tlbTool_ButtonClick);
			// 
			// tlbOpen
			// 
			this.tlbOpen.ImageIndex = 1;
			this.tlbOpen.ToolTipText = "Open file";
			// 
			// tlbZoomIn
			// 
			this.tlbZoomIn.Enabled = false;
			this.tlbZoomIn.ImageIndex = 2;
			this.tlbZoomIn.ToolTipText = "Zoom In(+)";
			// 
			// tlbZoomOut
			// 
			this.tlbZoomOut.Enabled = false;
			this.tlbZoomOut.ImageIndex = 3;
			this.tlbZoomOut.ToolTipText = "Zoom Out(-)";
			// 
			// tlbWhite
			// 
			this.tlbWhite.Enabled = false;
			this.tlbWhite.ImageIndex = 4;
			this.tlbWhite.ToolTipText = "White background";
			// 
			// tlbBlack
			// 
			this.tlbBlack.Enabled = false;
			this.tlbBlack.ImageIndex = 5;
			this.tlbBlack.ToolTipText = "Black background";
			// 
			// tlbLay
			// 
			this.tlbLay.Enabled = false;
			this.tlbLay.ImageIndex = 6;
			this.tlbLay.ToolTipText = "Show layers form";
			// 
			// tlbAddEnt
			// 
			this.tlbAddEnt.DropDownMenu = this.addContextMenu;
			this.tlbAddEnt.Enabled = false;
			this.tlbAddEnt.ImageIndex = 0;
			this.tlbAddEnt.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.tlbAddEnt.ToolTipText = "Add entity";
			// 
			// addContextMenu
			// 
			this.addContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.addCircleMenuItem,
																						   this.addLineMenuItem,
																						   this.addPolyLineMenuItem,
																						   this.menuItem7,
																						   this.menuItem8});
			// 
			// addCircleMenuItem
			// 
			this.addCircleMenuItem.Index = 0;
			this.addCircleMenuItem.Text = "Circle";
			this.addCircleMenuItem.Click += new System.EventHandler(this.addCircleMenuItem_Click);
			// 
			// addLineMenuItem
			// 
			this.addLineMenuItem.Index = 1;
			this.addLineMenuItem.Text = "Line";
			this.addLineMenuItem.Click += new System.EventHandler(this.addLineMenuItem_Click);
			// 
			// addPolyLineMenuItem
			// 
			this.addPolyLineMenuItem.Index = 2;
			this.addPolyLineMenuItem.Text = "Polyline";
			this.addPolyLineMenuItem.Click += new System.EventHandler(this.addPolyLineMenuItem_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 3;
			this.menuItem7.Text = "Text";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 4;
			this.menuItem8.Text = "MText";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// tlbSave
			// 
			this.tlbSave.Enabled = false;
			this.tlbSave.ImageIndex = 7;
			this.tlbSave.ToolTipText = "Save image";
			// 
			// tlbShx
			// 
			this.tlbShx.Enabled = false;
			this.tlbShx.ImageIndex = 8;
			this.tlbShx.Pushed = true;
			// 
			// toolBtnImageList
			// 
			this.toolBtnImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.toolBtnImageList.ImageSize = new System.Drawing.Size(16, 16);
			this.toolBtnImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolBtnImageList.ImageStream")));
			this.toolBtnImageList.TransparentColor = System.Drawing.Color.White;
			// 
			// cadPictBox
			// 
			this.cadPictBox.BackColor = System.Drawing.Color.Black;
			this.cadPictBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.cadPictBox.Cursor = System.Windows.Forms.Cursors.Default;
			this.cadPictBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.cadPictBox.Location = new System.Drawing.Point(0, 29);
			this.cadPictBox.Name = "cadPictBox";
			this.cadPictBox.Size = new System.Drawing.Size(687, 361);
			this.cadPictBox.TabIndex = 13;
			this.cadPictBox.TabStop = false;
			this.cadPictBox.Paint += new System.Windows.Forms.PaintEventHandler(this.cadPictBox_Paint);
			this.cadPictBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseUp);
			this.cadPictBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseMove);
			this.cadPictBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cadPictBox_MouseDown);
			// 
			// saveImgDlg
			// 
			this.saveImgDlg.Filter = "*.bmp|*.bmp|*.jpg|*.jpg|*.tiff|*.tiff|*.gif|*.gif|*.emf|*.emf|*.dxf|*.dxf";
			this.saveImgDlg.RestoreDirectory = true;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem9,
																					  this.menuItem5});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.mSaveAsDXF,
																					  this.menuItem3,
																					  this.menuItem4});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Open File ...";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// mSaveAsDXF
			// 
			this.mSaveAsDXF.Enabled = false;
			this.mSaveAsDXF.Index = 1;
			this.mSaveAsDXF.Text = "Save as DXF...";
			this.mSaveAsDXF.Click += new System.EventHandler(this.mSaveAsDXF_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "Exit";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 1;
			this.menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem10});
			this.menuItem9.Text = "View";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 0;
			this.menuItem10.Text = "SHX Fonts";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem11,
																					  this.miFloatLic,
																					  this.menuItem6});
			this.menuItem5.Text = "?";
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 0;
			this.menuItem11.Text = "Register";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// miFloatLic
			// 
			this.miFloatLic.Index = 1;
			this.miFloatLic.Text = "Floating License Registration...";
			this.miFloatLic.Click += new System.EventHandler(this.miFloatLic_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 2;
			this.menuItem6.Text = "About";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// saveDXFDlg
			// 
			this.saveDXFDlg.DefaultExt = "*.dxf";
			this.saveDXFDlg.Filter = "*.dxf|*.dxf";
			// 
			// AddEntityForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(687, 406);
			this.Controls.Add(this.cadPictBox);
			this.Controls.Add(this.tlbTool);
			this.Controls.Add(this.stBar);
			this.Menu = this.mainMenu1;
			this.Name = "AddEntityForm";
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CADImport.NET - Add Entity";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Resize += new System.EventHandler(this.MainForm_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
			((System.ComponentModel.ISupportInitialize)(this.sbOpen)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbScale)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sbCoord)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main(string[] args) 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			CADImage.SelectionMode = ObjectsSelection.SelectionEntityMode.Disabled;
			actForm = new AddEntityForm();
			if(args.Length != 0)
				if(File.Exists(args[0]))
					actForm.openFileDlg.FileName = args[0];
			Application.Run(actForm);	
		}

		#region Help
		/// <summary>
		/// Adjusts the image size according to the specified scale.
		/// </summary>
		/// <param name="i">A scale value.</param>
		/// <remarks>If the scale value is more than one the image size increases; otherwise, decreases.</remarks>
		#endregion Help
		public void Zoom(float i)
		{
			if(FCADImage == null) return;
			scale = scale*i;
			if(scale < 0.005f) scale = 0.005f;	
			cadPictBox.Invalidate();
			cadPictBox_MouseMove(cadPictBox, new MouseEventArgs(MouseButtons.Left, 0, (int)old_Pos.X, (int)old_Pos.Y, 0));
			stBar.Panels[1].Text = "" + scale;
		}

		private void Shift()
		{
			pos.X = old_Pos.X - (old_Pos.X - pos.X)*scale / prev_scale;
			pos.Y = old_Pos.Y - (old_Pos.Y - pos.Y)*scale / prev_scale;
			prev_scale = scale;		
		}

		#region Help
		/// <summary>
		/// Processes Windows messages and allows the user to zoom in(out) the CAD image by mouse wheel.
		/// </summary>
		/// <param name="m">The Windows <see cref="System.Windows.Forms.Message">Message</see> to process.</param>
		#endregion Help
		protected override void WndProc(ref Message m)
		{
			if(m.Msg == 0x0112)
			{
				if(m.WParam.ToInt32() == 0xF020)
					deactiv = true;
			}
			if(m.Msg == OnMouseScroll) 
			{
				if(m.WParam.ToInt32() < 0)  Zoom(0.7f);
				else Zoom(1.3f);
			} 
			base.WndProc(ref m);
		}

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="AddEntityDemoApplication.AddEntityForm">AddEntityForm</see> class.
		/// </summary>
		#endregion Help
		public AddEntityForm()
		{
			scale = 1;
			ScaleRect = new DPoint();
			old_Pos = new PointF();
			layouts = new ArrayList();
			lForm = new LayerForm();
			aboutForm = new AboutForm();
			dl1 = new System.Windows.Forms.ItemCheckEventHandler(this.chLay_ItemCheck);
			frmSHX = new SHXForm();
			#region protect
			#if (protect && floatprotect)
				floatLicFrm = new FloatLicForm();
				floatLicFrm.Change += new System.EventHandler(InvalidateImage);
			#endif
			#if protect
				regFrm = new RegForm();
			#endif
			#endregion protect
			InitializeComponent();
			#region protect
#if ((! floatprotect) && protect)
			this.miFloatLic.Enabled = false;
#endif
			#endregion
			this.clipRectangle = new ClipRect(this.cadPictBox);
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void Open_Click(object sender, System.EventArgs e)
		{
			LoadFile(true);	
		}

		private void InvalidateImage(object sender, System.EventArgs e)
		{
			this.cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Loads a CAD file into the main application's form.
		/// </summary>
		/// <param name="dlg">A value indicating if an <see cref="System.Windows.Forms.OpenFileDialog">OpenFileDialog</see> 
		/// box is invoked for selecting and loading a CAD file. <b>true</b>, if an <see cref="System.Windows.Forms.OpenFileDialog">OpenFileDialog</see> 
		/// box is invoked; otherwise, <b>false</b>.</param>
		#endregion Help
		public void LoadFile(bool dlg)
		{
			cadPictBox.Visible = false;
			lForm.lstViewLay.Items.Clear();
			lForm.lstViewLay.ItemCheck -= dl1;
			if(dlg)
				if(openFileDlg.ShowDialog(this) != DialogResult.OK) 
				{
					cadPictBox.Visible = true;
					return;
				}
			if (openFileDlg.FileName != null)
			{
				if(FCADImage != null)
				{	
					FCADImage.Dispose();
					FCADImage = null;
				}
				this.Cursor = Cursors.WaitCursor;
				stBar.Panels[0].Text = "Load file...";
				scale = 1;
				prev_scale = 1;
				pos = new PointF();
				string ext = Path.GetExtension(openFileDlg.FileName).ToUpper();
				if(ext == ".DWG")
				{
#if DWGModule
					FCADImage = new DWG.DWGImage();
					((DWG.DWGImage)FCADImage).LoadFromFile(openFileDlg.FileName);
					stBar.Panels[0].Text = Path.GetFileName(openFileDlg.FileName) + " - ";
#else
					NotSupportedInCurrentVersion();
					return;
#endif
				}
				else 
				{
					if(ext == ".DXF")
					{
						FCADImage = new CADImage();
						FCADImage.LoadFromFile(openFileDlg.FileName);
						stBar.Panels[0].Text = Path.GetFileName(openFileDlg.FileName);
					}
					else if(ext == ".CGM")
					{
#if UseCGM
					bool tmpshx = CADConst.UseSHXFonts;
					if(CADConst.UseSHXFonts)
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = false;
					}
					else 
					{
						CADConst.UseMultyTTFFonts = true;
						CADConst.UseTTFFonts = true;
					}
					FCADImage = new CGM.CGMImage();
					FCADImage.LoadFromFile(openFileDlg.FileName);
#else
						NotSupportedInCurrentVersion();
						return;
#endif
					}
					else 
						if(HPGLExt.IndexOf(ext) != -1)
					{
						FCADImage = new HPGLImage();
						FCADImage.LoadFromFile(openFileDlg.FileName);
					}
					else
					{
						FCADImage = new CADRasterImage(this.cadPictBox);
						FCADImage.LoadFromFile(openFileDlg.FileName);
					}
				}
			}
			FCADImage.UseWinEllipse = false;
			EnableButton(true);
			if(cadPictBox.BackColor == Color.White)
				White_Click();
			else Black_Click();
			DoResize();
			stBar.Panels[1].Text = "" + scale;
			this.Cursor = Cursors.Default;
			
		}

		
		private void NotSupportedInCurrentVersion()
		{
			this.Cursor = Cursors.Default;
			cadPictBox.Visible = true;
			stBar.Panels[0].Text = "not supported";
			MessageBox.Show("Not supported in current version!", "CADImport .Net");
			return;
		}

		#region Help
		/// <summary>
		/// Enables or disables buttons of the toolbar and menu items of the main menu.
		/// </summary>
		/// <param name="aVal"><b>true</b> if to enable the buttons and menu items; <b>false</b> if to disable them.</param>
		/// <remarks>The buttons and menu items are enabled after loading a CAD file and become disabled after closing the file.</remarks>
		#endregion Help
		public void EnableButton(bool aVal)
		{
			for(int i = 1; i < tlbTool.Buttons.Count; i++)
				tlbTool.Buttons[i].Enabled = aVal;
			cadPictBox.Visible = aVal;
			#if Export
				this.mSaveAsDXF.Enabled = aVal;
			#endif
			
		}

		private void ZoomIn_Click(object sender, System.EventArgs e)
		{
			DoZoomIn();
		}

		#region Help
		/// <summary>
		/// Increases a scale of the CAD image in two times.
		/// </summary>
		#endregion Help
		public void DoZoomIn()
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = scale * 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void ZoomOut_Click(object sender, System.EventArgs e)
		{
			DoZoomOut();
		}

		#region Help
		/// <summary>
		/// Decreases a scale of the CAD image in two times.
		/// </summary>
		#endregion Help
		public void DoZoomOut()
		{
			if(FCADImage == null) return;
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = scale / 2;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		private void cadPictBox_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			DrawCADImage(e.Graphics);
		}

		#region Help
		/// <summary>
		/// Draws a CAD image from the loaded CAD file.
		/// </summary>
		/// <param name="gr">A <see cref="System.Drawing.Graphics">Graphics</see> object used to draw the CAD entities.</param>
		#endregion Help
		public void DrawCADImage(Graphics gr)
		{
			if(FCADImage == null) return;
			try
			{
				deactiv = false;
				Shift();
				RectangleF tmp = new RectangleF(pos.X, pos.Y, curClRect.Width*scale,
					curClRect.Height*scale);
				FCADImage.Draw(gr, tmp);		
			}
			catch(Exception e)
			{ 
				#region debug
				#if DEBUG
					MessageBox.Show("Message [" + e.Message + "]" + (char)13 + e.StackTrace, "CADImport Net debug", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				#endif	
				#endregion debug
				return;
			}
		}

		private void cadPictBox_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			det1 = false;
			cadPictBox.Cursor = Cursors.Default;
			if(this.clipRectangle.Enabled)
				if((this.clipRectangle.Type == RectangleType.Zooming))
				{
					if((this.clipRectangle.ClientRectangle.Width <= 10)||
						(this.clipRectangle.ClientRectangle.Height <= 10)) { cadPictBox.Invalidate(); return; }
					if(this.scale > 1000) { cadPictBox.Invalidate(); return; }
					float tmp1 = this.curClRect.Width / this.clipRectangle.ClientRectangle.Width;
					float tmp2 = this.curClRect.Height / this.clipRectangle.ClientRectangle.Height;
					if(tmp1 > tmp2) tmp1 = tmp2;
					pos.X += this.clipRectangle.ClientRectangle.Width / 2; 
					pos.Y += this.clipRectangle.ClientRectangle.Height / 2; 
					this.Zoom(tmp1);
				}
			cadPictBox.Invalidate();
		}

		private void cadPictBox_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if((e.Button == MouseButtons.Right)||(e.Button == MouseButtons.Middle))
			{
				AddEntityForm.ActiveForm.Cursor = Cursors.Hand;
				cX = e.X;
				cY = e.Y;
				det1 = true;
			}
			else
			{
				if(this.FCADImage != null)
				{
					this.clipRectangle.EnableRect(RectangleType.Zooming, new Rectangle(e.X, e.Y, 0, 0));
				}
			}
		}

		private void cadPictBox_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			cadPictBox.Focus();
			if(FCADImage == null) return;
			if(det1)
			{
				pos.X -= (cX - e.X);
				pos.Y -= (cY - e.Y);
				cX = e.X;
				cY = e.Y;
				cadPictBox.Invalidate();
			}
			old_Pos = new PointF(e.X, e.Y);
			DPoint vPt = GetRealPointUsingsgImagePoint(e.X, e.Y);
			stBar.Panels[2].Text = "" + vPt.X + " : " + vPt.Y + " : 0";
		}

		private DPoint GetRealPointUsingsgImagePoint(float X, float Y)
		{
			Rectangle tmp = new Rectangle();
			tmp = curClRect;
			DRect Rect = new DRect(tmp.Left, tmp.Top,
				tmp.Right, tmp.Bottom);
			float fKoef = (float)(FCADImage.AbsHeight / FCADImage.AbsWidth);
			Rect.left = Rect.left  * scale + pos.X;
			Rect.right = Rect.right * scale + pos.X;
			Rect.top = Rect.top * scale + pos.Y;			
			Rect.bottom = Rect.top  + (Rect.right - Rect.left) *   fKoef;						
			ScaleRect.X = FCADImage.AbsWidth / (Rect.right - Rect.left);
			ScaleRect.Y = FCADImage.AbsHeight / (Rect.bottom - Rect.top);
			DPoint mousePt = new DPoint(0 ,0, 0);
			DPoint newmousePt = new DPoint(0 ,0, 0);
			DPoint pX, pY, pCenter;
			DRect DRectExtentsCAD = FCADImage.Extents;
			mousePt.X = DRectExtentsCAD.left + (X - pos.X) * ScaleRect.X;
			mousePt.Y = DRectExtentsCAD.top  - (Y - pos.Y) * ScaleRect.Y;
			pCenter.X = 0.5f * (DRectExtentsCAD.right + DRectExtentsCAD.left);
			pCenter.Y = 0.5f * (DRectExtentsCAD.top + DRectExtentsCAD.bottom);
			pCenter.Z = 0.5f * (DRectExtentsCAD.z2 + DRectExtentsCAD.z1);
			pX.X = 1; pX.Y = 0;	pX.Z = 0;
			pY.X = 0; pY.Y = 1;	pY.Z = 0;		
			pX = FCADImage.GetRealImagePoint(pX);
			pY = FCADImage.GetRealImagePoint(pY);
			MoveToPosition(ref mousePt, pCenter, -1);
			newmousePt.X = mousePt.X * pX.X + mousePt.Y * pX.Y;
			newmousePt.Y = mousePt.X * pY.X + mousePt.Y * pY.Y;
			MoveToPosition(ref newmousePt, pCenter, +1);
			return newmousePt;
		}

		private void MoveToPosition(ref DPoint point, DPoint aPos, int direction)
		{  
			point.X = point.X + direction * aPos.X;
			point.Y = point.Y + direction * aPos.Y;
			point.Z = point.Z + direction * aPos.Z;
		}

		private void menuItemZoom_Click(object sender, System.EventArgs e)
		{
			if(FCADImage == null) return;
			float i = scale;
			switch((sender as MenuItem).Index)
			{
				case 0:
					i = 0.1f;
					break;
				case 1:
					i = 0.25f;
					break;
				case 2:
					i = 0.5f;
					break;
				case 3:
					i = 1;
					break;
				case 4:
					i = 2;
					break;
				case 5:
					i = 4;
					break;
				case 6:
					i = 8;
					break;
			}
			ResetScaling();
			old_Pos = new PointF(cadPictBox.ClientRectangle.Width / 2, 
				cadPictBox.ClientRectangle.Height / 2);
			scale = i;
			cadPictBox.Invalidate();
			stBar.Panels[1].Text = "" + scale;
		}

		#region Help
		/// <summary>
		/// Paints the CAD image background in the white color.
		/// </summary>
		#endregion Help
		public void White_Click()
		{
			tlbTool.Buttons[3].Pushed = true;
			tlbTool.Buttons[4].Pushed = false;
			cadPictBox.BackColor = Color.White;
			FCADImage.DefaultColor = Color.Black;
			if(this.clipRectangle != null)
				this.clipRectangle.Color = Color.Black;
		}

		#region Help
		/// <summary>
		/// Paints the CAD image background in the black color.
		/// </summary>
		#endregion Help
		public void Black_Click()
		{
			tlbTool.Buttons[3].Pushed = false;
			tlbTool.Buttons[4].Pushed = true;
			cadPictBox.BackColor = Color.Black;
			FCADImage.DefaultColor = Color.White;
			if(this.clipRectangle != null)
				this.clipRectangle.Color = Color.White;
		}

		private void tlbTool_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if((FCADImage == null)&&(tlbTool.Buttons.IndexOf(e.Button) == 8)) return;
			switch(tlbTool.Buttons.IndexOf(e.Button))
			{
				case 0:
					LoadFile(true);
					break; 
				case 1:
					DoZoomIn();
					break; 
				case 2:
					DoZoomOut();
					break;
				case 3:
					White_Click();
					break;
				case 4:
					Black_Click();
					break;
				case 5:
					SetLayList();
					lForm.ShowDialog();
					break;
				case 6:
					sForm = new SelectorForm();
					sForm.ShowDialog();
					break;
				case 7:
					SaveAsImage();
					break;
				case 8:
					if(MessageBox.Show("If you proceed with this operation, all added objects will be lost. Continue?", "CADImport .Net", MessageBoxButtons.YesNo) == DialogResult.Yes)
						ChangeTextsType(! CADConst.UseSHXFonts);
					break;
			}
		}

		private void ChangeTextsType(bool val)
		{
			CADConst.UseSHXFonts = val;
			CADConst.UseTTFFonts = ! val;
			CADConst.UseMultyTTFFonts = ! val;
			this.tlbTool.Buttons[8].Pushed = val;
			this.ReOpen();
		}
	
		#region Help
		/// <summary>
		/// Reopens a file after selecting or deselecting SHX fonts.
		/// </summary>
		/// <remarks>This method is also called when the paths to the 
		/// files containing SHX fonts have been edited in the <b>SHX Paths</b> window 
		/// invoked by the <b>SHX Fonts</b> menu item.</remarks>
		#endregion Help
		public void ReOpen()
		{
			if(openFileDlg.FileName != null)
				if(File.Exists(openFileDlg.FileName))
					this.LoadFile(false);
		}
		#region Help
		/// <summary>
		/// Sets the scale and position of the CAD image to its original values.
		/// </summary>
		#endregion Help
		public void ResetScaling()
		{
			scale = 1.0f;
			prev_scale = 1;
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;
			cadPictBox.Invalidate();
		}

		private void SetLayList()
		{
			if((lForm.lstViewLay.Items.Count != 0)||(FCADImage == null)) return;
			ObjEntity.LayersList = new string[FCADImage.LayersCount];
			string tmp;
			Color colorLay;
			Bitmap b1 = new Bitmap(32, 16);
			lForm.imgColor.Images.Clear();
			lForm.listColor.Items.Clear();
			for(int I = 0; I < FCADImage.LayersCount; I++)
			{
				tmp = FCADImage.GetLayerName(I);
				ObjEntity.LayersList[I] = tmp;
				lForm.lstViewLay.Items.Add(new ListViewItem(new string[1]{tmp}));	
				lForm.lstViewLay.Items[I].Checked = FCADImage.GetLayerVisible(I);

				try
				{
					colorLay = ((CADLayer)FCADImage.Converter.Layers[I]).Color;
					Graphics gr = Graphics.FromImage(b1);
					gr.FillRectangle(new SolidBrush(colorLay), 0, 0, 16, 16);
					gr.DrawRectangle(new Pen(Brushes.Black, 1.2f), 0, 0, 15, 15);
				
					lForm.imgColor.Images.Add((Bitmap)b1.Clone());
					lForm.listColor.Items.Add(new ListViewItem(new string[1]{string.Empty}));
					lForm.listColor.Items[I].ImageIndex = I;
				}
				catch(Exception e)
				{
					MessageBox.Show(e.Message + " - " + e.StackTrace);
				}
			}
			int len = lForm.imgColor.Images.Count * 18 + 18;
			lForm.listColor.Height = len;
			lForm.listColor.Top = 0;
			lForm.lstViewLay.Height = len;
			lForm.lstViewLay.Top = 0;
			lForm.lstViewLay.ItemCheck += dl1;
		}

		#region Help
		/// <summary>
		/// Resizes the CAD image to fit drawing's bounds.
		/// </summary>
		/// <remarks>This method is invoked when changing layout or working with 3D Orbit tool.</remarks>
		#endregion Help
		public void DoResize()
		{			
			if((FCADImage == null)||(deactiv)) return;
			wh = (float)(FCADImage.AbsWidth / FCADImage.AbsHeight); 
			float new_wh = (float)cadPictBox.ClientRectangle.Width / (float)cadPictBox.ClientRectangle.Height;
			curClRect = cadPictBox.ClientRectangle;
			if(new_wh > wh)
				curClRect.Width	= (int)(curClRect.Height * wh);
			else 
			{
				if(new_wh < wh)
					curClRect.Height = (int)(curClRect.Width / wh);
				else
					curClRect = cadPictBox.ClientRectangle;
			}
			pos.X = (cadPictBox.ClientRectangle.Width - curClRect.Width) / 2;
			pos.Y = (cadPictBox.ClientRectangle.Height - curClRect.Height) / 2;				
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Closes a currently open CAD file.
		/// </summary>
		#endregion Help
		public void CloseFile()
		{
			FCADImage.Dispose();
			FCADImage = null;
			EnableButton(false);
		
			this.cadPictBox.Invalidate();
		}
		
		#region Help
		/// <summary>
		/// Makes the layers of the loaded CAD image visible or invisible.
		/// </summary>
		/// <param name="sender">A <see cref="System.Windows.Forms.CheckedListBox">CheckedListBox</see> that initializes changing a visibility of the layers.</param>
		/// <param name="e">An <see cref="System.Windows.Forms.ItemCheckEventArgs">ItemCheckEventArgs</see> object that provides data for the event of changing a layer visibility.</param>
		#endregion Help
		public void chLay_ItemCheck(object sender, System.Windows.Forms.ItemCheckEventArgs e)
		{
			if(e.NewValue == CheckState.Checked)
				FCADImage.SetLayerVisible(e.Index, true);
			else if(e.NewValue == CheckState.Unchecked) 
				FCADImage.SetLayerVisible(e.Index, false);
			cadPictBox.Invalidate();
		}

		#region Help
		/// <summary>
		/// Invokes a <see cref="System.Windows.Forms.SaveFileDialog">SaveFileDialog</see> box where 
		/// a user can select a directory and format for saving a currently open CAD file.
		/// </summary>
		/// <remarks><p>This method can be invoked from the toolbar and from the main menu.</p>
		/// <p>Images can be saved in the following formats: JPG, BMP, TIFF, GIF, EMF.</p></remarks>
		#endregion Help
		public void SaveAsImage()
		{
			if(FCADImage == null) return;
			if(saveImgDlg.ShowDialog() != DialogResult.OK) return;
			DRect tmpRect = new DRect(0, 0, curClRect.Width*scale,curClRect.Height*scale);
			if(saveImgDlg.FileName != null) 
			{
				string tmp = saveImgDlg.FileName;	
				
				if(tmp.ToUpper().IndexOf(".JPG") != -1)
					FCADImage.SaveToFile(saveImgDlg.FileName, ImageFormat.Jpeg, tmpRect);
				if(tmp.ToUpper().IndexOf(".BMP") != -1)
					FCADImage.SaveToFile(saveImgDlg.FileName, ImageFormat.Bmp, tmpRect);
				if(tmp.ToUpper().IndexOf(".TIFF") != -1)
					FCADImage.SaveToFile(saveImgDlg.FileName, ImageFormat.Tiff, tmpRect);
				if(tmp.ToUpper().IndexOf(".GIF") != -1)
					FCADImage.SaveToFile(saveImgDlg.FileName, ImageFormat.Gif, tmpRect);
				if(tmp.ToUpper().IndexOf(".EMF") != -1)
					FCADImage.ExportToMetafile(saveImgDlg.FileName, actForm, tmpRect);
				if(tmp.ToUpper().IndexOf(".DXF") != -1)
				{
					SaveAsDXF(saveImgDlg.FileName);
					return;
				}
			}
			if(! (FCADImage is CADRasterImage))
				this.DoResize();
		}

		private void MainForm_Deactivate(object sender, System.EventArgs e)
		{
			det1 = false;
		}

		private void MainForm_Resize(object sender, System.EventArgs e)
		{
			DoResize();
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			#region protect
			#if protect
			#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.DisableFloating();
			}
			else
			{
				Protection.CloseApplication();
			}
			#else
				Protection.CloseApplication();
			#endif
			#endif
			#endregion
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			wh = 1f;
			frmSHX.AddDefaultSHXPaths();
			curClRect = cadPictBox.ClientRectangle;
			#region protect
#if protect
#if floatprotect
			if(Protection.LicenseType == LicenseType.Floating)
			{
				this.floatLicFrm.FloatingLicRegister();
			}
			else	
			{
				Protection.Register();
			}
#else
			Protection.Register();
#endif
#endif
			#endregion
			if(this.openFileDlg.FileName != null)
				if(File.Exists(this.openFileDlg.FileName))
					LoadFile(false);
			#region demo
			#if Demo
				DemoForm d1 = new DemoForm();
				d1.ShowDialog();
			#endif
			#endregion demo
		}

		private void addCircleMenuItem_Click(object sender, EventArgs e)
		{
			aCForm = new AddCircleForm();
			aCForm.ShowDialog();
		}

		private void addLineMenuItem_Click(object sender, EventArgs e)
		{
			aLForm = new AddLineForm();
			aLForm.ShowDialog();
		}

		private void addPolyLineMenuItem_Click(object sender, EventArgs e)
		{
			aPForm = new AddPolyForm();
			aPForm.ShowDialog();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			aboutForm.ShowDialog();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			LoadFile(true);
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			aTForm = new AddTextForm();
			aTForm.ShowDialog();
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			aMTForm = new AddMTextForm();
			aMTForm.ShowDialog();
		}

		private void mSaveAsDXF_Click(object sender, System.EventArgs e)
		{
			if(this.FCADImage == null) return;
			if(this.saveDXFDlg.ShowDialog() != DialogResult.OK) return;
			SaveAsDXF(this.saveDXFDlg.FileName);
		}

		private void SaveAsDXF(string fName)
		{
			#region Export
#if Export
			if(FCADImage == null) return;
			if(FCADImage is CADRasterImage) 
			{
				return;
			}
			CADtoDXFModule.CADtoDXF vExp = new CADtoDXFModule.CADtoDXF(FCADImage);
			vExp.SaveToFile(fName);
#else
				MessageBox.Show("Not supported in current version!", "CADImport .Net");
#endif
			#endregion Export

			#region ExportOverMetafile 
			/*#region Export
#if Export
				if(! (this.FCADImage is RasterImage.CADRasterImage)) 
					this.FCADImage.SaveAsDXF(fName, this.cadPictBox.Handle, actForm);
				else
					MessageBox.Show("This operation is not supported for current file format", "CADImport .Net");
#else
					MessageBox.Show("Not supported in current version!", "CADImport .Net");
#endif
			#endregion Export*/
			#endregion
		}


		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			this.frmSHX.ShowDialog();
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			#region protect
			#if protect
				regFrm.ShowDialog();
			#endif
			#endregion protect
		}

		private void miFloatLic_Click(object sender, System.EventArgs e)
		{
			#region protect
			#if floatprotect
				floatLicFrm.ShowDialog();
			#endif
			#endregion
		}
	}
}
