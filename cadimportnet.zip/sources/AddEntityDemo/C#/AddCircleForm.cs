using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CADImport;
using CADImportForm;

namespace AddEntityDemoApplication
{
	#region Help
	/// <summary>
	/// Represents a form in which the properties of the circle are set 
	/// before adding it to the current CAD image.
	/// </summary>
	#endregion Help
	public class AddCircleForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button addCircleOK;
		private System.Windows.Forms.Button addCircleCancel;
		private System.Windows.Forms.Label colorLab;
		private System.Windows.Forms.TextBox colorTB;
		private System.Windows.Forms.Button pickColorButton;
		private ColorDialog setColorDlg;
		private CADCircle circle;
		private System.Windows.Forms.Label Xlab;
		private System.Windows.Forms.Label Ylab;
		private System.Windows.Forms.Label Zlab;
		private System.Windows.Forms.TextBox XTb;
		private System.Windows.Forms.TextBox YTb;
		private System.Windows.Forms.TextBox ZTb;
		private System.Windows.Forms.TextBox radTb;
		private System.Windows.Forms.Label radLab;
		private System.Windows.Forms.Label lWlab;
		private System.Windows.Forms.ComboBox cBox;
	
		private System.ComponentModel.Container components = null;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="AddEntityDemoApplication.AddCircleForm">AddCircleForm</see> class.
		/// </summary>
		#endregion Help
		public AddCircleForm()
		{
			InitializeComponent();
			setColorDlg = new ColorDialog();
			this.cBox.SelectedItem = "1";
			this.colorTB.Enabled = false;
			this.StartPosition = FormStartPosition.CenterScreen;
		}
		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.addCircleOK = new System.Windows.Forms.Button();
			this.addCircleCancel = new System.Windows.Forms.Button();
			this.colorLab = new System.Windows.Forms.Label();
			this.colorTB = new System.Windows.Forms.TextBox();
			this.pickColorButton = new System.Windows.Forms.Button();
			this.XTb = new System.Windows.Forms.TextBox();
			this.YTb = new System.Windows.Forms.TextBox();
			this.ZTb = new System.Windows.Forms.TextBox();
			this.Xlab = new System.Windows.Forms.Label();
			this.Ylab = new System.Windows.Forms.Label();
			this.Zlab = new System.Windows.Forms.Label();
			this.radTb = new System.Windows.Forms.TextBox();
			this.radLab = new System.Windows.Forms.Label();
			this.lWlab = new System.Windows.Forms.Label();
			this.cBox = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// addCircleOK
			// 
			this.addCircleOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addCircleOK.Location = new System.Drawing.Point(96, 216);
			this.addCircleOK.Name = "addCircleOK";
			this.addCircleOK.Size = new System.Drawing.Size(75, 25);
			this.addCircleOK.TabIndex = 0;
			this.addCircleOK.Text = "OK";
			this.addCircleOK.Click += new System.EventHandler(this.addCircleOK_Click);
			// 
			// addCircleCancel
			// 
			this.addCircleCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addCircleCancel.Location = new System.Drawing.Point(185, 216);
			this.addCircleCancel.Name = "addCircleCancel";
			this.addCircleCancel.Size = new System.Drawing.Size(75, 25);
			this.addCircleCancel.TabIndex = 1;
			this.addCircleCancel.Text = "Cancel";
			this.addCircleCancel.Click += new System.EventHandler(this.addCircleCancel_Click);
			// 
			// colorLab
			// 
			this.colorLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.colorLab.Location = new System.Drawing.Point(8, 16);
			this.colorLab.Name = "colorLab";
			this.colorLab.Size = new System.Drawing.Size(56, 23);
			this.colorLab.TabIndex = 2;
			this.colorLab.Text = "Color :";
			// 
			// colorTB
			// 
			this.colorTB.BackColor = System.Drawing.Color.Black;
			this.colorTB.Location = new System.Drawing.Point(96, 16);
			this.colorTB.Multiline = true;
			this.colorTB.Name = "colorTB";
			this.colorTB.Size = new System.Drawing.Size(75, 25);
			this.colorTB.TabIndex = 3;
			this.colorTB.Text = "";
			// 
			// pickColorButton
			// 
			this.pickColorButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.pickColorButton.Location = new System.Drawing.Point(185, 16);
			this.pickColorButton.Name = "pickColorButton";
			this.pickColorButton.Size = new System.Drawing.Size(75, 25);
			this.pickColorButton.TabIndex = 4;
			this.pickColorButton.Text = "Pick a color";
			this.pickColorButton.Click += new System.EventHandler(this.pickColorButton_Click);
			// 
			// XTb
			// 
			this.XTb.Location = new System.Drawing.Point(185, 120);
			this.XTb.Name = "XTb";
			this.XTb.Size = new System.Drawing.Size(75, 20);
			this.XTb.TabIndex = 5;
			this.XTb.Text = "100,0";
			// 
			// YTb
			// 
			this.YTb.Location = new System.Drawing.Point(185, 152);
			this.YTb.Name = "YTb";
			this.YTb.Size = new System.Drawing.Size(75, 20);
			this.YTb.TabIndex = 6;
			this.YTb.Text = "100,0";
			// 
			// ZTb
			// 
			this.ZTb.Location = new System.Drawing.Point(185, 184);
			this.ZTb.Name = "ZTb";
			this.ZTb.Size = new System.Drawing.Size(75, 20);
			this.ZTb.TabIndex = 7;
			this.ZTb.Text = "0,0";
			// 
			// Xlab
			// 
			this.Xlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Xlab.Location = new System.Drawing.Point(8, 120);
			this.Xlab.Name = "Xlab";
			this.Xlab.Size = new System.Drawing.Size(168, 20);
			this.Xlab.TabIndex = 8;
			this.Xlab.Text = "X coordinate of the center :";
			// 
			// Ylab
			// 
			this.Ylab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Ylab.Location = new System.Drawing.Point(8, 152);
			this.Ylab.Name = "Ylab";
			this.Ylab.Size = new System.Drawing.Size(168, 20);
			this.Ylab.TabIndex = 9;
			this.Ylab.Text = "Y coordinate of the center :";
			// 
			// Zlab
			// 
			this.Zlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Zlab.Location = new System.Drawing.Point(8, 184);
			this.Zlab.Name = "Zlab";
			this.Zlab.Size = new System.Drawing.Size(168, 20);
			this.Zlab.TabIndex = 10;
			this.Zlab.Text = "Z coordinate of the center :";
			// 
			// radTb
			// 
			this.radTb.Location = new System.Drawing.Point(185, 88);
			this.radTb.Name = "radTb";
			this.radTb.Size = new System.Drawing.Size(75, 20);
			this.radTb.TabIndex = 11;
			this.radTb.Text = "100,0";
			// 
			// radLab
			// 
			this.radLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radLab.Location = new System.Drawing.Point(8, 88);
			this.radLab.Name = "radLab";
			this.radLab.Size = new System.Drawing.Size(136, 20);
			this.radLab.TabIndex = 12;
			this.radLab.Text = "Radius of the circle :";
			// 
			// lWlab
			// 
			this.lWlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lWlab.Location = new System.Drawing.Point(8, 56);
			this.lWlab.Name = "lWlab";
			this.lWlab.Size = new System.Drawing.Size(88, 20);
			this.lWlab.TabIndex = 14;
			this.lWlab.Text = "Line weight :";
			// 
			// cBox
			// 
			this.cBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBox.Items.AddRange(new object[] {
													  "1",
													  "2",
													  "3",
													  "4",
													  "5",
													  "6",
													  "7",
													  "8",
													  "9",
													  "10",
													  "11",
													  "12",
													  "13",
													  "14",
													  "15",
													  "16",
													  "17",
													  "18",
													  "19",
													  "20",
													  "21",
													  "22",
													  "23",
													  "24",
													  "25",
													  "26",
													  "27",
													  "28",
													  "29",
													  "30",
													  "31",
													  "32",
													  "33",
													  "34",
													  "35",
													  "36",
													  "37",
													  "38",
													  "39",
													  "40",
													  "41",
													  "42",
													  "43",
													  "44",
													  "45",
													  "46",
													  "47",
													  "48",
													  "49",
													  "50",
													  "51",
													  "52",
													  "53",
													  "54",
													  "55",
													  "56",
													  "57",
													  "58",
													  "59",
													  "60",
													  "61",
													  "62",
													  "63",
													  "64",
													  "65",
													  "66",
													  "67",
													  "68",
													  "69",
													  "70",
													  "71",
													  "72",
													  "73",
													  "74",
													  "75",
													  "76",
													  "77",
													  "78",
													  "79",
													  "80",
													  "81",
													  "82",
													  "83",
													  "84",
													  "85",
													  "86",
													  "87",
													  "88",
													  "89",
													  "90",
													  "91",
													  "92",
													  "93",
													  "94",
													  "95",
													  "96",
													  "97",
													  "98",
													  "99",
													  "100"});
			this.cBox.Location = new System.Drawing.Point(185, 56);
			this.cBox.Name = "cBox";
			this.cBox.Size = new System.Drawing.Size(75, 21);
			this.cBox.TabIndex = 15;
			// 
			// AddCircleForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(272, 251);
			this.Controls.Add(this.cBox);
			this.Controls.Add(this.lWlab);
			this.Controls.Add(this.radLab);
			this.Controls.Add(this.radTb);
			this.Controls.Add(this.ZTb);
			this.Controls.Add(this.YTb);
			this.Controls.Add(this.XTb);
			this.Controls.Add(this.colorTB);
			this.Controls.Add(this.Zlab);
			this.Controls.Add(this.Ylab);
			this.Controls.Add(this.Xlab);
			this.Controls.Add(this.pickColorButton);
			this.Controls.Add(this.colorLab);
			this.Controls.Add(this.addCircleCancel);
			this.Controls.Add(this.addCircleOK);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MinimizeBox = false;
			this.Name = "AddCircleForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Add Circle";
			this.ResumeLayout(false);

		}
		#endregion

		private void addCircleOK_Click(object sender, System.EventArgs e)
		{
			circle = new CADCircle();
			if(setColorDlg.Color == Color.Black)
				circle.Color = CADConst.clNone;
			else
				circle.Color = setColorDlg.Color;
			try
			{
				circle.Radius = Convert.ToDouble(this.radTb.Text);
				circle.Point = new DPoint(Convert.ToDouble(this.XTb.Text), Convert.ToDouble(this.YTb.Text), Convert.ToDouble(this.ZTb.Text));
				circle.LineWeight = Convert.ToInt16(this.cBox.Text);
				AddEntityForm.actForm.FCADImage.Converter.GetSection(ConvSection.Entities).AddEntity(circle);
				AddEntityForm.actForm.FCADImage.Converter.OnCreate(circle);
				AddEntityForm.actForm.FCADImage.Converter.Loads(circle);
				AddEntityForm.actForm.FCADImage.GetExtents();
				AddEntityForm.actForm.DoResize();
			}
			catch(FormatException exception)
			{
				MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			
			AddEntityForm.actForm.Invalidate();
			this.Close();
		}

		private void addCircleCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void pickColorButton_Click(object sender, EventArgs e)
		{
			if(setColorDlg.ShowDialog() == DialogResult.OK)
			{
				this.colorTB.BackColor = setColorDlg.Color;
			}
		}
	}
}
