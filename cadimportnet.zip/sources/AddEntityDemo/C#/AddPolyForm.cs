using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CADImport;
using CADImportForm;

namespace AddEntityDemoApplication
{
	#region Help
	/// <summary>
	/// Represents a form in which the properties of the polyline are set 
	/// before adding it to the current CAD image.
	/// </summary>
	#endregion Help
	public class AddPolyForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button pickColorButton;
		private System.Windows.Forms.TextBox colorTB;
		private System.Windows.Forms.Label colorLab;
		private System.Windows.Forms.Label Ylab;
		private System.Windows.Forms.Label Zlab;
		private System.Windows.Forms.Label Xlab;
		private System.Windows.Forms.TextBox ZTb2;
		private System.Windows.Forms.TextBox YTb2;
		private System.Windows.Forms.TextBox XTb2;
		private System.Windows.Forms.TextBox ZTb;
		private System.Windows.Forms.TextBox YTb;
		private System.Windows.Forms.TextBox XTb;
		private System.Windows.Forms.Label secLab;
		private System.Windows.Forms.Label firstLab;
		private System.Windows.Forms.Label line5;
		private System.Windows.Forms.Label line4;
		private System.Windows.Forms.Label line3;
		private System.Windows.Forms.Label line2;
		private System.Windows.Forms.Label line1;
		private System.Windows.Forms.Label vertLine2;
		private System.Windows.Forms.Label vertLine1;
		private System.Windows.Forms.Label vertNum;
		private System.Windows.Forms.ComboBox cBox;
		private System.Windows.Forms.Label lWlab;
		private System.Windows.Forms.Button addVertBut;
		private System.Windows.Forms.Button addPolyCancel;
		private System.Windows.Forms.Button addPolyOK;
		private ColorDialog setColorDlg;
		private CADPolyLine poly;
		private System.Windows.Forms.TextBox vertNumTb;
		private CADVertex vert0; 
		private CADVertex vertNext;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		
		private System.ComponentModel.Container components = null;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="AddEntityDemoApplication.AddPolyForm">AddPolyForm</see> class.
		/// </summary>
		#endregion Help
		public AddPolyForm()
		{
			InitializeComponent();
			setColorDlg = new ColorDialog();
			SetDefaut();
		}

		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pickColorButton = new System.Windows.Forms.Button();
			this.colorTB = new System.Windows.Forms.TextBox();
			this.colorLab = new System.Windows.Forms.Label();
			this.Ylab = new System.Windows.Forms.Label();
			this.Zlab = new System.Windows.Forms.Label();
			this.Xlab = new System.Windows.Forms.Label();
			this.ZTb2 = new System.Windows.Forms.TextBox();
			this.YTb2 = new System.Windows.Forms.TextBox();
			this.XTb2 = new System.Windows.Forms.TextBox();
			this.ZTb = new System.Windows.Forms.TextBox();
			this.YTb = new System.Windows.Forms.TextBox();
			this.XTb = new System.Windows.Forms.TextBox();
			this.secLab = new System.Windows.Forms.Label();
			this.firstLab = new System.Windows.Forms.Label();
			this.line5 = new System.Windows.Forms.Label();
			this.line4 = new System.Windows.Forms.Label();
			this.line3 = new System.Windows.Forms.Label();
			this.line2 = new System.Windows.Forms.Label();
			this.line1 = new System.Windows.Forms.Label();
			this.vertLine2 = new System.Windows.Forms.Label();
			this.vertLine1 = new System.Windows.Forms.Label();
			this.vertNum = new System.Windows.Forms.Label();
			this.vertNumTb = new System.Windows.Forms.TextBox();
			this.addVertBut = new System.Windows.Forms.Button();
			this.cBox = new System.Windows.Forms.ComboBox();
			this.lWlab = new System.Windows.Forms.Label();
			this.addPolyCancel = new System.Windows.Forms.Button();
			this.addPolyOK = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pickColorButton
			// 
			this.pickColorButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.pickColorButton.Location = new System.Drawing.Point(204, 8);
			this.pickColorButton.Name = "pickColorButton";
			this.pickColorButton.Size = new System.Drawing.Size(75, 25);
			this.pickColorButton.TabIndex = 10;
			this.pickColorButton.Text = "Pick a color";
			this.pickColorButton.Click += new System.EventHandler(this.pickColorButton_Click);
			// 
			// colorTB
			// 
			this.colorTB.BackColor = System.Drawing.Color.Black;
			this.colorTB.Location = new System.Drawing.Point(104, 8);
			this.colorTB.Multiline = true;
			this.colorTB.Name = "colorTB";
			this.colorTB.Size = new System.Drawing.Size(72, 23);
			this.colorTB.TabIndex = 9;
			this.colorTB.Text = "";
			// 
			// colorLab
			// 
			this.colorLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.colorLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.colorLab.Location = new System.Drawing.Point(8, 8);
			this.colorLab.Name = "colorLab";
			this.colorLab.Size = new System.Drawing.Size(56, 23);
			this.colorLab.TabIndex = 8;
			this.colorLab.Text = "Color :";
			// 
			// Ylab
			// 
			this.Ylab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Ylab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Ylab.Location = new System.Drawing.Point(8, 136);
			this.Ylab.Name = "Ylab";
			this.Ylab.Size = new System.Drawing.Size(98, 20);
			this.Ylab.TabIndex = 18;
			this.Ylab.Text = "Y coordinate :";
			this.Ylab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Zlab
			// 
			this.Zlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Zlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Zlab.Location = new System.Drawing.Point(8, 168);
			this.Zlab.Name = "Zlab";
			this.Zlab.Size = new System.Drawing.Size(98, 20);
			this.Zlab.TabIndex = 19;
			this.Zlab.Text = "Z coordinate :";
			this.Zlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Xlab
			// 
			this.Xlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Xlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Xlab.Location = new System.Drawing.Point(8, 104);
			this.Xlab.Name = "Xlab";
			this.Xlab.Size = new System.Drawing.Size(98, 20);
			this.Xlab.TabIndex = 17;
			this.Xlab.Text = "X coordinate :";
			this.Xlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ZTb2
			// 
			this.ZTb2.Location = new System.Drawing.Point(208, 168);
			this.ZTb2.Name = "ZTb2";
			this.ZTb2.Size = new System.Drawing.Size(56, 20);
			this.ZTb2.TabIndex = 25;
			this.ZTb2.Text = "0,0";
			// 
			// YTb2
			// 
			this.YTb2.Location = new System.Drawing.Point(208, 136);
			this.YTb2.Name = "YTb2";
			this.YTb2.Size = new System.Drawing.Size(56, 20);
			this.YTb2.TabIndex = 24;
			this.YTb2.Text = "0,0";
			// 
			// XTb2
			// 
			this.XTb2.Location = new System.Drawing.Point(208, 104);
			this.XTb2.Name = "XTb2";
			this.XTb2.Size = new System.Drawing.Size(56, 20);
			this.XTb2.TabIndex = 23;
			this.XTb2.Text = "0,0";
			// 
			// ZTb
			// 
			this.ZTb.Location = new System.Drawing.Point(120, 168);
			this.ZTb.Name = "ZTb";
			this.ZTb.Size = new System.Drawing.Size(56, 20);
			this.ZTb.TabIndex = 22;
			this.ZTb.Text = "0,0";
			// 
			// YTb
			// 
			this.YTb.Location = new System.Drawing.Point(120, 136);
			this.YTb.Name = "YTb";
			this.YTb.Size = new System.Drawing.Size(56, 20);
			this.YTb.TabIndex = 21;
			this.YTb.Text = "0,0";
			// 
			// XTb
			// 
			this.XTb.Location = new System.Drawing.Point(120, 104);
			this.XTb.Name = "XTb";
			this.XTb.Size = new System.Drawing.Size(56, 20);
			this.XTb.TabIndex = 20;
			this.XTb.Text = "0,0";
			// 
			// secLab
			// 
			this.secLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.secLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.secLab.Location = new System.Drawing.Point(199, 76);
			this.secLab.Name = "secLab";
			this.secLab.Size = new System.Drawing.Size(88, 23);
			this.secLab.TabIndex = 27;
			this.secLab.Text = "Next vertex";
			// 
			// firstLab
			// 
			this.firstLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.firstLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.firstLab.Location = new System.Drawing.Point(109, 76);
			this.firstLab.Name = "firstLab";
			this.firstLab.Size = new System.Drawing.Size(88, 23);
			this.firstLab.TabIndex = 26;
			this.firstLab.Text = "First vertex";
			// 
			// line5
			// 
			this.line5.BackColor = System.Drawing.Color.Black;
			this.line5.Location = new System.Drawing.Point(12, 192);
			this.line5.Name = "line5";
			this.line5.Size = new System.Drawing.Size(265, 1);
			this.line5.TabIndex = 32;
			// 
			// line4
			// 
			this.line4.BackColor = System.Drawing.Color.Black;
			this.line4.Location = new System.Drawing.Point(12, 160);
			this.line4.Name = "line4";
			this.line4.Size = new System.Drawing.Size(266, 1);
			this.line4.TabIndex = 31;
			// 
			// line3
			// 
			this.line3.BackColor = System.Drawing.Color.Black;
			this.line3.Location = new System.Drawing.Point(12, 128);
			this.line3.Name = "line3";
			this.line3.Size = new System.Drawing.Size(266, 1);
			this.line3.TabIndex = 30;
			// 
			// line2
			// 
			this.line2.BackColor = System.Drawing.Color.Black;
			this.line2.Location = new System.Drawing.Point(12, 96);
			this.line2.Name = "line2";
			this.line2.Size = new System.Drawing.Size(266, 1);
			this.line2.TabIndex = 29;
			// 
			// line1
			// 
			this.line1.BackColor = System.Drawing.Color.Black;
			this.line1.Location = new System.Drawing.Point(12, 72);
			this.line1.Name = "line1";
			this.line1.Size = new System.Drawing.Size(265, 1);
			this.line1.TabIndex = 28;
			// 
			// vertLine2
			// 
			this.vertLine2.BackColor = System.Drawing.Color.Black;
			this.vertLine2.Location = new System.Drawing.Point(184, 72);
			this.vertLine2.Name = "vertLine2";
			this.vertLine2.Size = new System.Drawing.Size(1, 120);
			this.vertLine2.TabIndex = 34;
			// 
			// vertLine1
			// 
			this.vertLine1.BackColor = System.Drawing.Color.Black;
			this.vertLine1.Location = new System.Drawing.Point(104, 72);
			this.vertLine1.Name = "vertLine1";
			this.vertLine1.Size = new System.Drawing.Size(1, 120);
			this.vertLine1.TabIndex = 33;
			// 
			// vertNum
			// 
			this.vertNum.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.vertNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.vertNum.Location = new System.Drawing.Point(8, 208);
			this.vertNum.Name = "vertNum";
			this.vertNum.Size = new System.Drawing.Size(128, 23);
			this.vertNum.TabIndex = 35;
			this.vertNum.Text = "Number of vertices :";
			// 
			// vertNumTb
			// 
			this.vertNumTb.Location = new System.Drawing.Point(136, 208);
			this.vertNumTb.Name = "vertNumTb";
			this.vertNumTb.Size = new System.Drawing.Size(56, 20);
			this.vertNumTb.TabIndex = 36;
			this.vertNumTb.Text = "";
			// 
			// addVertBut
			// 
			this.addVertBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addVertBut.Location = new System.Drawing.Point(204, 40);
			this.addVertBut.Name = "addVertBut";
			this.addVertBut.Size = new System.Drawing.Size(75, 25);
			this.addVertBut.TabIndex = 37;
			this.addVertBut.Text = "Add vertex";
			this.addVertBut.Click += new System.EventHandler(this.addVertBut_Click);
			// 
			// cBox
			// 
			this.cBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBox.Items.AddRange(new object[] {
													  "1",
													  "2",
													  "3",
													  "4",
													  "5",
													  "6",
													  "7",
													  "8",
													  "9",
													  "10",
													  "11",
													  "12",
													  "13",
													  "14",
													  "15",
													  "16",
													  "17",
													  "18",
													  "19",
													  "20",
													  "21",
													  "22",
													  "23",
													  "24",
													  "25",
													  "26",
													  "27",
													  "28",
													  "29",
													  "30",
													  "31",
													  "32",
													  "33",
													  "34",
													  "35",
													  "36",
													  "37",
													  "38",
													  "39",
													  "40",
													  "41",
													  "42",
													  "43",
													  "44",
													  "45",
													  "46",
													  "47",
													  "48",
													  "49",
													  "50",
													  "51",
													  "52",
													  "53",
													  "54",
													  "55",
													  "56",
													  "57",
													  "58",
													  "59",
													  "60",
													  "61",
													  "62",
													  "63",
													  "64",
													  "65",
													  "66",
													  "67",
													  "68",
													  "69",
													  "70",
													  "71",
													  "72",
													  "73",
													  "74",
													  "75",
													  "76",
													  "77",
													  "78",
													  "79",
													  "80",
													  "81",
													  "82",
													  "83",
													  "84",
													  "85",
													  "86",
													  "87",
													  "88",
													  "89",
													  "90",
													  "91",
													  "92",
													  "93",
													  "94",
													  "95",
													  "96",
													  "97",
													  "98",
													  "99",
													  "100"});
			this.cBox.Location = new System.Drawing.Point(104, 40);
			this.cBox.Name = "cBox";
			this.cBox.Size = new System.Drawing.Size(72, 21);
			this.cBox.TabIndex = 39;
			// 
			// lWlab
			// 
			this.lWlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lWlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lWlab.Location = new System.Drawing.Point(8, 40);
			this.lWlab.Name = "lWlab";
			this.lWlab.Size = new System.Drawing.Size(88, 20);
			this.lWlab.TabIndex = 38;
			this.lWlab.Text = "Line weight :";
			// 
			// addPolyCancel
			// 
			this.addPolyCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addPolyCancel.Location = new System.Drawing.Point(205, 238);
			this.addPolyCancel.Name = "addPolyCancel";
			this.addPolyCancel.Size = new System.Drawing.Size(75, 25);
			this.addPolyCancel.TabIndex = 41;
			this.addPolyCancel.Text = "Cancel";
			this.addPolyCancel.Click += new System.EventHandler(this.addPolyCancel_Click);
			// 
			// addPolyOK
			// 
			this.addPolyOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addPolyOK.Location = new System.Drawing.Point(125, 238);
			this.addPolyOK.Name = "addPolyOK";
			this.addPolyOK.Size = new System.Drawing.Size(75, 25);
			this.addPolyOK.TabIndex = 40;
			this.addPolyOK.Text = "OK";
			this.addPolyOK.Click += new System.EventHandler(this.addPolyOK_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(11, 73);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(1, 120);
			this.label1.TabIndex = 42;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Black;
			this.label2.Location = new System.Drawing.Point(277, 73);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(1, 120);
			this.label2.TabIndex = 43;
			// 
			// AddPolyForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 267);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.addPolyCancel);
			this.Controls.Add(this.addPolyOK);
			this.Controls.Add(this.cBox);
			this.Controls.Add(this.lWlab);
			this.Controls.Add(this.addVertBut);
			this.Controls.Add(this.vertNumTb);
			this.Controls.Add(this.ZTb2);
			this.Controls.Add(this.YTb2);
			this.Controls.Add(this.XTb2);
			this.Controls.Add(this.ZTb);
			this.Controls.Add(this.YTb);
			this.Controls.Add(this.XTb);
			this.Controls.Add(this.colorTB);
			this.Controls.Add(this.vertNum);
			this.Controls.Add(this.vertLine2);
			this.Controls.Add(this.vertLine1);
			this.Controls.Add(this.line5);
			this.Controls.Add(this.line4);
			this.Controls.Add(this.line3);
			this.Controls.Add(this.line2);
			this.Controls.Add(this.line1);
			this.Controls.Add(this.firstLab);
			this.Controls.Add(this.Ylab);
			this.Controls.Add(this.Zlab);
			this.Controls.Add(this.Xlab);
			this.Controls.Add(this.pickColorButton);
			this.Controls.Add(this.colorLab);
			this.Controls.Add(this.secLab);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "AddPolyForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Add Polyline";
			this.Load += new System.EventHandler(this.AddPolyForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void pickColorButton_Click(object sender, System.EventArgs e)
		{
			if(setColorDlg.ShowDialog() == DialogResult.OK)
			{
				this.colorTB.BackColor = setColorDlg.Color;
			}
		}

		private void addVertBut_Click(object sender, System.EventArgs e)
		{
			if(poly.Entities.Count == 0)
			{
				vert0 = new CADVertex();
				vertNext = new CADVertex();
				try
				{
					vert0.Point = new DPoint(Convert.ToDouble(this.XTb.Text), Convert.ToDouble(this.YTb.Text), Convert.ToDouble(this.ZTb.Text));
					poly.Entities.Add(vert0);
					vertNumTb.Text = poly.Entities.Count.ToString();
					this.XTb.Enabled = false;
					this.YTb.Enabled = false;
					this.ZTb.Enabled = false;
					this.XTb2.Enabled = true;
					this.YTb2.Enabled = true;
					this.ZTb2.Enabled = true;
				}
				catch(FormatException exception)
				{
					MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			else
			{
				vertNext = new CADVertex();
				try
				{
					vertNext.Point = new DPoint(Convert.ToDouble(this.XTb2.Text), Convert.ToDouble(this.YTb2.Text), Convert.ToDouble(this.ZTb2.Text));
					poly.Entities.Add(vertNext);
					vertNumTb.Text = poly.Entities.Count.ToString();
				}
				catch(FormatException exception)
				{
					MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
		}

		private void addPolyOK_Click(object sender, System.EventArgs e)
		{
			if(poly.Entities.Count == 0)
			{
				MessageBox.Show("Can't add a polyline with no vertices. Please, add a vertex first.", "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				if(setColorDlg.Color == Color.Black)
					poly.Color = CADConst.clNone;
				else
					poly.Color = setColorDlg.Color;
				try
				{
					poly.LineWeight = Convert.ToInt16(this.cBox.Text);
					AddEntityForm.actForm.FCADImage.Converter.GetSection(ConvSection.Entities).AddEntity(poly);
					AddEntityForm.actForm.FCADImage.Converter.OnCreate(poly);
					AddEntityForm.actForm.FCADImage.Converter.Loads(poly);
					AddEntityForm.actForm.FCADImage.GetExtents();
					AddEntityForm.actForm.DoResize();
				}
				catch(FormatException exception)
				{
					MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				AddEntityForm.actForm.Invalidate();
				this.Close();
			}
		}

		private void addPolyCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void AddPolyForm_Load(object sender, System.EventArgs e)
		{
			if(poly.Entities.Count != 0)
				SetDefaut();
		}

		private void SetDefaut()
		{
			this.cBox.SelectedItem = "1";
			this.colorTB.Enabled = false;
			this.vertNumTb.ReadOnly = true;
			poly = new CADPolyLine();
			vertNumTb.BackColor = Color.White;
			vertNumTb.Text = poly.Entities.Count.ToString();
			this.StartPosition = FormStartPosition.CenterScreen;
			this.XTb2.Enabled = false;
			this.YTb2.Enabled = false;
			this.ZTb2.Enabled = false;
			this.XTb.Enabled = true;
			this.YTb.Enabled = true;
			this.ZTb.Enabled = true;
		}
	}
}
