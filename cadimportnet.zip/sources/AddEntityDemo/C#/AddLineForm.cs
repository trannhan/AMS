using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CADImport;
using CADImportForm;

namespace AddEntityDemoApplication
{
	#region Help
	/// <summary>
	/// Represents a form in which the properties of the line are set 
	/// before adding it to the current CAD image.
	/// </summary>
	#endregion Help
	public class AddLineForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button pickColorButton;
		private System.Windows.Forms.TextBox colorTB;
		private System.Windows.Forms.Label colorLab;
		private System.Windows.Forms.TextBox ZTb;
		private System.Windows.Forms.TextBox YTb;
		private System.Windows.Forms.TextBox XTb;
		private System.Windows.Forms.Label Xlab;
		private System.Windows.Forms.Label Ylab;
		private System.Windows.Forms.Label Zlab;
		private System.Windows.Forms.Label firstLab;
		private ColorDialog setColorDlg;
		private CADLine line;
		private System.Windows.Forms.Label secLab;
		private System.Windows.Forms.Label line1;
		private System.Windows.Forms.Label line2;
		private System.Windows.Forms.Label line3;
		private System.Windows.Forms.Label line4;
		private System.Windows.Forms.Label line5;
		private System.Windows.Forms.Label vertLine1;
		private System.Windows.Forms.Label vertLine2;
		private System.Windows.Forms.ComboBox cBox;
		private System.Windows.Forms.Label lWlab;
		private System.Windows.Forms.TextBox ZTb2;
		private System.Windows.Forms.TextBox YTb2;
		private System.Windows.Forms.TextBox XTb2;
		private System.Windows.Forms.Button addLineCancel;
		private System.Windows.Forms.Button addLineOK;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;

		private System.ComponentModel.Container components = null;

		#region Help
		/// <summary>
		/// Initializes a new instance of the <see cref="AddEntityDemoApplication.AddLineForm">AddLineForm</see> class.
		/// </summary>
		#endregion Help
		public AddLineForm()
		{
			InitializeComponent();
			setColorDlg = new ColorDialog();
			this.cBox.SelectedItem = "1";
			this.colorTB.Enabled = false;
			this.StartPosition = FormStartPosition.CenterScreen;
		}
		
		#region Help
		/// <summary>
		/// Cleans up any resources being used.
		/// </summary>
		/// <param name="disposing">A value indicating if both managed and unmanaged resources have to be released (<b>true</b>) or only unmanaged (<b>false</b>). 
		///</param>
		#endregion Help
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pickColorButton = new System.Windows.Forms.Button();
			this.colorTB = new System.Windows.Forms.TextBox();
			this.colorLab = new System.Windows.Forms.Label();
			this.ZTb = new System.Windows.Forms.TextBox();
			this.YTb = new System.Windows.Forms.TextBox();
			this.XTb = new System.Windows.Forms.TextBox();
			this.Ylab = new System.Windows.Forms.Label();
			this.Zlab = new System.Windows.Forms.Label();
			this.Xlab = new System.Windows.Forms.Label();
			this.ZTb2 = new System.Windows.Forms.TextBox();
			this.YTb2 = new System.Windows.Forms.TextBox();
			this.XTb2 = new System.Windows.Forms.TextBox();
			this.firstLab = new System.Windows.Forms.Label();
			this.secLab = new System.Windows.Forms.Label();
			this.line1 = new System.Windows.Forms.Label();
			this.line2 = new System.Windows.Forms.Label();
			this.line3 = new System.Windows.Forms.Label();
			this.line4 = new System.Windows.Forms.Label();
			this.line5 = new System.Windows.Forms.Label();
			this.vertLine1 = new System.Windows.Forms.Label();
			this.vertLine2 = new System.Windows.Forms.Label();
			this.cBox = new System.Windows.Forms.ComboBox();
			this.lWlab = new System.Windows.Forms.Label();
			this.addLineCancel = new System.Windows.Forms.Button();
			this.addLineOK = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pickColorButton
			// 
			this.pickColorButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.pickColorButton.Location = new System.Drawing.Point(204, 15);
			this.pickColorButton.Name = "pickColorButton";
			this.pickColorButton.Size = new System.Drawing.Size(75, 25);
			this.pickColorButton.TabIndex = 7;
			this.pickColorButton.Text = "Pick a color";
			this.pickColorButton.Click += new System.EventHandler(this.pickColorButton_Click);
			// 
			// colorTB
			// 
			this.colorTB.BackColor = System.Drawing.Color.Black;
			this.colorTB.Location = new System.Drawing.Point(120, 15);
			this.colorTB.Multiline = true;
			this.colorTB.Name = "colorTB";
			this.colorTB.Size = new System.Drawing.Size(75, 25);
			this.colorTB.TabIndex = 6;
			this.colorTB.Text = "";
			// 
			// colorLab
			// 
			this.colorLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.colorLab.Location = new System.Drawing.Point(16, 15);
			this.colorLab.Name = "colorLab";
			this.colorLab.Size = new System.Drawing.Size(56, 24);
			this.colorLab.TabIndex = 5;
			this.colorLab.Text = "Color :";
			// 
			// ZTb
			// 
			this.ZTb.Location = new System.Drawing.Point(122, 181);
			this.ZTb.Name = "ZTb";
			this.ZTb.Size = new System.Drawing.Size(56, 20);
			this.ZTb.TabIndex = 13;
			this.ZTb.Text = "0,0";
			// 
			// YTb
			// 
			this.YTb.Location = new System.Drawing.Point(122, 149);
			this.YTb.Name = "YTb";
			this.YTb.Size = new System.Drawing.Size(56, 20);
			this.YTb.TabIndex = 12;
			this.YTb.Text = "0,0";
			// 
			// XTb
			// 
			this.XTb.Location = new System.Drawing.Point(122, 117);
			this.XTb.Name = "XTb";
			this.XTb.Size = new System.Drawing.Size(56, 20);
			this.XTb.TabIndex = 11;
			this.XTb.Text = "0,0";
			// 
			// Ylab
			// 
			this.Ylab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Ylab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Ylab.Location = new System.Drawing.Point(10, 149);
			this.Ylab.Name = "Ylab";
			this.Ylab.Size = new System.Drawing.Size(98, 20);
			this.Ylab.TabIndex = 15;
			this.Ylab.Text = "Y coordinate :";
			this.Ylab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Zlab
			// 
			this.Zlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Zlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Zlab.Location = new System.Drawing.Point(10, 181);
			this.Zlab.Name = "Zlab";
			this.Zlab.Size = new System.Drawing.Size(98, 20);
			this.Zlab.TabIndex = 16;
			this.Zlab.Text = "Z coordinate :";
			this.Zlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Xlab
			// 
			this.Xlab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Xlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Xlab.Location = new System.Drawing.Point(10, 117);
			this.Xlab.Name = "Xlab";
			this.Xlab.Size = new System.Drawing.Size(98, 20);
			this.Xlab.TabIndex = 14;
			this.Xlab.Text = "X coordinate :";
			this.Xlab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ZTb2
			// 
			this.ZTb2.Location = new System.Drawing.Point(210, 181);
			this.ZTb2.Name = "ZTb2";
			this.ZTb2.Size = new System.Drawing.Size(56, 20);
			this.ZTb2.TabIndex = 19;
			this.ZTb2.Text = "0,0";
			// 
			// YTb2
			// 
			this.YTb2.Location = new System.Drawing.Point(210, 149);
			this.YTb2.Name = "YTb2";
			this.YTb2.Size = new System.Drawing.Size(56, 20);
			this.YTb2.TabIndex = 18;
			this.YTb2.Text = "1000,0";
			// 
			// XTb2
			// 
			this.XTb2.Location = new System.Drawing.Point(210, 117);
			this.XTb2.Name = "XTb2";
			this.XTb2.Size = new System.Drawing.Size(56, 20);
			this.XTb2.TabIndex = 17;
			this.XTb2.Text = "1000,0";
			// 
			// firstLab
			// 
			this.firstLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.firstLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.firstLab.Location = new System.Drawing.Point(114, 88);
			this.firstLab.Name = "firstLab";
			this.firstLab.Size = new System.Drawing.Size(64, 23);
			this.firstLab.TabIndex = 20;
			this.firstLab.Text = "First point";
			// 
			// secLab
			// 
			this.secLab.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.secLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.secLab.Location = new System.Drawing.Point(194, 88);
			this.secLab.Name = "secLab";
			this.secLab.Size = new System.Drawing.Size(88, 23);
			this.secLab.TabIndex = 21;
			this.secLab.Text = "Second point";
			// 
			// line1
			// 
			this.line1.BackColor = System.Drawing.Color.Black;
			this.line1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.line1.Location = new System.Drawing.Point(13, 85);
			this.line1.Name = "line1";
			this.line1.Size = new System.Drawing.Size(266, 1);
			this.line1.TabIndex = 22;
			// 
			// line2
			// 
			this.line2.BackColor = System.Drawing.Color.Black;
			this.line2.Location = new System.Drawing.Point(14, 109);
			this.line2.Name = "line2";
			this.line2.Size = new System.Drawing.Size(266, 1);
			this.line2.TabIndex = 23;
			// 
			// line3
			// 
			this.line3.BackColor = System.Drawing.Color.Black;
			this.line3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.line3.Location = new System.Drawing.Point(14, 141);
			this.line3.Name = "line3";
			this.line3.Size = new System.Drawing.Size(266, 1);
			this.line3.TabIndex = 24;
			// 
			// line4
			// 
			this.line4.BackColor = System.Drawing.Color.Black;
			this.line4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.line4.Location = new System.Drawing.Point(14, 173);
			this.line4.Name = "line4";
			this.line4.Size = new System.Drawing.Size(266, 1);
			this.line4.TabIndex = 25;
			// 
			// line5
			// 
			this.line5.BackColor = System.Drawing.Color.Black;
			this.line5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.line5.Location = new System.Drawing.Point(14, 205);
			this.line5.Name = "line5";
			this.line5.Size = new System.Drawing.Size(266, 1);
			this.line5.TabIndex = 26;
			// 
			// vertLine1
			// 
			this.vertLine1.BackColor = System.Drawing.Color.Black;
			this.vertLine1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.vertLine1.Location = new System.Drawing.Point(106, 85);
			this.vertLine1.Name = "vertLine1";
			this.vertLine1.Size = new System.Drawing.Size(1, 120);
			this.vertLine1.TabIndex = 27;
			// 
			// vertLine2
			// 
			this.vertLine2.BackColor = System.Drawing.Color.Black;
			this.vertLine2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.vertLine2.Location = new System.Drawing.Point(189, 85);
			this.vertLine2.Name = "vertLine2";
			this.vertLine2.Size = new System.Drawing.Size(1, 120);
			this.vertLine2.TabIndex = 28;
			// 
			// cBox
			// 
			this.cBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBox.Items.AddRange(new object[] {
													  "1",
													  "2",
													  "3",
													  "4",
													  "5",
													  "6",
													  "7",
													  "8",
													  "9",
													  "10",
													  "11",
													  "12",
													  "13",
													  "14",
													  "15",
													  "16",
													  "17",
													  "18",
													  "19",
													  "20",
													  "21",
													  "22",
													  "23",
													  "24",
													  "25",
													  "26",
													  "27",
													  "28",
													  "29",
													  "30",
													  "31",
													  "32",
													  "33",
													  "34",
													  "35",
													  "36",
													  "37",
													  "38",
													  "39",
													  "40",
													  "41",
													  "42",
													  "43",
													  "44",
													  "45",
													  "46",
													  "47",
													  "48",
													  "49",
													  "50",
													  "51",
													  "52",
													  "53",
													  "54",
													  "55",
													  "56",
													  "57",
													  "58",
													  "59",
													  "60",
													  "61",
													  "62",
													  "63",
													  "64",
													  "65",
													  "66",
													  "67",
													  "68",
													  "69",
													  "70",
													  "71",
													  "72",
													  "73",
													  "74",
													  "75",
													  "76",
													  "77",
													  "78",
													  "79",
													  "80",
													  "81",
													  "82",
													  "83",
													  "84",
													  "85",
													  "86",
													  "87",
													  "88",
													  "89",
													  "90",
													  "91",
													  "92",
													  "93",
													  "94",
													  "95",
													  "96",
													  "97",
													  "98",
													  "99",
													  "100"});
			this.cBox.Location = new System.Drawing.Point(120, 49);
			this.cBox.Name = "cBox";
			this.cBox.Size = new System.Drawing.Size(75, 21);
			this.cBox.TabIndex = 30;
			// 
			// lWlab
			// 
			this.lWlab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lWlab.Location = new System.Drawing.Point(16, 53);
			this.lWlab.Name = "lWlab";
			this.lWlab.Size = new System.Drawing.Size(80, 20);
			this.lWlab.TabIndex = 29;
			this.lWlab.Text = "Line weight :";
			// 
			// addLineCancel
			// 
			this.addLineCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addLineCancel.Location = new System.Drawing.Point(204, 221);
			this.addLineCancel.Name = "addLineCancel";
			this.addLineCancel.Size = new System.Drawing.Size(75, 25);
			this.addLineCancel.TabIndex = 32;
			this.addLineCancel.Text = "Cancel";
			this.addLineCancel.Click += new System.EventHandler(this.addLineCancel_Click);
			// 
			// addLineOK
			// 
			this.addLineOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addLineOK.Location = new System.Drawing.Point(120, 221);
			this.addLineOK.Name = "addLineOK";
			this.addLineOK.Size = new System.Drawing.Size(75, 25);
			this.addLineOK.TabIndex = 31;
			this.addLineOK.Text = "OK";
			this.addLineOK.Click += new System.EventHandler(this.addLineOK_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Black;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label1.Location = new System.Drawing.Point(280, 85);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(1, 120);
			this.label1.TabIndex = 33;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Black;
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label2.Location = new System.Drawing.Point(13, 86);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(1, 120);
			this.label2.TabIndex = 34;
			// 
			// AddLineForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 253);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.addLineCancel);
			this.Controls.Add(this.addLineOK);
			this.Controls.Add(this.cBox);
			this.Controls.Add(this.lWlab);
			this.Controls.Add(this.vertLine2);
			this.Controls.Add(this.vertLine1);
			this.Controls.Add(this.line5);
			this.Controls.Add(this.line4);
			this.Controls.Add(this.line3);
			this.Controls.Add(this.line2);
			this.Controls.Add(this.line1);
			this.Controls.Add(this.secLab);
			this.Controls.Add(this.firstLab);
			this.Controls.Add(this.ZTb2);
			this.Controls.Add(this.YTb2);
			this.Controls.Add(this.XTb2);
			this.Controls.Add(this.ZTb);
			this.Controls.Add(this.YTb);
			this.Controls.Add(this.XTb);
			this.Controls.Add(this.colorTB);
			this.Controls.Add(this.pickColorButton);
			this.Controls.Add(this.colorLab);
			this.Controls.Add(this.Ylab);
			this.Controls.Add(this.Zlab);
			this.Controls.Add(this.Xlab);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "AddLineForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Add Line";
			this.ResumeLayout(false);

		}
		#endregion

		private void pickColorButton_Click(object sender, System.EventArgs e)
		{
			if(setColorDlg.ShowDialog() == DialogResult.OK)
			{
				this.colorTB.BackColor = setColorDlg.Color;
			}
		}

		private void addLineOK_Click(object sender, System.EventArgs e)
		{
			line = new CADLine();
			if(setColorDlg.Color == Color.Black)
				line.Color = CADConst.clNone;
			else
				line.Color = setColorDlg.Color;
			try
			{
				line.Point = new DPoint(Convert.ToDouble(this.XTb.Text), Convert.ToDouble(this.YTb.Text), Convert.ToDouble(this.ZTb.Text));
				line.Point1 = new DPoint(Convert.ToDouble(this.XTb2.Text), Convert.ToDouble(this.YTb2.Text), Convert.ToDouble(this.ZTb2.Text));
				line.LineWeight = Convert.ToInt16(this.cBox.Text);
				AddEntityForm.actForm.FCADImage.Converter.GetSection(ConvSection.Entities).AddEntity(line);
				AddEntityForm.actForm.FCADImage.Converter.OnCreate(line);
				AddEntityForm.actForm.FCADImage.Converter.Loads(line);
				AddEntityForm.actForm.FCADImage.GetExtents();
				AddEntityForm.actForm.DoResize();
			}
			catch(FormatException exception)
			{
				MessageBox.Show(exception.Message, "Add Entity Demo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			
			AddEntityForm.actForm.Invalidate();
			this.Close();
		}

		private void addLineCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
